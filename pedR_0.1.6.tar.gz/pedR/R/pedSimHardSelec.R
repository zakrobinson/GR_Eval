#' A function to simulate selection, evolution, and population dyamics in a closed population
#'
#' This function runs a forward-time, genomic simulation of evolution in a closed population. The simulation
#' saves the entire pedigree, genotypes at any number of simulated loci, the locations of haplotype junctions on each chromosome, quantitative trait
#' characteristics (e.g., heritability), allele frequencies at all simulated loci (including quantitative trait loci) throughout the simulation.
#' @param chrNum Number of simulated chromosomes. Must equal the length of chrLengs physLengs (see below). This will be overridden if a map file is provided.
#' @param chrLengs Vector of length chrNum giving the chromosome sizes in centiMorgans. Set to NULL if reading in a map file. This will be overridden if a map file is provided.
#' @param physLengs Vector of length chrNum giving the physical chromosome lengths in Megabases. This will be overridden if a map file is provided.
#' @param map A map file object to be used to assign physical chromosome sizes and the landscape of recombination rates across each chromosome.
#'     Genetic and physical chromsome lengths in the map file will override chrNum, chrLengs, and physLengs above when provided.
#' @param simLociNum The total number of SNPs that will be simulated. We first draw allele frequencies in the source population from a beta distribution with shape parameters
#'     of beta1 an beta2 (see below). We then assign diploid genotypes to the founders and immigrants assuming Hardy-Weinberg proportions and
#'     no linkage disequilibrium in the source population. Will be overriden when genotypes are imported (see genoImport below).
#' @param beta1 First shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param beta2 Second shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param gens Maximum number of generations to simulate. Note that the simulation model is of a random mating population (including self fertilization) with
#'     non-overlapping generations.
#' @param burnin Number of generations to run the simulation before beginning simulation and selection on a phenotype. This gives the user the opportunity to allow
#'     time for linkage disequilibrium to build up in the population before imposing selection.
#' @param lastGenSelec The last generation of selection on the quantitative trait. Must be NULL or an integer >burnin and <= than gens.
#' @param popSize Vector of length(gens) giving the population size each generation.
#' @param genoImport An object giving the genotypes of population founders. See 'help(selecSimGenos)' for details on formatting imported founder genotypes.
#' @param QTLFreqs Vector o length 2 giving the minimum and maximum allele frequencies at QTLs during the first generation of selection (burnin + 1).
#' @param h2 The initial narrow sense heritability of the selected trait.
#' @param numLgQTL Number of large effect QTLs.
#' @param numSmQTL Number of small effect QTLs.
#' @param propMajor Initial fraction of the additive genetic variance due to variation in the large effect QTL(s).
#' @param VP The phenotypic variance in the first generation of phenotype simulation and selection.
#' @param phenStart The desired mean phenotype in the first generation of phenotype simulation and selection.
#' @param phenFit The value of the phenotype with the highest fitness.
#' @param survProbs The probability of survival of an individual with the optimal phenotype value (phenFit) in the absence of density dependence.
#' @param carryCap Carrying capacity for the populations. Additional mortality will be imposed when the population exceeds carryCap.
#' @param popSize Starting population size. Must be a single integer >= 2.
#' @param famSize Mean number of offspring produced by each female (Poisson distribution).
#' @details
#'
#'    Output includes 9 objects:
#'
#'    pedObject is a data frame with one row for each individual and five columns including a unique indiviudal identifier (id); the ids
#'    of the two parents (mom and dad); the generation the individual was born in (gen); and whether the individual is an immigrant (0 = locally born,
#'    1 = immigrant).
#'
#'    juncMat1 and juncMat2 are data frames with columns for the individual id, chromosome number, and the locations of junctions in centiMorgans, including
#'    the beginning (0) and end of the chromosome. juncMat1 gives the junction locations on the first chromosome copy and juncMat2 gives the junction
#'    locations on the second chromosome copy. The number of columns in juncMat1 and juncMat2 are determined by the maximium number of junctions observed
#'    among the simulated individuals... Columns are filled with NAs where necessary.
#'
#'    hapIDMat1 and hapIDMat2 are data frames with columns for the individual id, chromosome number, and the haplotype identity of each segment on the
#'    chromosome. hapIDMat1 and hapIDMat2 give the haplotype identities for chromosome copies one and two, respectively. The haplotype identities correspond
#'    to the chromosome stretches between each of the junctions given in corresponding rows juncMat1 and juncMat2.
#'
#'    genoMat gives the genotypes for each simulated individual. Each row represents a locus. Columns include the chromsome identity (chromID), the map position
#'    on the chromosome in centiMorgans (chromMapPos), and the physical position on the chromosome (chromPhysPos). There are then two columns giving the alleles
#'
#'    quantTraitDat is a data frame with 5 columns saving information on the quantitative genetic parameters throughout the simulation, from generations burnin + 1 to gens.
#'    Columns are generation ("gens"); the additive genetic variance for the quantitative trait (VaVec); the total phenotypic variance (VpVec); the narrow sense heritability
#'    of the quantitative trait (h2Vec); and the mean value of the trait among all indiviuals in the population (traitMean).
#'
#'    allFreqMat is a data frame storing the allele frequency at every simulated locus throughout the simulation. The first column is the generation (starting with generation 2).
#'    The remaining columns give the allele frequency at every simulated locus in the genome. The corresponding locations of the loci are given in genoMat.
#'
#'    qtlInfo is a data frame with three columns: the ID of the SNPs that were chosen as QTLs (qtls); expected heterozygosity of each QTL in the first generation of trait simulation (generation burnin + 1);
#'    and the effect size and direction of each QTL.
#'
#'    NVec is a vector saving the population sizes for each generation of the simulation. Note that NVec will be shorter than gens if the population goes extinct (i.e., when there is <= 1 adult individual left)
#'
#' @return
#'
#' @examples
#'
#'  library(pedigreeR)
#' # simulate a population with constant recombination rate across each chromosome
#' pedSimHardSelec(chrNum=2,chrLengs=rep(50,2),physLengs=rep(100,2),map=NULL,simLociNum=200,beta1=0.5,
#'                beta2=0.5,burnin=1,gens=40,lastGenSelec = 40,genoImport=NULL,QTLFreqs=c(0.01,0.99),h2=0.6,numLgQTL=1,
#'                numSmQTL=99,propMajor = 0.8,VP=10,phenStart = 100,phenFit = 110,survProbs = 0.8,survProbSlope=0.4/10,carryCap = 300,
#'                popSize = 150,famSize = 4)
#'
#' # plot the frequencies of positively selected alleles through time. Line width is proportional to the allele's pheontypic effect size.
#'
#' plot(c(1,ncol(qtlInfo)-5),c(0,1),type="n",ylab="Allele frequency",xlab="Generation of selection")
#' for(i in 1:nrow(qtlInfo)){
#'   lines(1:(ncol(qtlInfo)-5),as.numeric(qtlInfo[i,6:ncol(qtlInfo)]),lwd=qtlInfo[i,3])
#' }
#'
#' # plot the phenotype values through time
#' rollMeans <- rep(NA,40)
#' plot(c(0,40),c(95,115),type="n",xlab="Generation",ylab="Phenotype size")
#' for(i in 1:40){
#'  genDat <- pedObject[which(pedObject[,4] == i),]
#'  points(rep(i,nrow(genDat)),genDat[,8],col="darkblue",pch=16,cex=0.1)
#'  rollMeans[i] <- mean(genDat[,8])
#' }
#'lines(1:40,rollMeans,lwd=2)
#' @importFrom stats rbeta rexp rnorm rpois runif var lm
#' @importFrom utils read.table
#'
#' @export
#'
pedSimHardSelec <- function(chrNum,chrLengs,physLengs,map,simLociNum,beta1,beta2,burnin,gens,lastGenSelec,genoImport,QTLFreqs,h2,numLgQTL,numSmQTL,propMajor,VP,phenStart,phenFit,survProbs,survProbSlope,carryCap,popSize,famSize){
  if(is.null(chrLengs) == FALSE & is.null(physLengs) == FALSE & is.null(chrNum) == FALSE){
    if(3*chrNum != sum(chrNum,length(chrLengs),length(physLengs)))stop("lengths of chrLengs and physLengs must equal chrNum")
  }
  if(simLociNum <= 0)stop("must simulate at least one SNP locus")
  if(beta1 <= 0 | beta2 <= 0)stop("beta1 and beta2 must be positive")
  if(is.null(popSize) == TRUE) stop("must specify vector of population sizes")
  if(length(popSize) != 1)stop("popSize must be a single integer giving the starting size of the population")
  if(sum(popSize < 1) > 0)stop("popSize must be a positive integer)")
  if(lastGenSelec <= burnin | lastGenSelec > gens)stop("lastGenSelec must be > burnin and <= gens")

  ###################################
  # read in the map file if specified
  ###################################
  if(is.null(map) == FALSE){
    mapFile <- map
    chrNum <- length(unique(mapFile[,1]))
    chrLengs <- rep(NA,chrNum)
    physLengs <- rep(NA,chrNum)
    for(i in 1:length(physLengs)){
      physLengs [i] <- max(mapFile[which(mapFile[,1] == i),2])
      chrLengs [i]  <- max(mapFile[which(mapFile[,1] == i),3])
    }

    #### calculate segment recombination rates
    recRates <- NULL
    for(i in 1:chrNum){
      thisChrMap <- mapFile[which(mapFile[,1] == i),]
      theseRates <- rep(NA,nrow(thisChrMap))
      for(j in 1:(length(theseRates)-1)){
        theseRates[j] <- (thisChrMap[j+1,3]-thisChrMap[j,3])/(thisChrMap[j+1,2]-thisChrMap[j,2])
      }
      recRates <- c(recRates,theseRates)
    }
    mapFile <- cbind(mapFile,recRates)
  }

  ########################################
  # import founder genotypes if specified
  ########################################
  if(is.null(genoImport) == FALSE){
    importGenos <- genoImport
    simLociNum <- nrow(importGenos)
    if(chrNum != length(unique(importGenos[,1])))stop("chrNum must equal the number of chromosomes in the imported genotype data")
    if(popSize[1] != (ncol(importGenos)-3)/2)stop("Number of imported genotpes must equal the population size in the first generation (popSize [1])")

    #### check that the simulated chromosomes capture all of the imported loci
    importChroms <- unique(importGenos[,1])
    impPhysLengs <- rep(NA,length(importChroms))
    impGenLengs <- rep(NA,length(importChroms))
    for(i in 1:length(importChroms)){
      impPhysLengs[i] <- max(importGenos[which(importGenos[,1] == importChroms[i]),3])
      impGenLengs[i] <- max(importGenos[which(importGenos[,1] == importChroms[i]),2])
    }
    #if(sum(chrLengs <= impGenLengs) > 0) stop("chrLengs must be greater than the map lengths of the corresponding imported chromosomes")
    if(sum(physLengs <= impPhysLengs) > 0) stop("physLengs must be greater than the physical lengths of the corresponding imported chromosomes")
  }
  if(is.null(genoImport)) {allFreqs <- rbeta(n=simLociNum,shape1=beta1,shape2=beta2)}                     # expected heterozygosity at each locus in the source population... these frequencyes will be used to assign founder genotpyes stochastically, assuming infinite Ne (no linkage disequilibrium) in the source population
  VA <- h2*VP                                                                      # assign the additive genetic variance of the phenotype

  if(is.null(genoImport)){
    snpChrs <- sort(sample(1:chrNum,size=simLociNum,replace=TRUE,prob=physLengs))  # assign SNP chromosomes
    snpPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      theseChrs <- snpChrs[which(snpChrs == i)]
      theseSnpPos <- sort(runif(n=length(theseChrs),min=0,max=physLengs[i]))
      snpPos <- c(snpPos,theseSnpPos)
    }
    snpMat <- cbind(snpChrs,snpPos)                                               # object storing SNP chromosome assignments and positions
  }

  if(is.null(genoImport) == FALSE){         # Assign SNP positions if you have imported founder genotypes
    snpChrs <- genoImport[,1]
    snpPos <- genoImport[,3]
    snpMat <- cbind(snpChrs,snpPos)
  }
  id <- 1:popSize[1]
  mom <- rep(NA,popSize[1])
  dad <- rep(NA,popSize[1])
  gen <- rep(1,length(id))
  pedObject <- cbind(id,mom,dad,gen)    # store the simulated pedigree information

  ################################################################
  # initialize founder and immigrant chromosome segment identities
  ################################################################
  fstJuncList <- list()      # lists of length(chroms), where each element is a list of all simulated individuals storing the genetic mapping locations of junctions
  secJuncList <- list()
  fstChrOrigList <- list()   # lists of length(chroms), where each element will be a list of length nrow(pedObject) to store chrom segment origin
  secChrOrigList <- list()
  immVec <- rep(0,nrow(pedObject))   # indicator variable for immigrants
  imms <- which(is.na(pedObject[,2]) == TRUE)  # identify the founders and immigrants
  immVec[imms] <- 1
  pedObject <- cbind(pedObject,immVec)
  for (i in 1:chrNum){
    fstChrOrigList[[i]] <- list()
    secChrOrigList[[i]] <- list()
    fstJuncList[[i]] <- list()
    secJuncList[[i]] <- list()
  }
  for(i in 1:chrNum){
    foundOrigIter <- 1
    for(j in 1:length(imms)){
      fstChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      secChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      fstJuncList[[i]] [[imms[j]]] <- c(0,physLengs[i])
      secJuncList[[i]] [[imms[j]]] <- c(0,physLengs[i])
    }
  }

  ##################################################
  # genotype the founders and immigrants chromosomes
  ##################################################
  #### calculate the minor allele frequencies
  if(is.null(genoImport)){
    mafs <- allFreqs
    #mafs[which(allFreqs > 0.5)] <- 1 - allFreqs[which(allFreqs > 0.5)]
  }
  foundChrGenos <- matrix(NA,nrow=length(imms)*2,ncol=simLociNum+1)
  print("genotyping founding generation")

  if(is.null(genoImport)){          # simulate the genotypes if you have not imported them
    for (i in 2:ncol(foundChrGenos)){
      theseGenos1 <- rep("A",nrow(foundChrGenos))
      allTrials1 <- runif(nrow(foundChrGenos),min=0,max=1)
      if(i %in% seq(2,ncol(foundChrGenos),2)){
        theseGenos1[allTrials1 > mafs[i-1]] <- "T"
      }
      if(i %in% seq(3,ncol(foundChrGenos),2)){
        theseGenos1[allTrials1 < mafs[i-1]] <- "T"
      }
      foundChrGenos[,i] <- theseGenos1
    }
  foundChrGenos[,1] <- 1:(2*length(imms))
  }

  if(is.null(genoImport) == FALSE){   # imported genotypes for founders
    fstAlls <- seq(4,ncol(importGenos),2)
    secAlls <- fstAlls + 1
    rowIter <- 1
    for(i in 1:length(imms)){
      foundChrGenos [rowIter,2:ncol(foundChrGenos)] <- as.character(importGenos[,fstAlls[i]])
      rowIter <- rowIter + 1
      foundChrGenos [rowIter,2:ncol(foundChrGenos)] <- as.character(importGenos[,secAlls[i]])
      rowIter <- rowIter + 1
    }
  foundChrGenos[,1] <- 1:(2*length(imms))
  }
  genoMat1 <- matrix(NA,nrow=round(carryCap*3*gens),ncol=simLociNum+1)
  genoMat2 <- matrix(NA,nrow=round(carryCap*3*gens),ncol=simLociNum+1)
  fstAlls <- seq(1,length(imms)*2,2)
  secAlls <- seq(2,length(imms)*2,2)
  for(i in imms){
    genoMat1[i,] <- foundChrGenos[fstAlls[i],]
    genoMat2[i,] <- foundChrGenos[secAlls[i],]
  }
  genoMat1[1:length(imms),1] <- imms
  genoMat2[1:length(imms),1] <- imms

  #################################################
  # keep track of quantitative trait parameters
  #################################################
  sVec <-  rep(NA,length((burnin+1):gens))
  VaVec <- rep(NA,length((burnin+1):gens))
  VpVec <- rep(NA,length((burnin+1):gens))
  h2Vec <- rep(NA,length((burnin+1):gens))
  allFreqMat <- matrix(NA,nrow=gens,ncol=simLociNum)
  traitMean <- rep(NA,length((burnin+1):gens))
  indTraitVal <- NULL # vector storing the trait value for every simulated individual
  qtlInfo <- NULL  # object storing the locations and effect sizes of the simulated QTLs
  NVec <- nrow(pedObject)

  ######################################
  # simulate 2:gens generations
  ######################################
  i <- 2            # iterate over generations
  extinct <- FALSE  # the population size is > 0 to start
  while(i <= gens & extinct == FALSE){
    lastG1 <- genoMat1[which(pedObject[,4] == i - 1),2:ncol(genoMat1)]
    lastG2 <- genoMat2[which(pedObject[,4] == i - 1),2:ncol(genoMat2)]
    aCnts1 <- colSums(lastG1 == "A")
    aCnts2 <- colSums(lastG2 == "A")
    aCnts <- aCnts1 + aCnts2
    aFreqs <- aCnts /(2*nrow(lastG1))
    hetMat <- lastG1 != lastG2
    obsHets <- colSums(hetMat)/nrow(hetMat)
    expHet <- 2*aFreqs*(1-aFreqs)
    Fis <- 1-(obsHets/expHet)
    allFreqMat[i,] <- aFreqs
    if(i < (burnin + 1)){indTraitVal <- c(indTraitVal,rep(NA,nrow(pedObject) - length(indTraitVal)))}
    if(i >= (burnin + 1)){       # if the burnin is over, then calculate allele frequencies so that you can identify QTLs
      expHet <- 2*aFreqs*(1-aFreqs)                                            # expected heterozygosity

      ###################################################################
      # assign the QTL effects (the first generation after burnin period)
      ###################################################################
      if(i == burnin + 1){
        candQtls <- which(aFreqs >= QTLFreqs[1] & aFreqs <= QTLFreqs[2])       # Identify candidate QTL loci based on allele frequency
        qtls <- sort(sample(candQtls,size=numLgQTL+numSmQTL,replace=FALSE))    # randoly select among the candidate QTL loci
        majQTL <- sample(qtls,size=numLgQTL,replace=FALSE)                     # randomly select a major effect locus
        qtlExpHet <- expHet[qtls]                                              # expected heterozygosity at the QTLs
        qtl1Mat <- genoMat1[which(pedObject[,4] == i - 1),qtls+1]              # pull out the QTLs
        qtl2Mat <- genoMat2[which(pedObject[,4] == i - 1),qtls+1]
        numAs <- (qtl1Mat == "A") + (qtl2Mat == "A")   # count the As in each individual at each locus
        locusPropVars <- rep(NA,numLgQTL+numSmQTL)                             # locus-specific proportional genetic variances
        expSamps <- rexp(n = numSmQTL,rate=1)                                  # sample effect sizes of small effect loci from an exponential distribution
        expSizes <- ((1-propMajor)/sum(expSamps))*expSamps                     # proportion of the genetic varianc explained by each non-major locus (exponentially distributed)
        locusPropVars[which(qtls %in% majQTL == FALSE)] <- expSizes
        locusPropVars[which(qtls %in%  majQTL)] <- propMajor/numLgQTL
        locusVars <- locusPropVars * VA
        qtlEffs <- sqrt(locusVars/qtlExpHet)
        qtlInfo <- cbind(qtls,qtlExpHet,qtlEffs)
      }
      qtlExpHet <- expHet[qtls]                                                # expected heterozygosity at the QTLs
      majQTLExpHet <- qtlExpHet[which(qtls %in% majQTL)]                       # expected heterozygosity at the major effect QTL(s)
      qtl1Mat <- genoMat1[which(pedObject[,4] == i - 1),qtls+1]                # pull out the QTLs
      qtl2Mat <- genoMat2[which(pedObject[,4] == i - 1),qtls+1]
      numAs <- (qtl1Mat == "A") + (qtl2Mat == "A")                             # count the As in each individual at each locus
      xMat <- numAs * matrix(rep(qtlEffs,sum(pedObject[,4] == i - 1)),nrow=sum(pedObject[,4] == i - 1),ncol=length(qtlEffs),byrow=TRUE)
      Va <- var(rowSums(xMat))                                         # additive genetic variance in the trait
      Vp <- Va/h2                                                              # total phenotypic variance in the trait
      if(i == burnin + 1){
        Ve <- Vp-Va                                                            # environmental (error) variance in the trait. Keep constant after the first generation of selection
        modIntercept <- phenStart - mean(rowSums(xMat))                        # Intercept of the quantitative genetic model, assigned so that the starting mean
      }                                                                        # mean phenotype will be approximately phenStart
      resids <- rnorm(n=sum(pedObject[,4] == i - 1),mean=0,sd=sqrt(Ve))                       # rediduals (adjust phenotypes for random environmental variation)
      phenVec <- modIntercept + rowSums(xMat) + resids                         # assign phenotypic values for each individual
      indTraitVal <- c(indTraitVal,phenVec)
      VaVec [i - burnin] <- Va                                                 # save the quantitative genetic parameter values
      VpVec [i - burnin] <- var(phenVec)
      h2Vec [i - burnin] <- Va/var(phenVec)
      traitMean [i-burnin] <- mean(phenVec)

      ##############################################
      # selection on the phenotype
      ##############################################
      survProbVec <- rep(NA,length(phenVec))
      for(nb in 1:length(survProbVec)){
        survProbVec [nb]<- survProbs - survProbSlope *abs(phenFit - phenVec[nb])
      }
      if(length(phenVec) > carryCap){
        parToK <- 2*(carryCap/(famSize))   # number of parents needed to produce K offspring on average
        survToK <- parToK/length(phenVec)  # mean survival probability needed to get to K on average next generation
        if(mean(survProbVec) > survToK){   # lower survival probabilities to bring the population down to K
          survProbVec <- survProbVec - (mean(survProbVec) - survToK)
        }
      }
      survTest <- runif(n=length(phenVec),min=0,max=1) <= survProbVec
      removeInds <- which(survTest == 0)

      ##########################
      # check for extinction
      ##########################

      if(sum(survTest == 1) <= 1) {
        extinct <- TRUE
      }
      if(sum(survTest) > 1){ # continue if there are at least two parents remaining
        remainInds <- (1:length(phenVec))[which(1:length(phenVec) %in% removeInds == FALSE)]
        if(is.null(lastGenSelec) == FALSE & i > lastGenSelec){                   # consider all individuals as candidate parents if i is greater than the last generation of selection
          remainInds <- 1:length(phenVec)
        }
        moms <- sample(x=pedObject[which(pedObject[,4] == i - 1)[remainInds],1],size=round(0.5*length(remainInds)),replace=TRUE)   # sample moms with selection
        dads <- rep(NA,length(moms))
        for(z in 1:length(moms)){
          possibleDads <- pedObject[which(pedObject[,4] == i - 1)[remainInds],1][-which(pedObject[which(pedObject[,4] == i - 1)[remainInds],1] == moms[z])]
          dads[z] <- sample(x=possibleDads,size=1,replace=FALSE)
        }
        sVec [i-burnin] <- mean(phenVec[remainInds]) - mean(phenVec)
      }
    }
    if(i <= burnin){                                  # sample moms and dads without allowing self fertilization
      if(length(which(pedObject[,4] == i - 1)) > carryCap){     # increase mortality in fecessary to bring the population to carrying capacity
        remainInds <- sample(1:length(which(pedObject[,4] == i - 1)),carryCap,replace=FALSE)
      }
      if(length(which(pedObject[,4] == i - 1)) <= carryCap){     # sample parents without decreasing population size if the population is already below arrying capacity
        remainInds <- 1:length(which(pedObject[,4] == i - 1))
      }
      moms <- sample(x=pedObject[which(pedObject[,4] == i - 1),1][remainInds],size=0.5*length(pedObject[which(pedObject[,4] == i - 1),1][remainInds]),replace=TRUE)   # sample moms
      dads <- rep(NA,length(moms))
      for(z in 1:length(moms)){
        possibleDads <- pedObject[which(pedObject[,4] == i - 1)[remainInds],1][-which(pedObject[which(pedObject[,4] == i - 1)[remainInds],1] == moms[z])]
        dads[z] <- sample(x=possibleDads,size=1,replace=FALSE)
      }
    }
    # assign family sizes
    nOffs <- 0 # initialize nOffs at zero
    if(length(moms) > 0){        # assign family sizes if there are any mother-father pairs
      nOffs <- rpois(n=length(moms),lambda = famSize)
    }
    if(length(moms) == 0 | sum(nOffs) <= 1){        # check for family sizes sith size > 0
      extinct <- TRUE
    }

    ###################################################
    # assign IDs for new offspring (if there are any)
    ###################################################
    if(sum(nOffs) > 0){
      theseInds <- (nrow(pedObject)+1):(nrow(pedObject)+ sum(nOffs))  # vector of non-immgrant individuals to assign haplotypes to
      id <-  (max(pedObject[,1])+1):(max(pedObject[,1])+length(theseInds))
      gen <- rep(i, length(id))
      immVec <- rep(0,length(id))
      mom <- NULL
      dad <- NULL
      for(z in 1:length(moms)){
        mom <- c(mom,rep(moms[z],nOffs[z]))
        dad <- c(dad,rep(dads[z],nOffs[z]))
      }
      outDat <- cbind(id,mom,dad,gen,immVec)
      pedObject <- rbind(pedObject,outDat)

      #####################################################
      # Mendelian segregation
      #####################################################
      offGenoMat1 <- matrix(NA,nrow=length(theseInds),ncol= simLociNum + 1)          # store the individual genotypes
      offGenoMat2 <- matrix(NA,nrow=length(theseInds),ncol= simLociNum + 1)
      for(j in 1:length(theseInds)){
        thisMom <- pedObject[which(pedObject[,1] == theseInds[j]),2]
        thisDad <- pedObject[which(pedObject[,1] == theseInds[j]),3]
        chromPickerVec <- rep(c(1,2),500)  # vector you will use to iterate between parental chromosome copies with recombination events during meiosis
        chromeOneGeno <- NULL
        chromeTwoGeno <- NULL
        chromID <- NULL
        chromPhysPos <- NULL
        for (k in 1:chrNum){    # meiosis in the mom and dad
          if(is.null(map) == FALSE){thisChrMap <- mapFile[which(mapFile[,1] == k),]} # grab the linkage map for this chromosome}
          segTest <- 0 # indicator testing for proper recombination; this will switch to 1 after confirming proper recombination; this catches the rare recombination error arising from R using floating point numbers
          while(segTest == 0){
            outMomJuncs <- NULL # the junction locations in the offspring that will come from the mom
            outMomOrig <- NULL # the haplotype origins in the offspring that will come from the mom
            momChromOrig1 <- fstChrOrigList[[k]][[thisMom]] # haplotype origins for the mom's first chromosome copy
            momChromOrig2 <- secChrOrigList[[k]][[thisMom]] # haplotype origins for the mom's second chromosome copy
            momChromJunc1 <- fstJuncList[[k]][[thisMom]] # chromosome junctions for the mom's first chromosome copy
            momChromJunc2 <- secJuncList[[k]][[thisMom]] # chromosome junctions for the mom's second chromosome copy
            outDadJuncs <- NULL # the junction locations in the offspring that will come from the dad
            outDadOrig <- NULL # the haplotype origins in the offspring that will come from the dad
            dadChromOrig1 <- fstChrOrigList[[k]][[thisDad]] # haplotype origins for the dad's first chromosome copy
            dadChromOrig2 <- secChrOrigList[[k]][[thisDad]] # haplotype origins for the dad's second chromosome copy
            dadChromJunc1 <- fstJuncList[[k]][[thisDad]] # chromosome junctions for the dad's first chromosome copy
            dadChromJunc2 <- secJuncList[[k]][[thisDad]] # chromosome junctions for the dad's second chromosome copy

            #### determine number of crossovers
            momRecs <- rpois(n=1,lambda=chrLengs[k]/100)  # number of recombinations during meiosis in the mom
            dadRecs <- rpois(n=1,lambda=chrLengs[k]/100)  # number of recombinations during meiosis in the dad
            recLocsMom <- NULL # locations of recombination events during meiosis in each of the parents
            recLocsDad <- NULL

            #### make the offspring maternal chromosome copy if there are >=1 crossovers in the maternal meiosis
            momJuncList <- list()               # list of length two carrying the maternal chromsome junction locations
            momJuncList[[1]] <- momChromJunc1
            momJuncList[[2]] <- momChromJunc2
            momOrigList <- list()               # list of length two carrying the maternal chromsome haplotype origins
            momOrigList [[1]] <- momChromOrig1
            momOrigList [[2]] <- momChromOrig2
            momChrIter <- chromPickerVec[sample(x=c(1,2),size=1,replace=FALSE):length(chromPickerVec)]   # which chromosome do we sample before the first crossover?
            if(momRecs > 0){
              outMomJuncs <- 0
              if(is.null(map) == TRUE){recLocsMom <- sort(runif(n=momRecs,min=0,max=physLengs[k]))}  # assign the locations of recombination events during meiosis in the mom
              if(is.null(map) == FALSE){
                recGenLocsMom <- sort(runif(n=momRecs,min=0,max=chrLengs[k]))
                recLocsMom <- rep(NA,length(recGenLocsMom))
                for(n in 1:length(recLocsMom)){
                  prevRow <- which(thisChrMap[,3] < recGenLocsMom[n])[length(which(thisChrMap[,3] < recGenLocsMom[n]))]
                  recLocsMom [n] <- thisChrMap[prevRow,2] + (recGenLocsMom[n]-thisChrMap[prevRow,3])/(thisChrMap[prevRow+1,3]-thisChrMap[prevRow,3] ) * (thisChrMap[prevRow+1,2]-thisChrMap[prevRow,2])
                }
              }
              for(l in 1:(momRecs)){  # populate the offspring junction and haplotype origins vector
                inJuncs <- outMomJuncs
                outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[l] ]][which(momJuncList[[ momChrIter[l] ]] > max(outMomJuncs) & momJuncList[[ momChrIter[l] ]] < recLocsMom[l])],recLocsMom[l])
                outMomOrig  <- c(outMomOrig,momOrigList[[ momChrIter[l] ]][  (which(momJuncList[[ momChrIter[l] ]] >= max(inJuncs))[1]-1) : which(momJuncList[[ momChrIter[l] ]] < recLocsMom[l])[length(which(momJuncList[[ momChrIter[l] ]] < recLocsMom[l]))]])
              }
              inJuncs <- outMomJuncs
              outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[l+1] ]][which(momJuncList[[ momChrIter[l+1] ]] > max(outMomJuncs))])   # finish the offspring junction location and haplotype orgins vector
              outMomOrig <- c(outMomOrig,momOrigList[[ momChrIter[l+1] ]]  [(which(momJuncList[[ momChrIter[l+1] ]] >= max(inJuncs))[1]-1):length(momOrigList[[ momChrIter[l+1] ]])])
            }
            #### make the offspring maternal chromosome copy if there are no crossovers in the maternal meiosis
            if(momRecs == 0){
              outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[1] ]]) # finish the offspring junction location and haplotype orgins vector
              outMomOrig <- c(outMomOrig,momOrigList[[ momChrIter[1] ]])
            }
            #### make the offspring paternal chromosome copy if there are >=1 crossovers in the paternal meiosis
            dadJuncList <- list()               # list of length two carrying the paternal chromsome junction locations
            dadJuncList[[1]] <- dadChromJunc1
            dadJuncList[[2]] <- dadChromJunc2
            dadOrigList <- list()               # list of length two carrying the paternal chromsome haplotype origins
            dadOrigList [[1]] <- dadChromOrig1
            dadOrigList [[2]] <- dadChromOrig2
            dadChrIter <- chromPickerVec[sample(x=c(1,2),size=1,replace=FALSE):length(chromPickerVec)]   # which chromosome do we sample before the first crossover?
            if(dadRecs > 0){
              outDadJuncs <- 0
              if(is.null(map) == TRUE){recLocsDad <- sort(runif(n=dadRecs,min=0,max=physLengs[k]))}  # assign the locations of recombination events during meiosis in the dad
              if(is.null(map) == FALSE){
                recGenLocsDad <- sort(runif(n=dadRecs,min=0,max=chrLengs[k]))
                recLocsDad <- rep(NA,length(recGenLocsDad))
                for(n in 1:length(recLocsDad)){
                  prevRow <- which(thisChrMap[,3] < recGenLocsDad[n])[length(which(thisChrMap[,3] < recGenLocsDad[n]))]
                  recLocsDad [n] <- thisChrMap[prevRow,2] + (recGenLocsDad[n]-thisChrMap[prevRow,3])/(thisChrMap[prevRow+1,3]-thisChrMap[prevRow,3] ) * (thisChrMap[prevRow+1,2]-thisChrMap[prevRow,2])
                }
              }
              for(l in 1:(dadRecs)){     # populate the offspring junction and haplotype origins vector
                inJuncs <- outDadJuncs
                outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[l] ]][which(dadJuncList[[ dadChrIter[l] ]] > max(outDadJuncs) & dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l])],recLocsDad[l])
                outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[l] ]][  (which(dadJuncList[[ dadChrIter[l] ]] >= max(inJuncs))[1]-1) : which(dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l])[length(which(dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l]))]])
              }
              inJuncs <- outDadJuncs
              outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[l+1] ]][which(dadJuncList[[ dadChrIter[l+1] ]] > max(outDadJuncs))])   # finish the offspring junction location and haplotype orgins vector
              outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[l+1] ]]  [(which(dadJuncList[[ dadChrIter[l+1] ]] >= max(inJuncs))[1]-1):length(dadOrigList[[ dadChrIter[l+1] ]])])
            }
            #### make the offspring paternal chromosome copy if there are no crossovers in the paternal meiosis
            if(dadRecs == 0){
              outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[1] ]]) # finish the offspring junction location and haplotype orgins vector
              outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[1] ]])
            }
            if(length(outMomOrig) == (length(outMomJuncs) - 1) & length(outDadOrig) == (length(outDadJuncs) - 1)) segTest <- 1    # this handles the rare case where rounding error due to using floating point numbers causes a recombination error                                                                                                                        # If there's an error then the maternal and paternal gametes will be reconstructed
          }
          fstJuncList[[k]][[theseInds[j]]] <- outMomJuncs           # save the maternal and paternal chromosome information
          secJuncList[[k]][[theseInds[j]]] <- outDadJuncs
          fstChrOrigList[[k]][[theseInds[j]]]<- outMomOrig
          secChrOrigList[[k]][[theseInds[j]]] <- outDadOrig
          fstSegs <- fstJuncList[[k]][[theseInds[j]]]           # Junction location on the first and second copies of the the kth chromosome in the ith individual
          secSegs <- secJuncList[[k]][[theseInds[j]]]
          fstOrigs <- fstChrOrigList[[k]][[theseInds[j]]]       # founder origins of the first and second chromosome haplotypes
          secOrigs <- secChrOrigList[[k]][[theseInds[j]]]
          thesePos  <- snpMat [which(snpMat[,1] == k),2]
          chromID <- c(chromID,rep(k,length(thesePos)))
          snpOrigVec1 <- rep(NA,length(thesePos))   # list storing the founder origin of each SNP on this chromsome
          snpOrigVec2 <- rep(NA,length(thesePos))   # list storing the founder origin of each SNP on this chromsome
          for(n in 1:length(fstOrigs)){
            theseBounds <- fstSegs[n:(n+1)]    # the bounds of this segment
            theseSNPs <-which(thesePos > theseBounds[1] & thesePos <= theseBounds[2]) # index the SNPs that reside in this segment
            snpOrigVec1 [theseSNPs] <- fstOrigs[n]
          }
          for(n in 1:length(secOrigs)){
            theseBounds <- secSegs[n:(n+1)]    # the bounds of this segment
            theseSNPs <- which(thesePos > theseBounds[1] & thesePos <= theseBounds[2]) # index the SNPs that reside in this segment
            snpOrigVec2 [theseSNPs] <- secOrigs[n]
          }
          thisFstGeno <- rep(NA,length(thesePos)) # vector of genotypes at these snps
          thisSecGeno <- rep(NA,length(thesePos))  # vector of genotypes at these snps
          fstGenoFounds <- unique(snpOrigVec1) # vectors of unique founder chromosome IDs represented in the individual's genotype
          secGenoFounds <- unique(snpOrigVec2)
          for (n in 1:length(fstGenoFounds)){        # assign genotypes on the first chromosome copy
            thisFstGeno[which(snpOrigVec1 == fstGenoFounds[n])] <- foundChrGenos[which(foundChrGenos[,1] == fstGenoFounds[n]),(which(snpMat[,1] == k)+1)[which(snpOrigVec1 == fstGenoFounds[n])]]
          }
          for (n in 1:length(secGenoFounds)){        # assign genotypes on the first chromosome copy
            thisSecGeno[which(snpOrigVec2 == secGenoFounds[n])] <- foundChrGenos[which(foundChrGenos[,1] == secGenoFounds[n]),(which(snpMat[,1] == k)+1)[which(snpOrigVec2 == secGenoFounds[n])]]
          }

          #### if statements below deal with the rare occurence of a SNP being located very near a junction... Here R sometimes (rarely) makes a rounding error that makes the simulation leave a genotype missing
          if(sum(is.na(thisFstGeno)) > 0) {thisFstGeno[which(is.na(thisFstGeno) == TRUE)] <- thisSecGeno[which(is.na(thisFstGeno) == TRUE)]}
          if(sum(is.na(thisSecGeno)) > 0) {thisSecGeno[which(is.na(thisSecGeno) == TRUE)] <- thisFstGeno[which(is.na(thisSecGeno) == TRUE)]}
          if(length(thisFstGeno) != length(thisSecGeno)) {print(paste("error on chromsome",k,sep=  " "))}
          chromeOneGeno <- c(chromeOneGeno,thisFstGeno)
          chromeTwoGeno <- c(chromeTwoGeno,thisSecGeno)
        }
        chromeOneGeno<- c(theseInds[j],chromeOneGeno)
        chromeTwoGeno<- c(theseInds[j],chromeTwoGeno)
        offGenoMat1 [j,] <- chromeOneGeno
        offGenoMat2 [j,] <- chromeTwoGeno
      }
      newGenoRow <- which(is.na(genoMat1[,2]))[1]  # which row to start adding new genotypes
      genoMat1[newGenoRow:(newGenoRow + nrow(offGenoMat1) - 1),] <- offGenoMat1
      genoMat2[newGenoRow:(newGenoRow + nrow(offGenoMat2) - 1),] <- offGenoMat2
    } # if statement checking for > 0 offspring in generation i
    print(paste("done with generation ",i,sep=""))
    if(extinct == TRUE){print(paste("population extinct at generation ",i,sep=""))}
    i <- i + 1
  }
  if(length(indTraitVal) < nrow(pedObject)) {indTraitVal <- c(indTraitVal,rep(NA,nrow(pedObject) - length(indTraitVal)))}
  genoMat1 <- genoMat1[which(is.na(genoMat1[,1]) == FALSE),]
  genoMat2 <- genoMat2[which(is.na(genoMat2[,1]) == FALSE),]

  ###########################################
  # calculate the SNP mapping positions
  ###########################################
  chromPhysPos <- NULL
  chromMapPos <- NULL
  for (k in 1:chrNum){
    thesePos  <- snpMat [which(snpMat[,1] == k),2]   # positions of the loci on this chromosome
    chromPhysPos <- c(chromPhysPos,thesePos)
    #### calculate the genetic mapping positions of loci on this chromosome
    if(is.null(map) == FALSE){
      thisChrMap <- mapFile[which(mapFile[,1] == k),]
      thisMapPos <- rep(NA,length(thesePos))
      prevRows <- rep(NA,length(thesePos))
      for(n in 1:length(thisMapPos)){
        prevRows [n] <- which(thisChrMap[,2] < thesePos[n])[length(which(thisChrMap[,2] < thesePos[n]))]
      }
      thisMapPos <- thisChrMap[prevRows,3] + thisChrMap[prevRows,4]* (thesePos-thisChrMap[prevRows,2])
    }
    if(is.null(map) == TRUE){thisMapPos <- (thesePos/physLengs[k]) * chrLengs[k]}
    chromMapPos <- c(chromMapPos,thisMapPos)
  }

  #################################################
  # calculate individual heterozygosity
  #################################################
  hetMat <- genoMat1[,2:ncol(genoMat1)] != genoMat2[,2:ncol(genoMat2)]
  het <- rowSums(hetMat)/ncol(hetMat)

  ################################################################
  # calculate pedigree inbreeding coefficients
  ################################################################
  #kins <- kinship2::kinship(id=pedObject[,1],dadid=pedObject[,3],momid=pedObject[,2])
  pedF <- rep(NA,nrow(pedObject))
  #nonImms <- which(is.na(pedObject[,2]) == FALSE)
  #for( k in 1:length(nonImms)){
  #  pedF [nonImms[k]]<- kins[which(pedObject[,1] == pedObject[nonImms[k],2]),which(pedObject[,1] == pedObject[nonImms[k],3])]
  #}
  pedObject <- cbind(pedObject,pedF,het)

  ###############################################################################
  # save the chromosome segment origins for each individual on each chromosome
  ###############################################################################
  segLengs <- NULL   # calculate the maximim length among vectors of junction locations
  for (i in 1:chrNum){
    thisChr1 <- fstJuncList[[i]]
    thisChr2 <- secJuncList[[i]]
    fstJuncNum <- rep(NA,length(thisChr1))
    secJuncNum <- rep(NA,length(thisChr2))
    for(j in 1:length(thisChr1)){
      fstJuncNum [j] <- length(thisChr1[[j]])
      secJuncNum [j] <- length(thisChr2[[j]])
    }
    segLengs <- c(segLengs,fstJuncNum,secJuncNum)
  }
  juncMat1  <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  juncMat2  <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  hapIDMat1 <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  hapIDMat2 <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  rowIter <- 1 # iterate destination rows
  indIDs <- pedObject[,1]
  idVec <- NULL
  for(i in 1:length(indIDs)){
    for(j in 1:chrNum){
      juncMat1[rowIter,1:length(fstJuncList[[j]][[i]])] <- fstJuncList[[j]][[i]]
      juncMat2[rowIter,1:length(secJuncList[[j]][[i]])] <- secJuncList[[j]][[i]]

      hapIDMat1[rowIter,1:length(fstChrOrigList[[j]][[i]])] <- fstChrOrigList[[j]][[i]]
      hapIDMat2[rowIter,1:length(secChrOrigList[[j]][[i]])] <- secChrOrigList[[j]][[i]]
      rowIter <- rowIter + 1
    }
    idVec <- c(idVec,rep(indIDs[i],chrNum))
  }
  chrVec <- rep(1:chrNum,length(indIDs))
  juncMat1 <- cbind(idVec,chrVec,juncMat1)
  juncMat2 <- cbind(idVec,chrVec,juncMat2)
  hapIDMat1 <- cbind(idVec,chrVec,hapIDMat1)
  hapIDMat2 <- cbind(idVec,chrVec,hapIDMat2)
  genoMat <- matrix(NA,nrow=simLociNum,ncol=nrow(pedObject)*2)
  fstCols <- seq(1,ncol(genoMat),2)
  for(n in 1:length(fstCols)){
    genoMat[,fstCols[n]]   <- genoMat1[n,2:ncol(genoMat1)]
    genoMat[,fstCols[n]+1] <- genoMat2[n,2:ncol(genoMat2)]
  }
  genoMat <- cbind(chromID,chromMapPos,chromPhysPos,genoMat)
  genoColNames <- c("chromID","chromMapPos","chromPhysPos",rep(NA,nrow(pedObject)*2))  # names for genoMat columns
  genoColNames[seq(4,ncol(genoMat),2)] <- paste(pedObject[,1],"_1",sep="")
  genoColNames[seq(5,ncol(genoMat),2)] <- paste(pedObject[,1],"_2",sep="")
  colnames(genoMat) <- genoColNames
  allFreqMat <- cbind(1:gens,allFreqMat)
  colnames(allFreqMat) <- c("gens",paste("l_",(1:simLociNum),sep=""))

  #### add allele frequencies and SNP positions to qtlInfo
  qtlChrs <- genoMat[qtlInfo[,1],1]
  qtlPhysPos <- genoMat[qtlInfo[,1],3]
  qtlFreqs <- NULL
  for(j in 1:nrow(qtlInfo)){
    qtlFreqs <- rbind(qtlFreqs,allFreqMat[,qtlInfo[j,1]+1])
  }
  qtlInfo <- cbind(qtlInfo,qtlChrs,qtlPhysPos,qtlFreqs[,(burnin+1):(ncol(qtlFreqs))])

  colnames(qtlInfo)[6:ncol(qtlInfo)] <- paste("gen",(burnin+1):(ncol(qtlFreqs)),sep="")

  #### make a vector of yearly population sizes
  outGens <- unique(pedObject[,4])
  NVec <- rep(NA,length(outGens))
  for( i in 1:length(outGens)){
    NVec [i] <- sum(pedObject[,4] == i)
  }

  #### trim NAs from output files
  allFreqMat <- allFreqMat[which(is.na(allFreqMat[,2]) == FALSE),]
  qtlInfo <- qtlInfo[,which(is.na(qtlInfo[1,]) == FALSE)]

  #### outputs
  NVec <<- NVec
  pedObject <<- cbind(pedObject,indTraitVal)
  juncMat1 <<- juncMat1
  juncMat2 <<- juncMat2
  hapIDMat1 <<- hapIDMat1
  hapIDMat2 <<- hapIDMat2
  genoMat <<- genoMat
  quantTraitDat <<- cbind((burnin+1):gens,VaVec,VpVec,h2Vec,traitMean,sVec) # store information on the location and effect size and direction of each QTL
  allFreqMat <<- allFreqMat[2:nrow(allFreqMat),]
  qtlInfo <<- qtlInfo
  print("**********simulation done**********")
}
