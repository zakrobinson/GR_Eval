#' A function to simulate hybridization
#'
#' This function runs a forward-time spatially and genomically explicit simulation of hybridization in a
#'     two-dimensional habitat.
#' @param habSize numeric. The length and width of the square-shaped habitat (in kilometers)
#' @param popSize numeric. The size of the population occupying the habitat
#' @param ages numeric. The ages of individuals in the population. Starting with 0 for young-of-the-year
#' @param ageMaturity numeric. The age at which an individual is capable of reproducing
#' @param ageStruc numeric. A vector giving the proportion of the population in each of the age
#'     classes. Must sum to one.
#' @param meanDispDist numeric. Mean dispersal distance of one year olds (only one year olds are allowed to disperse and establish a home range)
#' @param matingDistRate numeric. Exponential rate of decline with increasing distance in the probability of a female selecting
#'     a male as a mate. Females are more likely mate with close-by males.
#' @param repro_d numeric. The dominance of immigrant alleles over native alleles (0 = no dominance; 1 = complete dominance).
#' @param surv_d numeric. The dominance of immigrant alleles over native alleles for survival (0 = no dominance; 1 = complete dominance).
#' @param numSelecLoci numeric. The number of loci in the genome that affect fitness. The same loci affect survival and reproduction
#' @param invRelSurv numeric. Signed difference in survival of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-native are more fit compared to natives. Negative
#'     values mean that non-natives are less fit than natives.
#' @param invRelRepro numeric. Signed difference in female fedundity of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-native are more fit compared to natives. Negative
#'     values mean that non-natives are less fit than natives.
#' @param F1Heterosis logical. TRUE if F1 hybrids are to have the same fitness as pure native individuals, FALSE otherwise. Must be FALSE when
#'     invRelSurv and/or invRelRepro are positive
#' @param assortWeight numeric. The strength of positive assortative mating. Must range from 0 to 1. 1 means complete
#'     assortative mating (pure non-natives and pure natives will never mate), 0 means no assorative mating.
#' @param stockYears numeric. Vector giving the years in the simulation that non-native individuals will be planted in the habitat.
#' @param stockAge numeric. The age of non-native indiviudals that will be planted in the system.
#' @param stockNum numeric. The number of individuals that will be planted in the habitat. Must be >= 0 and an even number.
#' @param stockLoc numeric. Vector with first element defining the X-coordinate of introduction, and the second
#'     element defining the Y-coordinate of introduction of non-natives.
#' @param nChromLoci numeric. The number of evenly spaced ancestry informative loci to place on each chromosome.
#' @param chroms numeric. The number of chromosomes to simulate.
#' @param mapLeng numeric. The genetic map length of each chromosome (in centi-Morgans)
#' @param runTime numeric. The number of years to run the simulation.
#' @details
#'    The output from this function is a list with five elements. First element is a data frame with the following columns: Individual identification number,
#'    population number, age, the hybrid index (fraction of genome that is non-native), sex, the hybrid index at fitness
#'    loci, the location of the individual on the x-axis, the location on the y-axis, mother, father, and year. Only individuals
#'    that survived the first year are included. Every individual in the population is represented for each year; for example, an individual
#'    that was born in year 5 and died in year 7 will be represented in three rows (one for each of years 5-7).
#'
#'    The second element contains the genotypes of all individuals in 012 format. The first column is the individual identification number. The
#'    remaining columns are genotypes given as the number of non-native alleles at each locus in the genome. Loci are ordered left to right,
#'    starting with the first locus on chromosome 1, and so on.
#'
#'    The third element is a data frame containing the genotypes at "AT" format. T is the non-native allele and A is the native allele at each locus. The
#'    first column is the individual identification number. The remaining columns are individual genotypes, ordered from left to right, beginning
#'    with the first locus on chromosome one. Each locus is represented by two columns, such that the total number of columns is two times the number
#'    of loci plus one.
#'
#'    The fourth element is a vector giving the chromosome locations of fitness loci.
#'
#'    The fifth element is a vector giving the location of each fitness locus in centiMorgans.
#' @examples
#'     # load the package
#'     library(admixr)
#'     # simulate a population of 1000 individuals for five years. 20 non-native juveniles enter the habitat every year.
#'     admixTry <- admix2D(habSize=100,popSize=1000,ages=c(0,1,2,3,4),ageMaturity=2,ageStruc=c(0.5,0.2,0.1,0.1,0.1),meanDispDist=4,
#'     matingDistRate = 0.2,repro_d=0.9,surv_d=0.9,numSelecLoci=10,invRelSurv=0,invRelRepro=1.5,F1Heterosis=FALSE,assortWeight=0.2,
#'     stockYears=1:50,stockAge=0,stockNum=20,stockLoc=c(50,50),nChromLoci=100,chroms=5,mapLeng=50,runTime=5)
#'     # plot results from the last simulated year
#'     plot2D(admixDat = admixTry,habSize = 100,yearPlot = 5)
#' @export


admix2D <- function (habSize,popSize,ages,ageMaturity,ageStruc,meanDispDist,matingDistRate,
                     repro_d,surv_d,numSelecLoci,invRelSurv,invRelRepro,F1Heterosis,assortWeight,
                     stockYears,stockAge,stockNum,stockLoc,nChromLoci,chroms,mapLeng,runTime)
{

  if ((stockNum %% 2 == 0) == FALSE) {stop("stockNum must be even and >= 0")}
  if (F1Heterosis == TRUE & (invRelSurv > 0 | invRelRepro > 0)) {stop("F1Heterosis must be FALSE when survival and/or reproduction is higher for non-natives than for natives")}

  ################################################################
  # populate the network with genetically pure native individuals
  ################################################################

  age <- NULL
  for (i in 1:length(ages)){
    age <- c(age,rep(ages[i],ageStruc[i]*popSize))
  }

  ageVec <- age

  id <- 1:length(ageVec)

  pop <- rep(1,length(id))
  percRBT <- rep(0,length(pop))       # hybrid index (non-native fraction of the genome), initialized at zero for all native individuals
  sex <- rep(c(0,1),length(pop)/2)
  selecPercRBT <- rep(0,length(pop))  # hybrid index at the loci responsible for outbreeding depression

  ################################################################
  # assign location of each individual on a 2-dimensional surface
  ################################################################

  xLoc <- runif(n=length(id),min=0,max=habSize) # random x coordinate
  yLoc <- runif(n=length(id),min=0,max=habSize) # random y coordinate
  mom <- rep(NA,length(xLoc))
  dad <- rep(NA,length(xLoc))
  yearVec <- rep(0,length(dad))
  allPopMat <- cbind(id,pop,age,percRBT,sex,selecPercRBT,xLoc,yLoc,mom,dad,yearVec)# matrix to store all of the population data throughout the simulation
  popMat <- allPopMat # matrix to store the individuals that are in the population currently


  ###########################################
  # initialize the genome matrices
  ###########################################

  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  for(i in 1:chroms){
    chr1List [[i]]<- cbind(allPopMat[,1],matrix(1,nrow=nrow(allPopMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
    chr2List [[i]]<- cbind(allPopMat[,1],matrix(1,nrow=nrow(allPopMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
  }

  allChr1 <- chr1List     # save the genotypes of all individuals
  allChr2 <- chr2List

  selecLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  selecChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression

  selecChrs <- sort(sample(1:chroms,numSelecLoci,replace=TRUE))
  selecLoci <- NULL
  uniChrs <- unique(selecChrs)
  for(i in 1:length(uniChrs)){
    selecLoci <- c(selecLoci,sort(sample(1:nChromLoci,sum(selecChrs == uniChrs[i]),replace=FALSE)))
  }

  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat <- rbind(selecChrMat,selecChrs)

  ############################################################
  # run the simulation
  ############################################################
  maxID <- max(allPopMat[,1])

  for (i in 1:runTime){

    ##################################################
    # dispersal of juveniles
    ##################################################

    juvies <- NULL
    juvies <- which (popMat[,3] == 0)

    juvHybInds <- NULL      # hybrid indices of the juvies
    juvHybInds <- popMat[juvies,4]

    juvXLoc <- popMat[juvies,7] # location of each juvie in the 2D space
    juvYLoc <- popMat[juvies,8]

    expRate <- 1/meanDispDist    # exponential rate of decline in dispersal probability with distance

    ###############################################
    # assign new X and Y location for each juvenile
    ###############################################

    newX <- rep(NA,length(juvXLoc))
    newY <- rep(NA,length(juvYLoc))
    candX <- seq(0,habSize,habSize/5000)    # all possible new locations
    candY <- seq(0,habSize,habSize/5000)

    for(j in 1:length(newX)){
      newX [j] <- sample(candX,1,prob=dexp(abs(candX-juvXLoc[j]),rate=expRate))
      newY [j] <- sample(candY,1,prob=dexp(abs(candY-juvYLoc[j]),rate=expRate))
    }

    popMat[juvies,7] <- newX
    popMat[juvies,8] <- newY

    ##################################
    # Introduce non-native individuals
    ##################################

    if(i %in% stockYears){
      stockIDs <- (maxID+1):(stockNum + maxID) # ids of the stocked individuals
      maxID <- max(stockIDs)
      stockPop <- rep(1,length(stockIDs))

      stockAges <- rep(stockAge,length(stockIDs))    # age of introduced non-native individuals
      stockSex <- rep(c(0,1),length(stockAges)/2)    # sex of introduced individuals
      stockRBT <- rep(1,length(stockIDs))            # all introduced non-natives have a hybrid index of 1
      stockSelecRBT <- rep(1,length(stockIDs))

      ##################################
      # disperse the stocked individuals
      ##################################

      candX <- seq(0,habSize,habSize/5000)    # all possible new locations for stocked individuals
      candY <- seq(0,habSize,habSize/5000)

      newStockX <- sample(candX,length(stockIDs),prob=dexp(abs(candX-stockLoc[1]),rate=expRate))
      newStockY <- sample(candY,length(stockIDs),prob=dexp(abs(candX-stockLoc[2]),rate=expRate))
      stockMom <- rep(NA,length(stockIDs))
      stockDad <- rep(NA,length(stockIDs))
      year <- rep(i,length(stockIDs))
      stockMat <- cbind(stockIDs,stockPop,stockAge,stockRBT,stockSex,stockSelecRBT,newStockX,newStockY,stockMom,stockDad,year)
      colnames(stockMat) <- NULL
      popMat <- rbind(popMat,stockMat)
    }

    for(j in 1:length(chr1List)){
      chr1List[[j]] <- rbind(chr1List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))  # add genomic data for introduced non-natives
      chr2List[[j]] <- rbind(chr2List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))
    }

    ########
    # mating
    ########

    offspring <- NULL # matrix to store the new offspring demographic data (i.e., hybrid index, parents, etc.)
    offChr1 <- list() #list of length 'chroms' storing the maternal chromosome copies
    offChr2 <- list() #list of length 'chroms' storing the paternal chromosome copies
    numOffs <- ageStruc[1]*popSize           # total number of offspring to produce for EACH population

    thisDat <- NULL
    thisDat <- popMat

    matFems <- NULL      # mature females
    pickFemales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 0)
    matFems <- thisDat[pickFemales,1]
    matFemHybInd <- NULL
    matFemHybInd <- thisDat[pickFemales,6]       # female hybrid indices at the loci affecting fitness

    candMales <- NULL # males that are mature and could breed
    candMales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 1)
    maleHybInd <- NULL # hybrid indices of all candidate fathers
    maleHybInd <- thisDat[candMales,4]   # hybrid indices of males (at all loci) that are mature and could breed
    maleLocs <- thisDat[candMales,7:8]
    matFemLocs <- thisDat[pickFemales,7:8]
    #### pick males for the females to breed with.... Onle one male per female. Males can mate with multiple females

    pickMales <- rep(NA,length(matFems))
    for (v in 1:length(matFems)){
      femLoc <- matFemLocs[v,]                     # calculate the distance from the focal female to each of the males
      toMaleDist <- rep(NA,length(candMales))

      for(j in 1:length(toMaleDist)){
        maleLoc <- maleLocs[j,]
        toMaleDist[j] <- sqrt((femLoc[1]-maleLoc[1])^2+(femLoc[2]-maleLoc[2])^2)
      }

      distWeights <- dexp(toMaleDist,rate=matingDistRate)
      pickMales [v] <- sample(candMales,size=1,prob= (1 - abs(matFemHybInd[v] - maleHybInd)*assortWeight)*distWeights,replace=FALSE)
    }

    matMales <- NULL     # mature males
    matMales <- thisDat[pickMales,1]  # males that will be paired with females
    matMaleHybInd <- NULL
    matMaleHybInd <- thisDat[pickMales,4]

    # make offspring
    matePairs <- NULL
    matePairs <- cbind(matFems,matFemHybInd,matMales,matMaleHybInd)     # pairs of candidate parents

    femSelecGenos1 <- NULL    # femaile genotypes at loci affecting fitness
    femSelecGenos2 <- NULL    # femaile genotypes at loci affecting fitness
    for(z in 1:length(selecChrs)){
      femSelecGenos1 <- cbind(femSelecGenos1,chr1List[[selecChrs[z]]][match(matFems,chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      femSelecGenos2 <- cbind(femSelecGenos2,chr2List[[selecChrs[z]]][match(matFems,chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
    }

    femSelecGenos <- 2 - (femSelecGenos1 + femSelecGenos2)    # this is the number of non-native alleles each female has at each selected locus
    locusEffSize <- ((invRelRepro)/numSelecLoci)/2        # additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)

    genValMat <- matrix(0,nrow(femSelecGenos),ncol(femSelecGenos)) # matrix to store the genetic trait effects for each individual and each selected locus

    for(z in 1:ncol(femSelecGenos)){
      if(sum(femSelecGenos[,z] == 1) > 0){genValMat [which(femSelecGenos[,z] == 1),z] <- femSelecGenos [which(femSelecGenos[,z] == 1),z] * locusEffSize *(1 + repro_d)} #genetic value of heterozygoges, accounting for dominance
      if(sum(femSelecGenos[,z] == 2) > 0){genValMat [which(femSelecGenos[,z] == 2),z] <- femSelecGenos [which(femSelecGenos[,z] == 2),z] * locusEffSize}
    }

    femWeights <- NULL
    femWeights <-  1 + rowSums(genValMat)

    if(F1Heterosis == 1){if(sum(matFemHybInd == 0.5) > 0){femWeights[which(matFemHybInd == 0.5)] <- 1}}  # F1s have the same fitness as pure natives

    parentPairs<- NULL                       # randomly selected parents of each offspring weighted by the hybrid index of the female
    parentPairs <- matePairs[sample(1:nrow(matePairs),size=numOffs,replace=TRUE,prob=femWeights),]

    fry <- NULL   # this years offspring
    fryIDs <- (maxID+1):(maxID+numOffs)    # IDs for the offspring
    maxID <- max(fryIDs)
    fryPop <- rep(1,length(fryIDs))
    fryAge <- rep(0,length(fryIDs))
    frySex <- rep(c(0,1),length(fryIDs)/2)
    fryLoc <- popMat[match(parentPairs[,1],popMat[,1]),7:8]
    fryMoms <- parentPairs[,1]
    fryDads <- parentPairs[,3]

    #######################################################
    # calculate the genomic hybrid index of each offspring
    #######################################################

    #### meiosis

    nonNatAllsMom <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
    nonNatAllsDad <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual

    for(k in 1:chroms){
      momsCopy1 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],popMat[,1]),])
      dadsCopy1 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],popMat[,1]),])

      momsCopy2 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], popMat[,1]),])
      dadsCopy2 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], popMat[,1]),])

      momRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
      dadRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the dad

      fryChromOnes <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
      fryChromTwos <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))

      for(l in 1:nrow(fryChromOnes)){
        # maternal chromosome

        momStartChrom <- sample(c(1,2),1)
        momChrom <- NULL

        momRecLocs <- c(sort(sample(1:(nChromLoci-1),momRecs[l],replace=FALSE)),nChromLoci)
        if(length(momRecLocs)>1){
          momBeginLocs <- c(1,momRecLocs[1:(length(momRecLocs)-1)] + 1)
          momBeginLocs [length(momBeginLocs)] <-c(momRecLocs[length(momRecLocs)-1]+1)
        }

        if(length(momRecLocs) == 1){
          momBeginLocs <- 1
        }

        if(momStartChrom == 1){
          for(m in 1:length(momRecLocs)){
            if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
          }
        }

        if(momStartChrom == 2){
          for(m in 1:length(momRecLocs)){
            if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
          }
        }

        fryChromOnes [l,2:ncol(fryChromOnes)] <- momChrom
        # paternal chromosome

        dadStartChrom <- sample(c(1,2),1)
        dadChrom <- NULL

        dadRecLocs <- c(sort(sample(1:(nChromLoci-1),dadRecs[l],replace=FALSE)),nChromLoci)

        if(length(dadRecLocs)>1){
          dadBeginLocs <- c(1,dadRecLocs[1:(length(dadRecLocs)-1)] + 1)
          dadBeginLocs [length(dadBeginLocs)] <-c(dadRecLocs[length(dadRecLocs)-1]+1)
        }

        if(length(dadRecLocs) == 1){
          dadBeginLocs <- 1
        }

        if(dadStartChrom == 1){
          for(m in 1:length(dadRecLocs)){
            if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
          }
        }

        if(dadStartChrom == 2){
          for(m in 1:length(dadRecLocs)){
            if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
          }
        }
        fryChromTwos[l,2:ncol(fryChromTwos)] <- dadChrom
      }

      offChr1[[k]] <- fryChromOnes
      offChr2[[k]] <- fryChromTwos

      nonNatAllsMom <- cbind(nonNatAllsMom,rowSums(fryChromOnes[,2:ncol(fryChromOnes)] == 0))
      nonNatAllsDad <- cbind(nonNatAllsDad,rowSums(fryChromTwos[,2:ncol(fryChromTwos)] == 0))
    }

    fryPercRBT <- rowSums(cbind(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry

    fryOut <- cbind(fryIDs,fryPop,fryAge,fryPercRBT,frySex,fryLoc,fryMoms,fryDads,rep(i,length(fryIDs)))
    colnames(fryOut) <- NULL
    offspring <- rbind(offspring,fryOut)

    ###########################################
    # get the hybrid index at fitness loci
    ###########################################

    selecPercRBT <- rep(NA,length(fryPercRBT))
    selecGenos <- NULL

    for(z in 1:length(selecChrs)){
      selecGenos <- cbind(selecGenos,offChr1[[selecChrs[z]]][,selecLoci[z]+1],offChr2[[selecChrs[z]]][,selecLoci[z]+1])
    }
    selecPercRBT <- 1 - rowSums(selecGenos)/ncol(selecGenos)
    offspring <- cbind(offspring[,1:5],selecPercRBT,offspring[,6:10])

    ##################################################
    # advance the population to the next year
    ##################################################

    newPop <- NULL          # temporarily store the new population data
    keepIndices <- NULL    # vector of the IDs of individuals surviving to the next year

    #thisDat <- NULL
    #thisDat <- popMat
    for (k in 1:(length(ageStruc)-1)){       # select individuals in each age class to survive to the next year (all individuals in the last age class die)
      ageDat <- NULL
      ageDat <- popMat[which(popMat[,3] == ages[k]),] # individuals in age class k for the jth population
      ageSelecGenos1 <- NULL    # genotypes of individuals in the kth age class at fitness loci
      ageSelecGenos2 <- NULL

      for(z in 1:length(selecChrs)){
        ageSelecGenos1 <- cbind(ageSelecGenos1,chr1List[[selecChrs[z]]][match(ageDat[,1],chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        ageSelecGenos2 <- cbind(ageSelecGenos2,chr2List[[selecChrs[z]]][match(ageDat[,1],chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      }

      ageSelecGenos <- 2 - (ageSelecGenos1 + ageSelecGenos2)    # number of non-native alleles each age[k] individual has at each selected locus
      locusEffSize <- ((invRelSurv)/numSelecLoci)/2             # additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)

      genValMat <- matrix(0,nrow(ageSelecGenos),ncol(ageSelecGenos)) # matrix to store the genetic trait effects for each individual and each selected locus

      for(z in 1:ncol(ageSelecGenos)){
        if(sum(ageSelecGenos[,z] == 1) > 0){genValMat [which(ageSelecGenos[,z] == 1),z] <- ageSelecGenos [which(ageSelecGenos[,z] == 1),z] * locusEffSize *(1 + surv_d)} #genetic value of heterozygoges, accounting for dominance
        if(sum(ageSelecGenos[,z] == 2) > 0){genValMat [which(ageSelecGenos[,z] == 2),z] <- ageSelecGenos [which(ageSelecGenos[,z] == 2),z] * locusEffSize}
      }
      survWeights <-  1 + rowSums(genValMat)
      keepIds <- NULL
      keepIds <- sample(ageDat[,1],size=ageStruc[k+1]*popSize,replace=FALSE,prob = survWeights)
      keepIndices <- append(keepIndices,which(popMat[,1] %in% keepIds))
    }

    keepIndices <- sort(keepIndices)
    newPop <- popMat[keepIndices,]
    newPop[,3] <- newPop[,3] + 1
    newPop <- rbind(newPop,offspring) # the new population

    ##################################################################################
    # update the genetic data to contain only the individuals passing to the next year
    ##################################################################################

    for(k in 1:length(chr1List)){
      chr1List[[k]] <- chr1List[[k]][keepIndices,]
      chr2List[[k]] <- chr2List[[k]][keepIndices,]

      chr1List[[k]] <- rbind(chr1List[[k]],offChr1[[k]])
      chr2List[[k]] <- rbind(chr2List[[k]],offChr2[[k]])
    }

    #######################################################
    # save the new genotypes from this year
    #######################################################

    newGenos <- which(chr1List[[1]][,1] %in% allChr1[[1]][,1] == FALSE)

    for(k in 1:length(chr1List)){
      allChr1[[k]] <- rbind(allChr1[[k]],chr1List[[k]][newGenos,])
      allChr2[[k]] <- rbind(allChr2[[k]],chr2List[[k]][newGenos,])

    }

    newPop[,ncol(newPop)] <- rep(i,nrow(newPop)) # update the year
    popMat <- newPop  # replace this year's population with the next

    ################################################
    # save the new individuals in allPopMat
    ################################################
    allPopMat <- rbind(allPopMat,newPop)
    print(paste("done with year", i))
  }


  #######################################################
  # format the genotypes
  #######################################################

  genos_012 <- NULL    # genotype file giving the count of native alleles at each locus for each individual
                       # individuals are in rows, loci are in columns (on column per locus)
  genoNames <- allChr1[[1]][,1]
  for(i in 1:length(chr2List)){
    genos_012 <- cbind(genos_012,allChr1[[i]][,2:ncol(allChr1[[i]])]+allChr2[[i]][,2:ncol(allChr2[[i]])])
  }


  fstAlls <- seq(from=1,to=2*ncol(genos_012),by=2)
  secAlls <- seq(from=2,to=2*ncol(genos_012),by=2)

  atMat <- matrix(NA,nrow=nrow(genos_012),ncol=ncol(genos_012)*2)   # genotype file with A = native allele, T = non-native allele
                                                                    # individuals are in rows, loci in columns (two adjacent columns
                                                                    # per locus); first column is individual ID


  for(i in 1:ncol(genos_012)){
    atMat[which(genos_012[,i] == 0),fstAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),fstAlls[i]] <- "A"
    atMat[which(genos_012[,i] == 2),fstAlls[i]] <- "A"

    atMat[which(genos_012[,i] == 0),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 2),secAlls[i]] <- "A"
  }
genos_012 <- cbind(genoNames,genos_012)
atMat <- cbind(genoNames,atMat)

admixRes <- list(allPopMat,genos_012,atMat,selecChrMat,selecLociMat)

return(admixRes)
}


