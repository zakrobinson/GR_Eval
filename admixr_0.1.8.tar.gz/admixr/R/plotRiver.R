#' A function to plot results from admixRiver simulations.
#'
#' This function plots hybrid indices of individuals simulated in a river system using the
#'     function admixRiver.
#' @param admixDat Output from the function admix2D.
#' @param mainStemLeng Length of the mainstem in kilometers
#' @param tribLeng Tributary length in kilometers
#' @param yearPlot The year of the simulation to include indivduals in the figure.
#' @details
#'     The output from this function is a plot showing the river system (mainstem, tributaries, and stocking site)
#'     and the geomic hybrid indices of each indiviudals the entire river system. Individuals are represented as colored vertical lines,
#'     with red representing the non-native fraction of the genome (the hybrid index), and gray representing the native fraction of the genome.
#'     Individuals with completey gray lines are pure native, and individuals with pure red lines are pure non-native.
#' @examples
#'     # load the package
#'     library(admixr)
#'     # simulate admixture in a river system
#'     tryRiver <- admixRiver(mainStemLeng=100,tribNum=10,tribLeng=10,lambda=0.05,popSize=200,nativeDispProb=0.05,maxDispProb=0.05,barrierLoc=0,
#'     nonNatThresh=0.5,ages=c(0,1,2),ageMaturity=1,ageStruc=c(0.5,0.25,0.25),repro_d=0,surv_d=0,numSelecLoci=10,invRelSurv=0,invRelRepro=0,
#'     F1Heterosis=0,assortWeight=0,stockYears=1:5,stockAge=0,stockNum=20,nChromLoci=100,chroms=4,mapLeng=50,runTime=10)
#'     # plot the results from year 10 of the simulation
#'     plotRiver(admixDat=tryRiver,mainStemLeng=100,tribLeng=10,yearPlot=10)
#' @export
plotRiver <- function(admixDat,mainStemLeng,tribLeng,yearPlot){
  popMat <- admixDat[[1]][which(admixDat[[1]][,9] == yearPlot & admixDat[[1]][,10] == 1 ),]
  tribNum <- length(unique(admixDat[[1]][,2]))
  confs <- seq(0,mainStemLeng,mainStemLeng/tribNum)[2:length(seq(0,mainStemLeng,mainStemLeng/tribNum))]
  tribSideLeng <- sqrt((tribLeng^2)/2)
  mainXStart <- 20
  tribXEnds <- rep(c(mainXStart-tribSideLeng,mainXStart+ tribSideLeng),tribNum)
  tribYEnds <- confs + tribSideLeng
  par(xpd=TRUE)
  plot(c(0,tribSideLeng*3),c(0,mainStemLeng + tribSideLeng*2),type="n",xlab="",
       ylab="",xlim=c(0,40),ylim=c(0,mainStemLeng + tribSideLeng*2),axes=FALSE)
  points(x=mainXStart,y=0,pch=15,col="black",cex=1.5)
  text(x=mainXStart,labels="Stocking Site",y=-10,cex=1.5)
  ### population labels
  lines(c(mainXStart,mainXStart),c(0,mainStemLeng))
  text(x=mainXStart,y=mainStemLeng + 0.2*mainStemLeng,labels = paste("Year ", yearPlot,sep=""),cex=1.5)
  for(i in 1:tribNum){
    lines(c(mainXStart,tribXEnds[i]),c(confs[i],tribYEnds[i]))
     hybInds <- sort(popMat[which(popMat[,2] == i),4])
     popSize <- nrow(popMat[which(popMat[,2] == i),])
    if(i %in% seq(1,500,2)){xSpots <- seq(tribXEnds[i]-11,tribXEnds[i]-1,10/popSize)}
    if(i %in% seq(2,500,2)){xSpots <- seq(tribXEnds[i]+1,tribXEnds[i]+11,10/popSize)}
    yBots <- tribYEnds[i] - 5
    yTops <- tribYEnds[i] + 5
    for(j in 1:length(hybInds)){
      if (hybInds[j] == 0){  lines(x=c(xSpots[j],xSpots[j]),y=c(yBots,yTops),col="darkgray",lwd=0.5)}
      if (hybInds[j] == 1){  lines(x=c(xSpots[j],xSpots[j]),y=c(yBots,yTops),col="darkred",lwd=0.5)}
      if(hybInds[j] > 0 & hybInds[j] < 1){
       lines(x=c(xSpots[j],xSpots[j]),y=c(yBots,yBots+(1-hybInds[j])*(yTops-yBots)),col="darkgray",lwd=0.5)
       lines(x=c(xSpots[j],xSpots[j]),y=c(yBots+(1-hybInds[j])*(yTops-yBots),yTops),col="darkred",lwd=0.5)
      }
    }
  }
}



