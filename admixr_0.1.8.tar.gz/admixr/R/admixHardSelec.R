#' A function to simulate hybridization with hard selection
#'
#' This function runs a forward-time, genomically explicit simulation of hybridization with hard selection
#' @param popSize numeric. The size of the population occupying the habitat
#' @param repro_d numeric. The dominance of immigrant alleles over native alleles (0 = no dominance; 1 = complete dominance).
#' @param surv_d numeric. The dominance of immigrant alleles over native alleles for survival (0 = no dominance; 1 = complete dominance).
#' @param numSelecLoci numeric. The number of loci in the genome that affect fitness. The same loci affect survival and reproduction
#' @param genoImportNative An object containing imported genotypes of native founders in the simulation. These can be from empirical data or from simulations.
#' @param genoImportImm An object containing imported genotypes of immigrants in the simulation. These can be from empirical data or from simulations.
#' @param invRelSurv numeric. Signed proportional difference in survival of pure non-natives compared to pure natives.
#'     This is equivalent to soft selection. Positive values mean non-native are more fit compared to natives. Negative
#'     values mean that non-natives are less fit than natives.
#' @param invRelRepro numeric. Signed proportional difference in female fedundity of pure non-natives compared to pure natives.
#'     Positive values mean non-native are more fit compared to natives. Negative
#'     values mean that non-natives are less fit than natives.
#' @param F1Heterosis 1 if you want F1s to have the same fitness as the most fit of pure natives or non-natives, 0 otherwise
#' @param assortWeight numeric. The strength of positive assortative mating. Must range from 0 to 1. 1 means complete
#'     assortative mating (pure non-natives and pure natives will never mate), 0 means no assorative mating.
#' @param stockYears numeric. Vector giving the years in the simulation that non-native individuals will be planted in the habitat.
#' @param stockNum numeric. The number of individuals that will be planted in the habitat. Must be >= 0 and an even number.
#' @param nChromLoci numeric. The number of evenly spaced ancestry informative loci to place on each chromosome.
#' @param genoImport Vector giving the names of objects storing genotypes of the native founders (1st element), and of non-native immigrants (2nd element). Set to
#'     NULL if not importing genotypes.
#' @param chroms numeric. The number of chromosomes to simulate.
#' @param mapLeng numeric. The genetic map length of each chromosome (in centi-Morgans)
#' @param runTime numeric. The number of years to run the simulation.
#' @param famSize numeric. The mean and variance of the number of offspring produced by a pure native mother in the absence of density dependence
#' @param survProbs numeric. The survival probability (to reproductive age) of a pure native juvenile in the absence of density dependence.
#' @param carryCap numeric. The carrying capacity of the habitat.
#' @details
#'    The output from this function is a list with five elements. First element is a data frame with the following columns: Individual identification number,
#'    population number, age, the hybrid index (fraction of genome that is non-native), sex, the hybrid index at fitness
#'    loci, mother, father, and year. Only individuals
#'    that survived the first year are included. Every individual in the population is represented for each year; for example, an individual
#'    that was born in year 5 and died in year 7 will be represented in three rows (one for each of years 5-7).
#'
#'    The second element contains the genotypes of all individuals in 012 format. The first column is the individual identification number. The
#'    remaining columns are genotypes given as the number of non-native alleles at each locus in the genome. Loci are ordered left to right,
#'    starting with the first locus on chromosome 1, and so on.
#'
#'    The third element is a data frame containing the genotypes at "AT" format. T is the non-native allele and A is the native allele at each locus. The
#'    first column is the individual identification number. The remaining columns are individual genotypes, ordered from left to right, beginning
#'    with the first locus on chromosome one. Each locus is represented by two columns, such that the total number of columns is two times the number
#'    of loci plus one.
#'
#'    The fourth element is a vector giving the chromosome locations of fitness loci.
#'
#'    The fifth element is a vector giving the location of each fitness locus in centiMorgans.
#' @examples
#'     # load the package
#'     library(admixr)
#'     # simulate a population of 1000 individuals for five years. 20 non-native juveniles enter the habitat every year.
#'     admixTry <- admixHardSelec(popSize=200,repro_d=0,surv_d=0,numSelecLoci=nLoci*nChroms,genoImportNative = smPopOutGenos,genoImportImm = bigPopOutGenos,
#'     invRelSurv= survSelec,invRelRepro= reproSelec,F1Heterosis = 0,assortWeight=0,stockYears=yearsImm,stockNum=indsImm,nChromLoci=nLoci,
#'           chroms=nChroms,mapLeng=100,runTime=yearsAdmixSim,famSize=4,survProbs=0.8,carryCap=300)
#'     # plot results from the last simulated year
#'     plot2D(admixDat = admixTry,habSize = 100,yearPlot = 5)
#' @export

admixHardSelec <- function (popSize,repro_d,surv_d,numSelecLoci,genoImportNative,genoImportImm,invRelSurv,invRelRepro,F1Heterosis,assortWeight,
                            stockYears,stockNum,nChromLoci,chroms,mapLeng,runTime,famSize,survProbs,carryCap){
  if ((stockNum %% 2 == 0) == FALSE) {stop("stockNum must be even and >= 0")}
  ################################################################
  # populate the network with genetically pure native individuals
  ################################################################
  ageVec <- rep(1,popSize)
  id <- 1:length(ageVec)
  pop <- rep(1,length(id))
  percRBT <- rep(0,length(pop))       # hybrid index (non-native fraction of the genome), initialized at zero for all native individuals
  sex <- rep(c(0,1),length(pop)/2 +5)[1:length(id)]
  selecPercRBT <- rep(0,length(pop))  # hybrid index at the loci responsible for outbreeding depression

  ################################################################
  # assign location of each individual on a 2-dimensional surface
  ################################################################
  mom <- rep(NA,length(id))
  dad <- rep(NA,length(id))
  yearVec <- rep(0,length(dad))
  age <- rep(1,length(mom))
  allPopMat <- cbind(id,pop,age,percRBT,sex,selecPercRBT,mom,dad,yearVec)# matrix to store all of the population data throughout the simulation

  popMat <- allPopMat # matrix to store the individuals that are in the population currently

  ###########################################
  # initialize the genome matrices
  ###########################################
  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  for(i in 1:chroms){
    chr1List [[i]]<- cbind(allPopMat[,1],matrix(1,nrow=nrow(allPopMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
    chr2List [[i]]<- cbind(allPopMat[,1],matrix(1,nrow=nrow(allPopMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
  }
  allChr1 <- chr1List     # save the genotypes of all individuals
  allChr2 <- chr2List

  ##############################################################
  # import genotypes for natives and non-natives
  ##############################################################
  if(is.null(genoImportNative) == FALSE){
    impChr1List <- list()
    impChr2List <- list()
    impImmChr1List<- list()
    impImmChr2List<- list()
    fstAlleleCols <- seq(4,ncol(genoImportNative),2)
    secAlleleCols <- seq(5,ncol(genoImportNative),2)
    fstAlleleColsImm <- seq(4,ncol(genoImportImm),2)
    secAlleleColsImm <- seq(5,ncol(genoImportImm),2)
    for(i in 1:chroms){
      impChr1List [[i]]<- cbind(allPopMat[,1],t(genoImportNative[which(as.numeric(genoImportNative[,1]) == i),fstAlleleCols]))
      impChr2List [[i]]<- cbind(allPopMat[,1],t(genoImportNative[which(as.numeric(genoImportNative[,1]) == i),secAlleleCols]))
      impImmChr1List [[i]]<- cbind(allPopMat[,1],t(genoImportImm[which(as.numeric(genoImportImm[,1]) == i),fstAlleleColsImm]))
      impImmChr2List [[i]]<- cbind(allPopMat[,1],t(genoImportImm[which(as.numeric(genoImportImm[,1]) == i),secAlleleColsImm]))
    }
    allChr1Poly <- impChr1List
    allChr2Poly <- impChr2List
  }

  #######################################################
  # assign loci affecting fitness
  #######################################################
  selecLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  selecChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression
  if(numSelecLoci != nChromLoci * chroms){
    selecChrs <- sort(sample(1:chroms,numSelecLoci,replace=TRUE))
    selecLoci <- NULL
    uniChrs <- unique(selecChrs)
    for(i in 1:length(uniChrs)){
      selecLoci <- c(selecLoci,sort(sample(1:nChromLoci,sum(selecChrs == uniChrs[i]),replace=FALSE)))
    }
    selecLociMat <- rbind(selecLociMat,selecLoci)
    selecChrMat <- rbind(selecChrMat,selecChrs)
  }
  if(numSelecLoci == nChromLoci * chroms){
    selecChrs <- NULL
    selecLoci <- NULL
    for(i in 1:chroms){
      selecLoci <- c(selecLoci,1:nChromLoci)
      selecChrs <- c(selecChrs,rep(i,nChromLoci))
    }
    selecLociMat <- rbind(selecLociMat,selecLoci)
    selecChrMat <- rbind(selecChrMat,selecChrs)
  }

  #### Estimate Fst between source and receiving populations if you have imported genotypes
  if(is.null(genoImportNative) == FALSE){
    # get Wright's Fst
    freqsNat <- rowSums(genoImportNative[,4:ncol(genoImportNative)] == "A")/(ncol(genoImportNative) - 3)  # native allele frequencies
    freqsImm <- rowSums(genoImportImm[,4:ncol(genoImportImm)] == "A")/(ncol(genoImportImm) - 3)   # immigrant allele frequencies
    expHetNat <- 2*freqsNat*(1-freqsNat)
    expHetImm <- 2*freqsImm*(1-freqsImm)
    freqsAll <- rowSums(cbind(genoImportNative[,4:ncol(genoImportNative)], genoImportImm[,4:ncol(genoImportImm)]) == "A")/ncol(cbind(genoImportNative[,4:ncol(genoImportNative)], genoImportImm[,4:ncol(genoImportImm)]))
    expHetAll <- 2*freqsAll*(1-freqsAll)
    Fst <- 1 - (rowMeans(cbind(expHetNat,expHetImm))/expHetAll)
  }

  snpLocs <- as.numeric(genoImportNative[which(genoImportNative[,1] == "1"),3])


  ##############################################################
  # save all offspring demographic data anb genotypes
  ##############################################################
  allOffspring <- NULL   # save demographic data from all offspring
  allOffChr1 <- list()   # save genomic data for all offspring
  allOffChr2 <- list()
  offSurv <- NULL    # vector of survival tests for each offspring

  ############################################################
  # run the simulation
  ############################################################
  maxID <- max(allPopMat[,1])
  persist <- 1                   # indicator that the population is not extinct
  i <- 1
  while (persist == 1 & i <= runTime){          # run the simulation to extinction or runTime generations
    ##################################################
    # dispersal of juveniles
    ##################################################
    juvies <- NULL
    juvies <- which (popMat[,3] == 0)
    juvHybInds <- NULL      # hybrid indices of the juvies
    juvHybInds <- popMat[juvies,4]

    ##################################
    # Introduce non-native individuals
    ##################################
    if(i %in% stockYears){
      stockIDs <- (maxID+1):(stockNum + maxID) # ids of the stocked individuals
      maxID <- max(stockIDs)
      stockPop <- rep(1,length(stockIDs))
      stockAges <- rep(1,length(stockIDs))    # age of introduced non-native individuals
      stockSex <- rep(c(0,1),length(stockAges)/2)    # sex of introduced individuals
      stockRBT <- rep(1,length(stockIDs))            # all introduced non-natives have a hybrid index of 1
      stockSelecRBT <- rep(1,length(stockIDs))

      ##################################
      # translocated individuals
      ##################################
      stockMom <- rep(NA,length(stockIDs))
      stockDad <- rep(NA,length(stockIDs))
      year <- rep(i,length(stockIDs))
      stockMat <- cbind(stockIDs,stockPop,rep(1,length(stockPop)),stockRBT,stockSex,stockSelecRBT,stockMom,stockDad,year)
      colnames(stockMat) <- NULL
      popMat <- rbind(popMat,stockMat)
      for(j in 1:length(chr1List)){
        chr1List[[j]] <- rbind(chr1List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))  # add genomic data for introduced non-natives
        chr2List[[j]] <- rbind(chr2List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))
        impImmChr1List[[j]][1:length(stockIDs),1] <- stockIDs
        impImmChr2List[[j]][1:length(stockIDs),1] <- stockIDs
        impChr1List[[j]] <- rbind(impChr1List[[j]],impImmChr1List[[j]][1:length(stockIDs),])
        impChr2List[[j]] <- rbind(impChr2List[[j]],impImmChr2List[[j]][1:length(stockIDs),])
        impImmChr1List[[j]] <- impImmChr1List[[j]][-(1:length(stockIDs)),]
        impImmChr2List[[j]] <- impImmChr2List[[j]][-(1:length(stockIDs)),]
      }
    }

    ########
    # mating
    ########
    offspring <- NULL # matrix to store the new offspring demographic data (i.e., hybrid index, parents, etc.)
    offChr1 <- list() #list of length 'chroms' storing the maternal chromosome copies
    offChr2 <- list() #list of length 'chroms' storing the paternal chromosome copies
    if(is.null(genoImportNative) == FALSE){
      offChr1Poly <- list() #list of length 'chroms' storing the maternal chromosome copies at polymorphic loci
      offChr2Poly <- list() #list of length 'chroms' storing the paternal chromosome copies at polymorphic loci
    }

    thisDat <- NULL
    thisDat <- popMat
    matFems <- NULL      # mature females
    pickFemales <- which(thisDat[,3] >= 1 & thisDat[,5] == 0)
    matFems <- thisDat[pickFemales,1]
    matFemHybInd <- NULL
    matFemHybInd <- thisDat[pickFemales,6]       # female hybrid indices at the loci affecting fitness
    candMales <- NULL # males that are mature and could breed
    candMales <- which(thisDat[,3] >= 1 & thisDat[,5] == 1)
    maleHybInd <- NULL # hybrid indices of all candidate fathers
    maleHybInd <- thisDat[candMales,4]   # hybrid indices of males (at all loci) that are mature and could breed

    #### pick males for the females to breed with.... Onle one male per female. Males can mate with multiple females
    pickMales <- rep(NA,length(matFems))
    for (v in 1:length(matFems)){
      if(length(candMales) > 1)pickMales [v] <- sample(candMales,size=1,prob= (1 - abs(matFemHybInd[v] - maleHybInd)*assortWeight),replace=FALSE)
      if(length(candMales) == 1)pickMales [v] <- candMales[1]

    }
    matMales <- NULL     # mature males
    matMales <- thisDat[pickMales,1]  # males that will be paired with females
    matMaleHybInd <- NULL
    matMaleHybInd <- thisDat[pickMales,4]

    ##### make offspring
    matePairs <- NULL
    matePairs <- cbind(matFems,matFemHybInd,matMales,matMaleHybInd)     # pairs of candidate parents
    femSelecGenos1 <- NULL    # female genotypes at loci affecting fitness
    femSelecGenos2 <- NULL    # female genotypes at loci affecting fitness
    for(z in 1:length(selecChrs)){
      femSelecGenos1 <- cbind(femSelecGenos1,chr1List[[selecChrs[z]]][match(matFems,chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      femSelecGenos2 <- cbind(femSelecGenos2,chr2List[[selecChrs[z]]][match(matFems,chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
    }
    femSelecGenos <- 2 - (femSelecGenos1 + femSelecGenos2)    # this is the number of non-native alleles each female has at each selected locus
    locusEffSize <- ((invRelRepro)/numSelecLoci)/2        # additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
    genValMat <- matrix(0,nrow(femSelecGenos),ncol(femSelecGenos)) # matrix to store the genetic trait effects for each individual and each selected locus
    for(z in 1:ncol(femSelecGenos)){
      if(sum(femSelecGenos[,z] == 1) > 0){genValMat [which(femSelecGenos[,z] == 1),z] <- femSelecGenos [which(femSelecGenos[,z] == 1),z] * locusEffSize *(1 + repro_d)} #genetic value of heterozygoges, accounting for dominance
      if(sum(femSelecGenos[,z] == 2) > 0){genValMat [which(femSelecGenos[,z] == 2),z] <- femSelecGenos [which(femSelecGenos[,z] == 2),z] * locusEffSize}
    }
    femWeights <- NULL
    femWeights <-  1 + rowSums(genValMat)
    if(F1Heterosis == 1){if(sum(matFemHybInd == 0.5) > 0){femWeights[which(matFemHybInd == 0.5)] <- 1}}  # F1s have the same fitness as pure natives
    numOffVec <- rep(NA,length(matFemHybInd))
    parentPairs <- NULL
    for(z in 1:length(matFemHybInd)){
      thisNumOff <- rpois(1,lambda=femWeights[z]*famSize)                 # female fecundity as a function of admixture
      numOffVec[z] <- thisNumOff
      if(thisNumOff > 0){
        outPairs <- matrix(rep(matePairs[z,],thisNumOff),nrow=thisNumOff,ncol=4,byrow=TRUE)
        parentPairs <- rbind(parentPairs,outPairs)
      }
    }

    if(is.null (parentPairs) == FALSE){
      fry <- NULL   # this years offspring
      fryIDs <- (maxID+1):(maxID+nrow(parentPairs))    # IDs for the offspring
      maxID <- max(fryIDs)
      fryPop <- rep(1,length(fryIDs))
      fryAge <- rep(1,length(fryIDs))
      frySex <- rep(c(0,1),length(fryIDs))[1:length(fryIDs)]
      fryMoms <- parentPairs[,1]
      fryDads <- parentPairs[,3]

      #######################################################
      # calculate the genomic hybrid index of each offspring
      ######################################################

      #### meiosis
      nonNatAllsMom <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      nonNatAllsDad <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      nLoci <- nChromLoci
      for(k in 1:chroms){

        ##### diagnostic loci
        if(nrow(parentPairs) > 1){
          momsCopy1 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],popMat[,1]),])
          dadsCopy1 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],popMat[,1]),])
          momsCopy2 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], popMat[,1]),])
          dadsCopy2 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], popMat[,1]),])
        }
        if(nrow(parentPairs) == 1){
          momsCopy1 <- NULL
          momsCopy2 <- NULL
          dadsCopy1 <- NULL
          dadsCopy2 <- NULL

          momsCopy1 <- rbind(momsCopy1,c(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],popMat[,1]),]))
          dadsCopy1 <- rbind(dadsCopy1,c(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],popMat[,1]),]))
          momsCopy2 <- rbind(momsCopy2,c(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], popMat[,1]),]))
          dadsCopy2 <- rbind(dadsCopy2,c(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], popMat[,1]),]))
        }

        if(is.null(genoImportNative) == FALSE){
          if(nrow(parentPairs) > 1){
            momsCopy1Poly <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],impChr1List[[k]][match(parentPairs[,1],popMat[,1]),])
            dadsCopy1Poly <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],impChr1List[[k]][match(parentPairs[,3],popMat[,1]),])
            momsCopy2Poly <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],impChr2List[[k]][match(parentPairs[,1], popMat[,1]),])
            dadsCopy2Poly <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],impChr2List[[k]][match(parentPairs[,3], popMat[,1]),])
            fryChromOnesPoly <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
            fryChromTwosPoly <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
          }
          if(nrow(parentPairs) == 1){
            momsCopy1Poly <- NULL
            dadsCopy1Poly <- NULL
            momsCopy2Poly <- NULL
            dadsCopy2Poly <- NULL
            fryChromOnesPoly <- NULL
            fryChromTwosPoly <- NULL

            momsCopy1Poly <- rbind(momsCopy1Poly, c(popMat[match(parentPairs[,1],popMat[,1]),1],impChr1List[[k]][match(parentPairs[,1],popMat[,1]),]))
            dadsCopy1Poly <- rbind(dadsCopy1Poly, c(popMat[match(parentPairs[,3],popMat[,1]),1],impChr1List[[k]][match(parentPairs[,3],popMat[,1]),]))
            momsCopy2Poly <- rbind(momsCopy2Poly, c(popMat[match(parentPairs[,1],popMat[,1]),1],impChr2List[[k]][match(parentPairs[,1], popMat[,1]),]))
            dadsCopy2Poly <- rbind(dadsCopy2Poly, c(popMat[match(parentPairs[,3],popMat[,1]),1],impChr2List[[k]][match(parentPairs[,3], popMat[,1]),]))
            fryChromOnesPoly <- rbind(fryChromOnesPoly, c(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci)))
            fryChromTwosPoly <- rbind(fryChromTwosPoly, c(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci)))
          }

        }

        #----------------------------
        # maternal meiosis
        #----------------------------
        momRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
        momRecLocsMat <- matrix(NA,nrow=length(fryIDs),ncol=max(momRecs)+1)
        for(z in 1:ncol(momRecLocsMat)){   # draw locations of crossovers for all individuals
          momRecLocsMat[which(momRecs >= z),z] <- runif(n=length(which(momRecs >= z)),min=0,max=mapLeng)
          if(sum(momRecs == (z-1)) > 0) momRecLocsMat[which(momRecs == (z-1)),z] <- mapLeng
        }
        if(sum(momRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(momRecs > 1)
          for(b in moreThanOneRec){
            momRecLocsMat[b,1:(momRecs[b]+1)] <- sort(momRecLocsMat[b,])
          }
        }
        momChrPicker <- sample(x=c(1,2),size=length(fryIDs),replace=TRUE) # which parental chromosome copy to sample first
        offMomGenos <- matrix(NA,nrow=length(fryIDs),ncol=nLoci)        #  initialize offspring genotype matrix
        offMomGenosPoly <- matrix(NA,nrow=length(fryIDs),ncol=nLoci)    #  initialize offspring genotype matrix
        for(b in 1:(max(momRecs)+1)){        # assign genotypes to offspring
          thisMomGenoMat <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offMomGenos))
          thisMomGenoMatPoly <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offMomGenos))
          if(sum(momChrPicker == 1) > 0){
            thisMomGenoMat[which(momChrPicker == 1),] <- momsCopy1[which(momChrPicker == 1),3:ncol(momsCopy1)]
            thisMomGenoMatPoly[which(momChrPicker == 1),] <- momsCopy1Poly[which(momChrPicker == 1),3:ncol(momsCopy1Poly)]
          }
          if(sum(momChrPicker == 2) > 0){
            thisMomGenoMat[which(momChrPicker == 2),] <- momsCopy2[which(momChrPicker == 2),3:ncol(momsCopy2)]
            thisMomGenoMatPoly[which(momChrPicker == 2),] <- momsCopy2Poly[which(momChrPicker == 2),3:ncol(momsCopy2Poly)]
          }
          if(b == 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p]),p]
              if(sum(momRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offMomGenosPoly[which(momRecLocsMat[,b] >= snpLocs[p]),p] <- thisMomGenoMatPoly[which(momRecLocsMat[,b] >= snpLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p]
              if(sum(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenosPoly[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMatPoly[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(momChrPicker))
          if(sum(momChrPicker == 1) > 0) newChrPicker[which(momChrPicker == 1)] <- 2
          momChrPicker <- newChrPicker
        }
        fryChromOnes <- cbind(fryIDs,offMomGenos)
        fryChromOnesPoly <- cbind(fryIDs,offMomGenosPoly)



        #----------------------------
        # paternal meiosis
        #----------------------------
        dadRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
        dadRecLocsMat <- matrix(NA,nrow=length(fryIDs),ncol=max(dadRecs)+1)
        for(z in 1:ncol(dadRecLocsMat)){   # draw locations of crossovers for all individuals
          dadRecLocsMat[which(dadRecs >= z),z] <- runif(n=length(which(dadRecs >= z)),min=0,max=mapLeng)
          if(sum(dadRecs == (z-1)) > 0) dadRecLocsMat[which(dadRecs == (z-1)),z] <- mapLeng
        }
        if(sum(dadRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(dadRecs > 1)
          for(b in moreThanOneRec){
            dadRecLocsMat[b,1:(dadRecs[b]+1)] <- sort(dadRecLocsMat[b,])
          }
        }
        dadChrPicker <- sample(x=c(1,2),size=length(fryIDs),replace=TRUE) # which parental chromosome copy to sample first
        offDadGenos <- matrix(NA,nrow=length(fryIDs),ncol=nLoci)        #  initialize offspring genotype matrix
        offDadGenosPoly <- matrix(NA,nrow=length(fryIDs),ncol=nLoci)    #  initialize offspring genotype matrix
        for(b in 1:(max(dadRecs)+1)){        # assign genotypes to offspring
          thisDadGenoMat <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offDadGenos))
          thisDadGenoMatPoly <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offDadGenos))
          if(sum(dadChrPicker == 1) > 0){
            thisDadGenoMat[which(dadChrPicker == 1),] <- dadsCopy1[which(dadChrPicker == 1),3:ncol(dadsCopy1)]
            thisDadGenoMatPoly[which(dadChrPicker == 1),] <- dadsCopy1Poly[which(dadChrPicker == 1),3:ncol(dadsCopy1Poly)]
          }
          if(sum(dadChrPicker == 2) > 0){
            thisDadGenoMat[which(dadChrPicker == 2),] <- dadsCopy2[which(dadChrPicker == 2),3:ncol(dadsCopy2)]
            thisDadGenoMatPoly[which(dadChrPicker == 2),] <- dadsCopy2Poly[which(dadChrPicker == 2),3:ncol(dadsCopy2Poly)]
          }
          if(b == 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p]),p]
              if(sum(dadRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offDadGenosPoly[which(dadRecLocsMat[,b] >= snpLocs[p]),p] <- thisDadGenoMatPoly[which(dadRecLocsMat[,b] >= snpLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p]
              if(sum(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenosPoly[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMatPoly[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(dadChrPicker))
          if(sum(dadChrPicker == 1) > 0) newChrPicker[which(dadChrPicker == 1)] <- 2
          dadChrPicker <- newChrPicker
        }
        fryChromTwos <- cbind(fryIDs,offDadGenos)
        fryChromTwosPoly <- cbind(fryIDs,offDadGenosPoly)

        offChr1[[k]] <- fryChromOnes
        offChr2[[k]] <- fryChromTwos
        if(is.null(genoImportNative) == FALSE){
          offChr1Poly[[k]] <- fryChromOnesPoly
          offChr2Poly[[k]] <- fryChromTwosPoly
        }
        if(nrow(fryChromOnes) > 1){
          nonNatAllsMom <- cbind(nonNatAllsMom,rowSums(fryChromOnes[,2:ncol(fryChromOnes)] == 0))
          nonNatAllsDad <- cbind(nonNatAllsDad,rowSums(fryChromTwos[,2:ncol(fryChromTwos)] == 0))
        }
        if(nrow(fryChromOnes) == 1){
          nonNatAllsMom <- c(nonNatAllsMom,sum(fryChromOnes[2:ncol(fryChromOnes)] == 0))
          nonNatAllsDad <- c(nonNatAllsDad,sum(fryChromTwos[2:ncol(fryChromTwos)] == 0))
        }
      }

      if(length(fryIDs) > 1)fryPercRBT <- rowSums(cbind(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry
      if(length(fryIDs) == 1)fryPercRBT <- sum(c(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry


      fryOut <- cbind(fryIDs,fryPop,fryAge,fryPercRBT,frySex,fryMoms,fryDads,rep(i,length(fryIDs)))
      colnames(fryOut) <- NULL
      offspring <- rbind(offspring,fryOut)

      ###########################################
      # get the hybrid index at fitness loci
      ###########################################
      selecPercRBT <- rep(NA,length(fryPercRBT))
      selecGenos <- NULL
      for(z in 1:length(selecChrs)){
        selecGenos <- cbind(selecGenos,offChr1[[selecChrs[z]]][,selecLoci[z]+1],offChr2[[selecChrs[z]]][,selecLoci[z]+1])
      }
      selecPercRBT <- 1 - rowSums(selecGenos)/ncol(selecGenos)

      if(nrow(offspring) > 1) offspring <- cbind(offspring[,1:5],selecPercRBT,offspring[,6:8])
      if(nrow(offspring) == 1) offspring <- c(offspring[1:5],selecPercRBT,offspring[6:8])

      ##################################################
      # advance the population to the next year
      ##################################################
      newPop <- NULL          # temporarily store the new population data
      keepIndices <- NULL    # vector of the IDs of individuals surviving to the next year
      ageDat <- NULL
      ageDat <- offspring
      ageSelecGenos1 <- NULL    # genotypes of individuals in the kth age class at fitness loci
      ageSelecGenos2 <- NULL
      for(z in 1:length(selecChrs)){
        if(is.null(nrow(ageDat)) == FALSE){
          ageSelecGenos1 <- cbind(ageSelecGenos1,offChr1[[selecChrs[z]]][match(ageDat[,1],offChr1[[selecChrs[z]]][,1]),selecLoci[z]+1])
          ageSelecGenos2 <- cbind(ageSelecGenos2,offChr1[[selecChrs[z]]][match(ageDat[,1],offChr1[[selecChrs[z]]][,1]),selecLoci[z]+1])
        }
        if(is.null(nrow(ageDat))) {
          ageSelecGenos1 <- c(ageSelecGenos1,offChr1[[selecChrs[z]]][selecLoci[z]+1])
          ageSelecGenos2 <- c(ageSelecGenos2,offChr1[[selecChrs[z]]][selecLoci[z]+1])
        }
      }
      ageSelecGenos <- 2 - (ageSelecGenos1 + ageSelecGenos2)    # number of non-native alleles each age[k] individual has at each selected locus
      locusEffSize <- ((invRelSurv)/numSelecLoci)/2             # additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)

      if(is.null(nrow(ageSelecGenos)) == FALSE){
        genValMat <- matrix(0,nrow(ageSelecGenos),ncol(ageSelecGenos)) # matrix to store the genetic trait effects for each individual and each selected locus
        for(z in 1:ncol(ageSelecGenos)){
          if(sum(ageSelecGenos[,z] == 1) > 0){genValMat [which(ageSelecGenos[,z] == 1),z] <- ageSelecGenos [which(ageSelecGenos[,z] == 1),z] * locusEffSize *(1 + surv_d)} #genetic value of heterozygoges, accounting for dominance
          if(sum(ageSelecGenos[,z] == 2) > 0){genValMat [which(ageSelecGenos[,z] == 2),z] <- ageSelecGenos [which(ageSelecGenos[,z] == 2),z] * locusEffSize}
        }
        survWeights <-  1 + rowSums(genValMat)
      }

      if(is.null(nrow(ageSelecGenos))){   # if there is only one individual
        genValMat <- rep(0,length(ageSelecGenos)) # matrix to store the genetic trait effects for each individual and each selected locus
          if(sum(ageSelecGenos == 1) > 0){genValMat [which(ageSelecGenos == 1)] <- ageSelecGenos [which(ageSelecGenos == 1)] * locusEffSize *(1 + surv_d)} #genetic value of heterozygoges, accounting for dominance
          if(sum(ageSelecGenos == 2) > 0){genValMat [which(ageSelecGenos == 2)] <- ageSelecGenos [which(ageSelecGenos == 2)] * locusEffSize}
        survWeights <-  1 + sum(genValMat)
      }


      if(F1Heterosis == 1){# F1s have the same fitness as pure natives
        if(is.null(nrow(ageDat)) == FALSE){if(sum(ageDat[,6] == 0.5) > 0){femWeights[which(ageDat[,6] == 0.5)] <- 1}}
        if(is.null(nrow(ageDat))) {if(ageDat[6] == 0.5) {femWeights[1] <- 1}}
        }

      indSurvProbs <- survWeights * survProbs                             # probability of surviving for each individual
      if(length(indSurvProbs) > carryCap) {
        needSurvProb <- carryCap/length(indSurvProbs)
        if(mean(indSurvProbs) > needSurvProb) indSurvProbs <- indSurvProbs - (mean(indSurvProbs) - needSurvProb)
      }                                                                    # density dependence if the population is above carrying capacity
      survTests <- runif(length(survWeights),min=0,max=1) < indSurvProbs   # test if each individual survives

      # save all data from the offspring
      allOffspring <- rbind(allOffspring,offspring)
      #for(k in 1:length(chr1List)){
      #  if(i == 1){
      #    allOffChr1 [[k]] <- offChr1[[k]]
      #    allOffChr2 [[k]] <- offChr2[[k]]
      #  }
      #  if(i > 1){
      #   allOffChr1 [[k]] <- rbind(allOffChr1 [[k]],offChr1[[k]])
      #    allOffChr2 [[k]] <- rbind(allOffChr2 [[k]],offChr2[[k]])
      #  }
      #}
      offSurv <- c(offSurv,survTests)

      # keep the survivors to pass to next year
      if(sum(survTests) > 0){
        keepIndices <- which(survTests == TRUE)
        if(is.null(nrow(ageDat)) == FALSE) newPop <- ageDat[keepIndices,]
        if(is.null(nrow(ageDat))) newPop <- ageDat

        ##################################################################################
        # update the genetic data to contain only the individuals passing to the next year
        ##################################################################################
        for(k in 1:length(chr1List)){
          chr1List[[k]] <- offChr1[[k]][keepIndices,]
          chr2List[[k]] <- offChr2[[k]][keepIndices,]
          if(is.null(genoImportNative) == FALSE){
            impChr1List[[k]] <- offChr1Poly[[k]][keepIndices,]
            impChr2List[[k]] <- offChr2Poly[[k]][keepIndices,]
          }
        }

        #######################################################
        # save the new genotypes from this year
        #######################################################

        if(is.null(ncol(chr1List[[1]])) == FALSE) newGenos <- which(chr1List[[1]][,1] %in% allChr1[[1]][,1] == FALSE)
        if(is.null(ncol(chr1List[[1]]))) newGenos <- 1
        if(is.null(genoImportNative) == FALSE & is.null(ncol(impChr1List[[1]])) == FALSE) newGenosPoly <- which(impChr1List[[1]][,1] %in% allChr1Poly[[1]][,1] == FALSE)
        if(is.null(genoImportNative) == FALSE & is.null(ncol(impChr1List[[1]]))) newGenosPoly <- 1

        for(k in 1:length(chr1List)){
          if(is.null(ncol(chr1List[[1]])) == FALSE){
            allChr1[[k]] <- rbind(allChr1[[k]],chr1List[[k]][newGenos,])
            allChr2[[k]] <- rbind(allChr2[[k]],chr2List[[k]][newGenos,])
          }

          if(is.null(ncol(chr1List[[1]]))){                       # add the new genotypes if there is only one individual left
            allChr1[[k]] <- rbind(allChr1[[k]],chr1List[[k]])
            allChr2[[k]] <- rbind(allChr2[[k]],chr2List[[k]])
          }

          if(is.null(genoImportNative) == FALSE & is.null(ncol(impChr1List[[1]])) == FALSE){
            allChr1Poly[[k]] <- rbind(allChr1Poly[[k]],impChr1List[[k]][newGenosPoly,])
            allChr2Poly[[k]] <- rbind(allChr2Poly[[k]],impChr2List[[k]][newGenosPoly,])
          }

          if(is.null(genoImportNative) == FALSE & is.null(ncol(impChr1List[[1]]))){
            allChr1Poly[[k]] <- rbind(allChr1Poly[[k]],impChr1List[[k]])
            allChr2Poly[[k]] <- rbind(allChr2Poly[[k]],impChr2List[[k]])
          }
        }
        if(is.null(nrow(newPop)) == FALSE){newPop[,ncol(newPop)] <- rep(i,nrow(newPop))} # update the year
        if(is.null(nrow(newPop))){newPop[length(newPop)] <- i}
        popMat <- newPop  # replace this year's population with the next

        ################################################
        # save the new individuals in allPopMat
        ################################################
        allPopMat <- rbind(allPopMat,newPop)
        print(paste("done with generation", i))
        i <- i + 1
      }
    } # end test for more than zero offspring

    #########################################################
    # test for extinction
    #########################################################
    numSexes <- 2
    if(is.null(nrow(popMat)) == FALSE) {
      if(length(unique(popMat[,5])) < 2) numSexes <- 1
    }
    if(sum(survTests) == 0 | is.null(nrow(popMat)) | is.null(parentPairs) | numSexes == 1) {        # declare the population extinct if there is only one sex left, or if no offspring survived
      print(paste("Population extinct at generation ",i,sep=""))
      persist <- 0
    }
  }



  #######################################################
  # format the genotypes
  #######################################################

  genos_012 <- NULL    # genotype file giving the count of native alleles at each locus for each individual
  # individuals are in rows, loci are in columns (on column per locus)
  genoNames <- allChr1[[1]][,1]
  for(i in 1:length(chr2List)){
    genos_012 <- cbind(genos_012,allChr1[[i]][,2:ncol(allChr1[[i]])]+allChr2[[i]][,2:ncol(allChr2[[i]])])
  }


  fstAlls <- seq(from=1,to=2*ncol(genos_012),by=2)
  secAlls <- seq(from=2,to=2*ncol(genos_012),by=2)

  atMat <- matrix(NA,nrow=nrow(genos_012),ncol=(ncol(genos_012)*2))   # genotype file with A = native allele, T = non-native allele

  # individuals are in rows, loci in columns (two adjacent columns
  # per locus); first column is individual ID


  for(i in 1:ncol(genos_012)){
    atMat[which(genos_012[,i] == 0),fstAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),fstAlls[i]] <- "A"
    atMat[which(genos_012[,i] == 2),fstAlls[i]] <- "A"

    atMat[which(genos_012[,i] == 0),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 2),secAlls[i]] <- "A"
  }

  polyGenos <- matrix(NA,nrow=nrow(genos_012),ncol=ncol(genos_012)*2)
  fstAllCol <- 1
  secAllCol <- 2
  for(i in 1:chroms){
    chr1_inDat <- allChr1Poly[[i]]
    chr2_inDat <- allChr2Poly[[i]]
    for (j in 1:nChromLoci){
      polyGenos[,fstAllCol] <- chr1_inDat[,j+1]
      polyGenos[,secAllCol] <- chr2_inDat[,j+1]
      fstAllCol <- fstAllCol + 2
      secAllCol <- secAllCol + 2
    }
  }
  genos_012 <- cbind(genoNames,genos_012)
  atMat <- cbind(genoNames,atMat)
  polyGenos <- cbind(genoNames,polyGenos)
  allOffspring <- cbind(allOffspring,offSurv)
  colnames(allOffspring) <- c(colnames(allPopMat),"survival")
  admixRes <- list(allPopMat,genos_012,atMat,polyGenos,selecChrMat,selecLociMat,Fst,allOffspring)
  return(admixRes)
}






