#' A function to plot results from admix2D simulations.
#'
#' This function plots individuals in 2-dimensional habitat resulting from simulations with the function admix2D. Individuals
#'     are color-coded according to hybrid index.
#' @param admixDat Output from the function admix2D.
#' @param habSize A single number giving the length and width of the simulated habitat (in kilometers).
#' @param yearPlot The year of the simulation to include indivduals in the figure.
#' @param contactLine The location on the x-axis of the species contact.
#' @param figName The name the plot will be saved under in the working directory.
#' @examples
#'     # load the package
#'     library(admixr)
#'     # simulate a population of 1000 individuals for five years. 20 non-native juveniles enter the habitat every year.
#'     admixTry <- admixHybZone(habSize=100,popSize=2000,contactLine = 50,ages=c(0,1,2,3,4),ageMaturity=2,ageStruc=c(0.5,0.2,0.1,0.1,0.1),meanDispDist=4,
#'     matingDistRate = 0.2,repro_d=1,surv_d=1,nativeDom = TRUE,epiSize = 1, epiDom = 1, numSelecLoci=1,invRelSurv=-1,invRelRepro=-1,assortWeight=0.2,
#'     nChromLoci=100,chroms=5,mapLeng=c(50,50,100,100,200),runTime=5)
#'     # plot results from the last simulated year
#'     plot2D(admixDat = admixTry,habSize = 100,yearPlot = 5,contactLine=50,figName="exampleFig")
#' @export


plot2D <- function(admixDat,habSize,yearPlot,contactLine,figName)
{
  library(plotrix)
  library(grDevices)
  if (yearPlot > max(admixDat[[1]][,11])) {stop("yearPlot must be <= the simulated number of years")}
  yearDat <- admixDat[[1]][which(admixDat[[1]][,11]==yearPlot),]
  rbPal <- colorRampPalette(c('orange','blue'))       # scale blue to orange : native to non-native
  col <- rbPal(101)[round(yearDat[,4]*100)+1]

  pdf(figName)
  par(xpd=TRUE,mar=c(4,4,4,4))
  ptSize <- 1 - 0.1*(nrow(yearDat)/1000)
  if(ptSize < 0.4){ptSize <- 0.4}
  plot(yearDat[,7],yearDat[,8],pch=19,cex=ptSize,col=col,ylab="",xlab="",
       axes=FALSE,xlim=c(0,habSize),ylim=c(0,habSize))         # plot individuals in the 2D space
  wid <- dev.size(units="in")[1]
  hei <- dev.size(units="in")[2]
  lines(x=c(-0.02*habSize,-0.02*habSize),y=c(1.02*habSize,-0.02*habSize),col="darkgray")  # make a box around the habitat
  lines(x=c(-0.02*habSize,1.02*habSize),y=c(-0.02*habSize,-0.02*habSize),col="darkgray")
  lines(x=c(1.02*habSize,1.02*habSize),y=c(-0.02*habSize,1.02*habSize),col="darkgray")
  lines(x=c(-0.02*habSize,1.02*habSize),y=c(1.02*habSize,1.02*habSize),col="darkgray")

  lines(x=c(0.45*habSize,0.55*habSize),y=c(-0.1*habSize,-0.1*habSize))                                      # distance scale
  text(x=0.5*habSize,y=-0.15*habSize,labels=paste(0.1*habSize," km", sep=""),cex=1.25)

  points(x=0.04,y=1.1*habSize,pch=19,cex=1.2,col="blue")                                     # admixture scale
  text(x=0.09*habSize,y=1.1*habSize,labels="Pop. 1",cex=1.25)

  points(x=0.86*habSize,y=1.1*habSize,pch=19,cex=1.2,col="orange")
  text(x=0.95*habSize,y=1.1*habSize,labels="Pop. 2",cex=1.25)

  points(x=0.48*habSize,y=1.1*habSize,cex=1.2,pch=19,col=rbPal(101)[50])
  text(x=0.53*habSize,y=1.1*habSize,labels="F1",cex=1.25)

  lines(x=c(contactLine,contactLine),y=c(0,habSize),lty="dashed",col="darkgray",lwd=2)
  dev.off()
}
