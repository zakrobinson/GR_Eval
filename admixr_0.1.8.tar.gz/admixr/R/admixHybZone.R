#' A function to simulate a hybrid zone
#'
#' This function runs a forward-time spatially and genomically explicit simulation of hybridization in a
#'     two-dimensional habitat.
#' @param habSize numeric. The length and width of the square-shaped habitat (in kilometers)
#' @param popSize numeric. The total number of individuals occupying the habitat. The fraction of the total individuals
#'     in each of the two populations is proportional to the location of the contactLine (see below), with population 1 on the left, and population 2 on the right).
#'     The population size on either side of the contact line will be constant throughout the simulation.
#' @param contactLine numeric. The location on the x-axis separating the ranges of the two populations at the beginning of the simulation
#' @param ages numeric. A vector giving the age classes in the population. The vector should be a sequence starting with 0 for young-of-the-year.
#' @param ageMaturity numeric. The age at which an individual is capable of reproducing.
#' @param ageStruc numeric. A vector giving the proportion of the population in each of the age
#'     classes. Must sum to one.
#' @param meanDispDist numeric. Mean dispersal distance of one year olds. Only one year olds are allowed to disperse and establish a new home range.
#' @param matingDistRate numeric. Exponential rate of decline in the probability of a female selecting
#'     a male as a mate with increasing distance. Females are more likely to select close-by males as mates.
#' @param repro_d numeric. The dominance of fitness loci for fedundity. 0 = no dominance. 1 = complete dominance.
#' @param surv_d numeric. The dominance of fitness loci for survival. 0 = no dominance. 1 = complete dominance.
#' @param nativeDom logical. TRUE if higher fitness alleles are dominant over lower fitness alleles, FALSE if less fit alleles alleles are dominant over more fit alleles
#'     at all fitness and modifier loci. If invRelRepro and invRelSurv are negative, then TRUE means that the native allele is dominant over the non-native allele.
#' @param epiSize numeric. The strength of epistasis. Ranges from 0 to 1. 1 means that the fitness effects of alleles at fitness loci depend 100% on the genotypic value at the modifier loci.
#'     zero means there is no epistasis. The model assumes that native alleles at modifier loci interact positively with native alleles at fitness loci.
#' @param epiDom numeric. The dominance at modifier loci. 0 = no dominance. 1 = complete dominance). Must range from 0 to 1.
#' @param numSelecLoci numeric. The number of loci in the genome that affect fitness. The same loci affect survival and reproduction. The fitness effects on survival and reproduction
#'     are spread evenly over these loci. The fitness loci are selected at random from all sites across the genome.
#' @param invRelSurv numeric. Signed proportional difference in survival probability of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean that non-natives are more fit than natives. Negative
#'     values mean that non-natives are less fit than natives. 0.5 means that pure non-natives have 50 percent higher survival than natives.
#' @param invRelRepro numeric. Signed difference in female fedundity of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-native are more fit than natives. Negative
#'     values mean that non-natives are less fit than natives. 0.5 means that non-natives have 50 percent higher fecundity than natives.
#' @param assortWeight numeric. The strength of positive assortative mating. Must range from 0 to 1. 1 means complete
#'     assortative mating, i.e. pure non-natives and pure natives will never mate. 0 means no assorative mating.
#' @param nChromLoci numeric. An integer defining the number of evenly spaced ancestry-informative, i.e. diagnostic, loci to place on each chromosome. Must be >= 1.
#' @param chroms numeric. An integer defining the number of chromosomes to simulate. Must be >= 2 to accomodate epistasic intereaction between unlinked loci.
#' @param mapLeng numeric. Vector of length chroms, defining the genetic map length of each chromosome in units of centiMorgans.
#' @param runTime numeric. The number of years to run the simulation.
#' @details
#'    The output from this function is a list with five elements. First element is a data frame with the following columns: Individual identification number,
#'    population number (one for all individuals), age, the hybrid index (fraction of genome that is non-native), sex, the hybrid index at fitness
#'    loci, the location of the individual on the x-axis, the location on the y-axis, mother identity, father identity, and year. Every individual in the population is
#'    represented for each year; for example, an individual that was born in year 5 and died in year 7 will be represented in three rows (one for each of years 5-7).
#'
#'    The second element contains the genotypes of all individuals in 012 format. The first column is the individual identification number. The
#'    remaining columns are genotypes given as the number of non-native alleles at each locus in the genome. Loci are ordered left to right,
#'    starting with the first locus on chromosome 1, and so on.
#'
#'    The third element is a data frame containing the genotypes at "AT" format. T is the non-native allele and A is the native allele at each locus. The
#'    first column is the individual identification number. The remaining columns are individual genotypes, ordered from left to right, beginning
#'    with the first locus on chromosome one. Each locus is represented by two columns, such that the total number of columns is two times the number
#'    of loci plus one.
#'
#'    The fourth element is a vector giving the chromosome locations of fitness loci.
#'
#'    The fifth element is a vector giving the location of each fitness locus on its corresponding chromosome in centiMorgans.
#' @examples
#'     # load the package
#'     library(admixr)
#'     # simulate a hybrid zone between 2 age-structured populations, each with 1000 individuals, for five years.
#'     admixTry <- admixHybZone(habSize=100,popSize=1000,contactLine=50,ages=c(0,1),ageMaturity=1, ageStruc=c(0.55,0.45),
#'     meanDispDist=10,matingDistRate=0.2,repro_d=1,surv_d=0,nativeDom=TRUE,epiSize=1,epiDom=1,numSelecLoci=10,
#'     invRelSurv=0,invRelRepro=-0.8,assortWeight=0,nChromLoci=20,chroms=4,mapLeng=c(rep(50,4)),runTime=20)
#'     # plot results from the last simulated year
#'     plot2D(admixDat = admixTry,habSize = 100,yearPlot = 5,contactLine=50,figName="exampleFig")
#' @export


admixHybZone <- function (habSize,popSize,contactLine,ages,ageMaturity,ageStruc,meanDispDist,matingDistRate,
                          repro_d,surv_d,nativeDom,epiSize,epiDom,numSelecLoci,invRelSurv,invRelRepro,assortWeight,
                          nChromLoci,chroms,mapLeng,runTime)
{

  if(length(mapLeng) != chroms){stop;print("mapLeng must be a vector of length chroms")}
  if(ageStruc[2]/ageStruc[1] >= 1){stop;print("survival from age 0 to age 1 must be < 1. Modify ageStruc accordingly.")}
  if(contactLine <= 0 | contactLine >= habSize){stop; print("contactLine must be > 0 and < habSize")}
  if(length(ages) != length(ageStruc)){stop;print("ages must be the same length as ageStruc")}
  if((0 <= epiDom & epiDom <= 1) == FALSE){stop; print("epiDom must be between 0 and 1")}
  if((0 <= epiSize & epiSize <= 1) == FALSE){stop; print("epiSize must be between 0 and 1")}
  if(is.logical(nativeDom) == FALSE){stop; print("nativeDom must be logical (TRUE of FALSE)")}
  if( (0 <= surv_d & surv_d <= 1) == FALSE | (0 <= repro_d & repro_d <= 1) == FALSE){stop; print("repro_d and surv_d must both be between 0 and 1")}
  if( sum(ageStruc) != 1){stop; print("ageStruc must sum to 1")}
  if(numSelecLoci > chroms*nChromLoci){stop;print("numSelecLoci must be <= the number of total loci simulated in the genome")}

  #########################################################
  # populate the network with genetically pure individuals
  #########################################################

  age <- NULL
  for (j in 1:2){
    for (i in 1:length(ages)){
      age <- c(age,rep(ages[i],ageStruc[i]*(popSize/2)))
    }
  }
  ageVec <- age

  id <- 1:length(ageVec)

  pop <- rep(1,length(id))
  sex <- rep(c(0,1),length(pop)/2)
  selecPercRBT <- rep(0,length(pop))  # hybrid index at the loci that affect fitness

  ################################################################
  # assign location of each individual on a 2-dimensional surface
  ################################################################

  xLoc <- runif(n=length(id)/2,min=0,max=contactLine) # random x and y coordinates for population 1
  yLoc <- runif(n=length(id)/2,min=0,max=habSize)
  xLoc <- c(xLoc,runif(n=length(id)/2,min=contactLine + 0.000000000001,max=habSize)) # random x and y coordinates for population 1
  yLoc <- c(yLoc,runif(n=length(id)/2,min=0,max=habSize) )
  percRBT <- rep(0,length(pop))       # hybrid index (fraction of the genome from population 1) initialized at zero for all individuals in population 2
  percRBT[which(xLoc <= contactLine)] <- 1  # hybrid index of individuals to the left of the contact line (in population 1)
  mom <- rep(NA,length(xLoc))
  dad <- rep(NA,length(xLoc))
  yearVec <- rep(0,length(dad))
  allPopMat <- cbind(id,pop,age,percRBT,sex,selecPercRBT,xLoc,yLoc,mom,dad,yearVec)       # matrix to store all of the population data throughout the simulation
  popMat <- allPopMat       # matrix to store the individuals that are in the population currently


  ###########################################
  # initialize the genome matrices
  ###########################################

  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  chrom <- matrix(NA,nrow=nrow(popMat),ncol=nChromLoci)
  allVec <- rep(1,nrow(popMat))
  allVec [which(percRBT == 1)] <- 0
  for (j in 1:nChromLoci){
    chrom[,j] <- allVec
  }
  chrom <- cbind(allPopMat[,1],chrom)
  for(i in 1:chroms){
    chr1List [[i]]<- chrom
    chr2List [[i]]<- chrom
  }

  allChr1 <- chr1List     # save the genotypes of all individuals
  allChr2 <- chr2List

  #######################
  # identify fitness loci
  #######################

  selecLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  selecChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression

  selecChrs <- sort(sample(1:chroms,numSelecLoci,replace=TRUE))
  selecLoci <- NULL
  uniChrs <- unique(selecChrs)
  for(i in 1:length(uniChrs)){
    selecLoci <- c(selecLoci,sort(sample(1:nChromLoci,sum(selecChrs == uniChrs[i]),replace=FALSE)))
  }

  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat <- rbind(selecChrMat,selecChrs)

  ##############################################################################
  # select modifier loci to intereact epistatically with the fitness loci
  ##############################################################################

    modLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
    modChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression

    modChrs <- rep(NA,length(selecChrs))
    for(i in 1:length(modChrs)){
      if(chroms > 2) {modChrs [i] <- sample( (1:chroms)[which( (1:chroms) != selecChrs[i])],1)}
      if(chroms == 2){modChrs [i] <- (1:chroms)[which( (1:chroms) != selecChrs[i])]}
    }


    modLoci <- NULL
    uniChrs <- unique(modChrs)
    for(i in 1:length(uniChrs)){
      modLoci <- c(modLoci,sort(sample(1:nChromLoci,sum(modChrs == uniChrs[i]),replace=FALSE)))
    }

    selecLociMat <- rbind(selecLociMat,selecLoci)
    selecChrMat <- rbind(selecChrMat,selecChrs)


  ############################################################
  # run the simulation
  ############################################################
  maxID <- max(allPopMat[,1])

  for (i in 1:runTime){

    ##################################################
    # dispersal of juveniles
    ##################################################

    juvies <- NULL
    juvies <- which (popMat[,3] == 0)

    juvHybInds <- NULL      # hybrid indices of the juvies
    juvHybInds <- popMat[juvies,4]

    juvXLoc <- popMat[juvies,7] # location of each juvie in the 2D space
    juvYLoc <- popMat[juvies,8]

    expRate <- 1/meanDispDist    # exponential rate of decline in dispersal probability with distance

    ###############################################
    # assign new X and Y location for each juvenile
    ###############################################

    newX <- rep(NA,length(juvXLoc))
    newY <- rep(NA,length(juvYLoc))
    candX <- seq(0,habSize,habSize/5000)    # all possible new locations
    candY <- seq(0,habSize,habSize/5000)

    for(j in 1:length(newX)){
      newX [j] <- sample(candX,1,prob=dexp(abs(candX-juvXLoc[j]),rate=expRate))
      newY [j] <- sample(candY,1,prob=dexp(abs(candY-juvYLoc[j]),rate=expRate))
    }

    popMat[juvies,7] <- newX
    popMat[juvies,8] <- newY


    ########
    # mating
    ########

    offspring <- NULL # matrix to store the new offspring demographic data (i.e., hybrid index, parents, etc.)
    offChr1 <- list() #list of length 'chroms' storing the maternal chromosome copies
    offChr2 <- list() #list of length 'chroms' storing the paternal chromosome copies
    numOffs <- ageStruc[1]*popSize           # total number of offspring to produce for EACH population

    thisDat <- NULL
    thisDat <- popMat

    matFems <- NULL      # mature females
    pickFemales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 0)
    matFems <- thisDat[pickFemales,1]

    matFemHybInd <- thisDat[pickFemales,6]       # female hybrid indices at the loci affecting fitness

    candMales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 1) # mature males

    maleHybInd <- thisDat[candMales,4]   # hybrid indices of males (at all loci) that are mature and could breed

    maleLocs <- thisDat[candMales,7:8]
    matFemLocs <- thisDat[pickFemales,7:8]

    #### pick males for the females to breed with.... Only one male per female. Males can mate with multiple females

    pickMales <- rep(NA,length(matFems))
    for (v in 1:length(matFems)){
      femLoc <- matFemLocs[v,]                     # calculate the distance from the focal female to each of the males
      toMaleDist <- rep(NA,length(candMales))

      for(j in 1:length(toMaleDist)){
        maleLoc <- maleLocs[j,]
        toMaleDist[j] <- sqrt((femLoc[1]-maleLoc[1])^2+(femLoc[2]-maleLoc[2])^2)
      }

      if(matingDistRate != 0){distWeights <- dexp(toMaleDist,rate=matingDistRate)}
      if(matingDistRate == 0){distWeights <- 1}

      pickMales [v] <- sample(candMales,size=1,prob= (1 - abs(matFemHybInd[v] - maleHybInd)*assortWeight)*distWeights,replace=FALSE) # pair males with females according to distance and difference in hybrid index
    }

    matMales <- NULL                  # mature males
    matMales <- thisDat[pickMales,1]  # males that will be paired with females
    matMaleHybInd <- NULL
    matMaleHybInd <- thisDat[pickMales,4]

    # make offspring
    matePairs <- NULL
    matePairs <- cbind(matFems,matFemHybInd,matMales,matMaleHybInd,matFemLocs)     # pairs of candidate parents

    femSelecGenos1 <- NULL    # female genotypes at loci affecting fitness
    femSelecGenos2 <- NULL    # female genotypes at loci affecting fitness
    for(z in 1:length(selecChrs)){
      femSelecGenos1 <- cbind(femSelecGenos1,chr1List[[selecChrs[z]]][match(matFems,chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      femSelecGenos2 <- cbind(femSelecGenos2,chr2List[[selecChrs[z]]][match(matFems,chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
    }

    femSelecGenos <- 2 - (femSelecGenos1 + femSelecGenos2)    # The number of population 1 alleles each female has at each selected locus
    newFemSelecGenos <- femSelecGenos # a copy of femSelecGenos for simulating local adaptation

    ######################################
    # get genotypes at the modifier loci
    ######################################

      femModGenos1 <- NULL    # female genotypes at loci affecting fitness
      femModGenos2 <- NULL    # female genotypes at loci affecting fitness
      for(z in 1:length(selecChrs)){
        femModGenos1 <- cbind(femModGenos1,chr1List[[modChrs[z]]][match(matFems,chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
        femModGenos2 <- cbind(femModGenos2,chr2List[[modChrs[z]]][match(matFems,chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
      }

      femModGenos <- 2 - (femModGenos1 + femModGenos2)    # The number of population 1 alleles each female has at each modifier locus
      newFemModGenos <- femModGenos

      matFemPop1 <- NULL
      if(sum(matFemLocs[,1] < contactLine) > 0){matFemPop1 <- which(matFemLocs[,1] < contactLine)}  # indicate if each female is to the left of the contact line. This is used to simulate local adaptation for reproduction

      if(is.null(matFemPop1) == FALSE){                                   # switch the allele counts in pop 1 individuals at selected loci to indicate the number of non-native alleles for all individuals
        for(z in matFemPop1){
          if(sum(femSelecGenos[z,] == 2) > 0){newFemSelecGenos[z,which(femSelecGenos[z,] == 2)] <- 0}
          if(sum(femSelecGenos[z,] == 0) > 0){newFemSelecGenos[z,which(femSelecGenos[z,] == 0)] <- 2}
          if(sum(femModGenos[z,] == 2) > 0){newFemModGenos[z,which(femModGenos[z,] == 2)] <- 0}
          if(sum(femModGenos[z,] == 0) > 0){newFemModGenos[z,which(femModGenos[z,] == 0)] <- 2}
        }
      }

    if(invRelRepro < 0){newFemModGenos <- 2 - newFemModGenos; newFemSelecGenos <- 2 - newFemSelecGenos}  # invert the genotypes at selected and modifier loci (to the number of native alleles) if natives are fitter than non-natives; now
                                                                                                                          # the genotypes give the number of the most fit allele at both fitness and modifier loci

    locusEffsize <- ((invRelRepro)/numSelecLoci)/2                             # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
    modEffSize <- epiSize/2                                                    # Additive effect at each modifier locus (half the difference between homozygous genotypes)
    modValMat <- matrix(0,nrow(newFemModGenos),ncol(newFemModGenos))     # Matrix to store the genetic values at modifier loci
    genValMat <- matrix(0,nrow(newFemSelecGenos),ncol(newFemSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus

    for(z in 1:ncol(newFemSelecGenos)){

      if(sum(newFemSelecGenos[,z] == 1) > 0 & nativeDom == TRUE) {genValMat [which(newFemSelecGenos[,z] == 1),z] <- locusEffsize + (repro_d * locusEffsize)} #genetic value of heterozygotes at fitness loci, accounting for dominance
      if(sum(newFemSelecGenos[,z] == 1) > 0 & nativeDom == FALSE){genValMat [which(newFemSelecGenos[,z] == 1),z] <- locusEffsize - (repro_d * locusEffsize)}
      if(sum(newFemSelecGenos[,z] == 2) > 0){genValMat [which(newFemSelecGenos[,z] == 2),z] <- 2 * locusEffsize}

      if(epiSize > 0){
        if(sum(newFemModGenos[,z] == 1) > 0 & nativeDom == TRUE)  {modValMat [which(newFemModGenos[,z] == 1),z] <- modEffSize + (epiDom * modEffSize)} #genetic value of heterozygotes at modifier loci, accounting for dominance
        if(sum(newFemModGenos[,z] == 1) > 0 & nativeDom == FALSE) {modValMat [which(newFemModGenos[,z] == 1),z] <- modEffSize - (epiDom * modEffSize)}
        if(sum(newFemModGenos[,z] == 2) > 0) {modValMat [which(newFemModGenos[,z] == 2),z] <-  1}
      }
    }
    modValMat <- 1 - modValMat

    minGenVal <- min(c(0,locusEffsize*2))
    maxGenVal <- max(c(0,locusEffsize*2))

    genValMat2 <- matrix(NA,nrow=nrow(genValMat),ncol=ncol(genValMat))

    for(e in 1:ncol(genValMat2)){
      if(sum(newFemSelecGenos[,e] == 0) > 0){         # genetic values of individuals that are homozygous for the least fit allele
        zeros <- which(newFemSelecGenos[,e] == 0)
        genValMat2[zeros,e] <- genValMat[zeros,e]
      }
      if(sum(newFemSelecGenos[,e] %in% c(1,2)) > 0){
        onesTwos <- which(newFemSelecGenos[,e] %in% c(1,2))
        genValMat2[onesTwos,e] <- genValMat[onesTwos,e] - modValMat[onesTwos,e]*(genValMat[onesTwos,e] - minGenVal)
      }
    }

    femWeights <- NULL
    femWeights <-  1 + rowSums(genValMat2)
    parentPairs<- NULL              # randomly selected parents of each offspring weighted by the hybrid index of the female at fitness loci
                                    # this is done separately for the left and right of the contactLine
    spec1Mates <- matePairs[which(matePairs[,5] <= contactLine),]
    spec2Mates <- matePairs[which(matePairs[,5] > contactLine),]

    spec1FemWeights <- femWeights[which(matePairs[,5] <= contactLine)]
    spec2FemWeights <- femWeights[which(matePairs[,5] > contactLine)]

    parentPairs <- spec1Mates[sample(1:nrow(spec1Mates),size=numOffs/2,replace=TRUE,prob=spec1FemWeights),]
    parentPairs <- rbind(parentPairs,spec2Mates[sample(1:nrow(spec2Mates),size=numOffs/2,replace=TRUE,prob=spec2FemWeights),])

    fry <- NULL   # this years offspring
    fryIDs <- (maxID+1):(maxID+numOffs)    # IDs for the offspring
    maxID <- max(fryIDs)
    fryPop <- rep(1,length(fryIDs))
    fryAge <- rep(0,length(fryIDs))
    frySex <- rep(c(0,1),length(fryIDs)/2)
    fryLoc <- popMat[match(parentPairs[,1],popMat[,1]),7:8]
    fryMoms <- parentPairs[,1]
    fryDads <- parentPairs[,3]

    #######################################################
    # calculate the genomic hybrid index of each offspring
    #######################################################

    #### meiosis

    nonNatAllsMom <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
    nonNatAllsDad <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual

    for(k in 1:chroms){
      momsCopy1 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],popMat[,1]),])
      dadsCopy1 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],popMat[,1]),])

      momsCopy2 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], popMat[,1]),])
      dadsCopy2 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], popMat[,1]),])

      momRecs <- rpois(n=length(fryIDs),lambda=mapLeng[k]/100)    # number of recombination events in the mom
      dadRecs <- rpois(n=length(fryIDs),lambda=mapLeng[k]/100)    # number of recombination events in the dad

      fryChromOnes <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
      fryChromTwos <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))

      for(l in 1:nrow(fryChromOnes)){
        # maternal chromosome

        momStartChrom <- sample(c(1,2),1)
        momChrom <- NULL

        momRecLocs <- c(sort(sample(1:(nChromLoci-1),momRecs[l],replace=FALSE)),nChromLoci)
        if(length(momRecLocs)>1){
          momBeginLocs <- c(1,momRecLocs[1:(length(momRecLocs)-1)] + 1)
          momBeginLocs [length(momBeginLocs)] <-c(momRecLocs[length(momRecLocs)-1]+1)
        }

        if(length(momRecLocs) == 1){
          momBeginLocs <- 1
        }

        if(momStartChrom == 1){
          for(m in 1:length(momRecLocs)){
            if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
          }
        }

        if(momStartChrom == 2){
          for(m in 1:length(momRecLocs)){
            if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
          }
        }

        fryChromOnes [l,2:ncol(fryChromOnes)] <- momChrom
        # paternal chromosome

        dadStartChrom <- sample(c(1,2),1)
        dadChrom <- NULL

        dadRecLocs <- c(sort(sample(1:(nChromLoci-1),dadRecs[l],replace=FALSE)),nChromLoci)

        if(length(dadRecLocs)>1){
          dadBeginLocs <- c(1,dadRecLocs[1:(length(dadRecLocs)-1)] + 1)
          dadBeginLocs [length(dadBeginLocs)] <-c(dadRecLocs[length(dadRecLocs)-1]+1)
        }

        if(length(dadRecLocs) == 1){
          dadBeginLocs <- 1
        }

        if(dadStartChrom == 1){
          for(m in 1:length(dadRecLocs)){
            if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
          }
        }

        if(dadStartChrom == 2){
          for(m in 1:length(dadRecLocs)){
            if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
          }
        }
        fryChromTwos[l,2:ncol(fryChromTwos)] <- dadChrom
      }

      offChr1[[k]] <- fryChromOnes
      offChr2[[k]] <- fryChromTwos

      nonNatAllsMom <- cbind(nonNatAllsMom,rowSums(fryChromOnes[,2:ncol(fryChromOnes)] == 0))
      nonNatAllsDad <- cbind(nonNatAllsDad,rowSums(fryChromTwos[,2:ncol(fryChromTwos)] == 0))
    }

    fryPercRBT <- rowSums(cbind(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry

    fryOut <- cbind(fryIDs,fryPop,fryAge,fryPercRBT,frySex,fryLoc,fryMoms,fryDads,rep(i,length(fryIDs)))
    colnames(fryOut) <- NULL
    offspring <- rbind(offspring,fryOut)

    ###########################################
    # get the hybrid index at fitness loci
    ###########################################

    selecPercRBT <- rep(NA,length(fryPercRBT))
    selecGenos <- NULL

    for(z in 1:length(selecChrs)){
      selecGenos <- cbind(selecGenos,offChr1[[selecChrs[z]]][,selecLoci[z]+1],offChr2[[selecChrs[z]]][,selecLoci[z]+1])
    }
    selecPercRBT <- 1 - rowSums(selecGenos)/ncol(selecGenos)
    offspring <- cbind(offspring[,1:5],selecPercRBT,offspring[,6:10])

    ##################################################
    # advance the population to the next year
    ##################################################

    newPop <- NULL          # temporarily store the new population data
    keepIndices <- NULL     # vector of the IDs of individuals surviving to the next year

    for(e in 1:2){

      for (k in 1:(length(ageStruc)-1)){       # select individuals in each age class to survive to the next year (all individuals in the last age class die)
        ageDat <- NULL
        if(e == 1){ageDat <- popMat[which(popMat[,3] == ages[k] & popMat[,7] <= contactLine),]} # individuals in age class k for the jth population
        if(e == 2){ageDat <- popMat[which(popMat[,3] == ages[k] & popMat[,7]  > contactLine),]}

        ageSelecGenos1 <- NULL    # genotypes of individuals in the kth age class at fitness loci
        ageSelecGenos2 <- NULL

        for(z in 1:length(selecChrs)){
          ageSelecGenos1 <- cbind(ageSelecGenos1,chr1List[[selecChrs[z]]][match(ageDat[,1],chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
          ageSelecGenos2 <- cbind(ageSelecGenos2,chr2List[[selecChrs[z]]][match(ageDat[,1],chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        }

        ageSelecGenos <- 2 - (ageSelecGenos1 + ageSelecGenos2)    # The number of population 1 alleles each individual has at each selected locus
        newageSelecGenos <- ageSelecGenos                         # a copy of femSelecGenos for simulating local adaptation

        ######################################
        # get genotypes at the modifier loci
        ######################################

        ageModGenos1 <- NULL    # age class genotypes at modifier loci
        ageModGenos2 <- NULL
        for(z in 1:length(selecChrs)){
          ageModGenos1 <- cbind(ageModGenos1,chr1List[[modChrs[z]]][match(ageDat[,1],chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
          ageModGenos2 <- cbind(ageModGenos2,chr2List[[modChrs[z]]][match(ageDat[,1],chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
        }

        ageModGenos <- 2 - (ageModGenos1 + ageModGenos2)    # The number of population 1 alleles each female has at each modifier locus
        newageModGenos <- ageModGenos

        agePop1 <- NULL
        if(sum(ageDat [,7] <= contactLine) > 0){agePop1 <- which(ageDat[,7] <= contactLine)}

        if(is.null(agePop1) == FALSE){                                   # switch the allele counts at selected loci in population one to indicate the number of non-native alleles for all individuals in each population
          for(z in agePop1){
            if(sum(ageSelecGenos[z,] == 2) > 0){newageSelecGenos[z,which(ageSelecGenos[z,] == 2)] <- 0}
            if(sum(ageSelecGenos[z,] == 0) > 0){newageSelecGenos[z,which(ageSelecGenos[z,] == 0)] <- 2}
            if(sum(ageModGenos[z,] == 2) > 0){newageModGenos[z,which(ageModGenos[z,] == 2)] <- 0}
            if(sum(ageModGenos[z,] == 0) > 0){newageModGenos[z,which(ageModGenos[z,] == 0)] <- 2}
          }
        }

        if(invRelSurv < 0){newageModGenos <- 2 - newageModGenos; newageSelecGenos <- 2 - newageSelecGenos}  # invert the genotypes at selected and modifier loci (to the number of native alleles) if natives are fitter than natives
                                                                                                            # these genotypes now give the number of the most fit allele at both fitness and modifier loci

        locusEffsize <- ((invRelSurv)/numSelecLoci)/2                              # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
        modEffSize <- epiSize/2                                                    # Additive effect at each modifier locus (half the difference between homozygous genotypes)
        modValMat <- matrix(0,nrow(newageModGenos),ncol(newageModGenos))           # Matrix to store the genetic values at modifier loci
        genValMat <- matrix(0,nrow(newageSelecGenos),ncol(newageSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus

        for(z in 1:ncol(newageSelecGenos)){

          if(sum(newageSelecGenos[,z] == 1) > 0 & nativeDom == TRUE) {genValMat [which(newageSelecGenos[,z] == 1),z] <- locusEffsize + (repro_d * locusEffsize)} #genetic value of heterozygotes at fitness loci, accounting for dominance
          if(sum(newageSelecGenos[,z] == 1) > 0 & nativeDom == FALSE){genValMat [which(newageSelecGenos[,z] == 1),z] <- locusEffsize - (repro_d * locusEffsize)}
          if(sum(newageSelecGenos[,z] == 2) > 0){genValMat [which(newageSelecGenos[,z] == 2),z] <- 2 * locusEffsize}

          if(epiSize > 0){
            if(sum(newageModGenos[,z] == 1) > 0 & nativeDom == TRUE)  {modValMat [which(newageModGenos[,z] == 1),z] <- modEffSize + (epiDom * modEffSize)} #genetic value of heterozygotes at modifier loci, accounting for dominance
            if(sum(newageModGenos[,z] == 1) > 0 & nativeDom == FALSE) {modValMat [which(newageModGenos[,z] == 1),z] <- modEffSize - (epiDom * modEffSize)}
            if(sum(newageModGenos[,z] == 2) > 0) {modValMat [which(newageModGenos[,z] == 2),z] <-  1}
          }
        }
        modValMat <- 1 - modValMat
        minGenVal <- min(c(0,locusEffsize*2))
        maxGenVal <- max(c(0,locusEffsize*2))

        genValMat2 <- matrix(NA,nrow=nrow(genValMat),ncol=ncol(genValMat))

        for(b in 1:ncol(genValMat2)){
          if(sum(newageSelecGenos[,b] == 0) > 0){         # genetic values of individuals that are homozygous for the least fit allele
            zeros <- which(newageSelecGenos[,b] == 0)
            genValMat2[zeros,b] <- genValMat[zeros,b]
          }

          if(sum(newageSelecGenos[,b] %in% c(1,2)) > 0){
            onesTwos <- which(newageSelecGenos[,b] %in% c(1,2))
            genValMat2[onesTwos,b] <- genValMat[onesTwos,b] - modValMat[onesTwos,b]*(genValMat[onesTwos,b] - minGenVal)
          }

        }

        survWeights <-  1 + rowSums(genValMat2)
        keepIds <- sample(ageDat[,1],size=ageStruc[k+1]*(popSize/2),replace=FALSE,prob = survWeights)
        keepIndices <- append(keepIndices,which(popMat[,1] %in% keepIds))
      }
    }

    keepIndices <- sort(keepIndices)
    newPop <- popMat[keepIndices,]
    newPop[,3] <- newPop[,3] + 1
    newPop <- rbind(newPop,offspring) # the new population

    ##################################################################################
    # update the genetic data to contain only the individuals passing to the next year
    ##################################################################################

    for(k in 1:length(chr1List)){
      chr1List[[k]] <- chr1List[[k]][keepIndices,]
      chr2List[[k]] <- chr2List[[k]][keepIndices,]

      chr1List[[k]] <- rbind(chr1List[[k]],offChr1[[k]])
      chr2List[[k]] <- rbind(chr2List[[k]],offChr2[[k]])
    }

    #######################################
    # save the new genotypes from this year
    #######################################

    newGenos <- which(chr1List[[1]][,1] %in% allChr1[[1]][,1] == FALSE)

    for(k in 1:length(chr1List)){
      allChr1[[k]] <- rbind(allChr1[[k]],chr1List[[k]][newGenos,])
      allChr2[[k]] <- rbind(allChr2[[k]],chr2List[[k]][newGenos,])

    }

    newPop[,ncol(newPop)] <- rep(i,nrow(newPop)) # update the year
    popMat <- newPop  # replace this year's population with the next

    #######################################
    # save the new individuals in allPopMat
    #######################################
    allPopMat <- rbind(allPopMat,newPop)
    print(paste("done with year", i))
  }


  ######################
  # format the genotypes
  ######################

  genos_012 <- NULL    # genotype file giving the count of native alleles at each locus for each individual
  # individuals are in rows, loci are in columns (on column per locus)
  genoNames <- allChr1[[1]][,1]
  for(i in 1:length(chr2List)){
    genos_012 <- cbind(genos_012,allChr1[[i]][,2:ncol(allChr1[[i]])]+allChr2[[i]][,2:ncol(allChr2[[i]])])
  }


  fstAlls <- seq(from=1,to=2*ncol(genos_012),by=2)
  secAlls <- seq(from=2,to=2*ncol(genos_012),by=2)

  atMat <- matrix(NA,nrow=nrow(genos_012),ncol=ncol(genos_012)*2)   # genotype file with A = native allele, T = non-native allele
  # individuals are in rows, loci in columns (two adjacent columns
  # per locus); first column is individual ID


  for(i in 1:ncol(genos_012)){
    atMat[which(genos_012[,i] == 0),fstAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),fstAlls[i]] <- "A"
    atMat[which(genos_012[,i] == 2),fstAlls[i]] <- "A"

    atMat[which(genos_012[,i] == 0),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 1),secAlls[i]] <- "T"
    atMat[which(genos_012[,i] == 2),secAlls[i]] <- "A"
  }
  genos_012 <- cbind(genoNames,genos_012)
  atMat <- cbind(genoNames,atMat)

  admixRes <- list(allPopMat,genos_012,atMat,selecChrMat,selecLociMat)

  return(admixRes)
}


