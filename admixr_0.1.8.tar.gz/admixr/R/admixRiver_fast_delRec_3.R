#' A function to simulate hybridization in a river system.
#'
#' This function runs a forward-time spatially and genomically explicit simulation of hybridization in a
#'     river system with a mainstem and tributaries.
#' @param importNetwork. Set to NULL if not importing a custom river network. Otherwise, the imported network is represented as a data
#'     frame with first column defining the distance from stocking site (bottom end of the network) to each tributary confluence, and the second column
#'     giving the distance from the main stem-tributary confluence to the single spawning ground up each tributary.
#' @param mainStemLeng The length of the mainstem in kilometers.
#' @param tribNum The number of evenly spaced tributaries in the river system.
#' @param tribLeng The length of each tributary in kilometers.
#' @param popSize The population size in each tributary.
#' @param nativeDispProb Probability of a pure native juvenile individual dispersing.
#' @param maxDispProb Probability of a pure non-native juvenile individual dispersing.
#' @param barrierLoc numeric. Number of headwater streams to place above a barrier to non-native immigration. Set to 0 for no barrier.
#' @param nonNatThresh numeric. The hybrid index above which an individual cannot go above the barrier.
#' @param repro_d numeric. The dominance of fitness loci for fedundity. 0 = no dominance. 1 = complete dominance.
#' @param surv_d numeric. The dominance of fitness loci for survival. 0 = no dominance. 1 = complete dominance.
#' @param fitDom logical. TRUE if higher fitness alleles are dominant over lower fitness alleles, FALSE if less fit alleles alleles are dominant over more fit alleles
#'     at all fitness and modifier loci. If invRelRepro and invRelSurv are negative, then TRUE means that the native allele is dominant over the non-native allele.
#' @param epiDom numeric. The dominance at modifier loci. 0 = no dominance. 1 = complete dominance. Must range from 0 to 1.
#' @param numSelecLoci numeric. The number of loci in the genome that affect fitness. The same loci affect survival and reproduction. The fitness effects on survival and reproduction
#'     are spread evenly over these loci. The fitness loci are selected at random from all sites across the genome.
#' @param numDelRec numeric. Number of loci with fixed deleterious recessive alleles in the genomes of natives, and separately, in the genomes of the invading population
#' @param delRecEffNat_repro numeric. The proporional reduction in reproduction due to fixed deleterious recessive alleles in the native population.
#' @param delRecEffInv_repro numeric. The proporional reduction in reproduction due to fixed deleterious recessive alleles in the invasive population.
#' @param delRecEffNat_surv numeric. The proporional reduction in survival due to fixed deleterious recessive alleles in the native population.
#' @param delRecEffInv_surv numeric. The proporional reduction in survival due to fixed deleterious recessive alleles in the invasive population.
#' @param ages numeric. The ages of individuals in the population. Starting with 0 for young-of-the-year.
#' @param ageMaturity numeric. The age at which an individual is capable of reproducing.
#' @param ageStruc numeric. A vector giving the proportion of the population in each of the age classes. Must sum to one.
#' @param reproRatio numeric. The excess of offspring produced each year. Must be at least 1. 1 means exactly ageStruc[1]*popSize offspring are produced. A value of one means there
#'     can be no viability selection on young of the year. 2 means twice the number of offspring needed are produced.
#' @param invRelSurv numeric. Baseline signed difference in survival of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-natives have higher survival than natives. Negative values mean that non-natives have lower survival than natives.
#' @param invRelSurv_top numeric. The signed difference in survival of pure non-natives compared to pure natives at the highest point in the river network.
#'     Set to NULL for constant invRelSurv throughout the river network. Relative hybrid survival probability will be linearly interpolated for intermediate locations.
#' @param invRelRepro numeric. Baseline signed difference in female fedundity of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-natives have higher reproduction than natives. Negative
#'     values mean that non-natives have lower reproduction than natives.
#' @param invRelRepro_top numeric. The signed difference in fecundity of pure non-natives compared to pure natives at the highest point in the river network.
#'     Set to NULL for constant invRelRepro throughout the river network. Relative hybrid fecundity will be linearly interpolated for intermediate locations.
#' @param assortWeight numeric. The strength of positive assortative mating. Must range from 0 to 1. 1 means complete
#'     assortative mating (pure non-natives and pure natives will never mate), 0 means no assorative mating.
#' @param stockYears numeric. The years in the simulation that non-native individuals will be stocked at the bottom end
#'     of the mainstem.
#' @param stockAge numeric. The age of non-native indiviudals that will be stocked.
#' @param stockNum numeric. The number of non-native individuals that will be stocked each of stockYears.
#' @param nChromLoci numeric. The number of evenly spaced ancestry-informative loci on each chromosome.
#' @param chroms numeric. The number of chromosomes.
#' @param mapLeng numeric. The genetic map length of each chromosome (in centiMorgans).
#' @param runTime numeric. The number of years to run the simulation.
#' @details
#'    The output from this function is a list with five elements. The first element is a data frame with the following columns: Individual identification number,
#'    population number, age, the hybrid index (fraction of genome that is non-native), sex, the hybrid index at fitness
#'    loci, mother, father, and year. Only individuals that survived to age one are included. Every individual in the population is represented for each year. For example, an individual
#'    that was born in year 5 and died in year 7 will be represented in three rows (one for each of years 5-7).
#'
#'    The second element contains the genotypes of all individuals in 012 format. The first column is the individual identification number. The
#'    remaining columns are genotypes given as the number of non-native alleles at each locus in the genome. Loci are ordered left to right,
#'    starting with the first locus on chromosome 1, and so on.
#'
#'    The third element is a data frame containing the genotypes at "AT" format. T is the non-native allele and A is the native allele at each locus. The
#'    first column is the individual identification number. The remaining columns are individual genotypes, ordered from left to right, beginning
#'    with the first locus on chromosome one. Each locus is represented by two columns, such that the total number of columns is two times the number
#'    of loci plus one.
#'
#'    The fourth element is a vector giving the chromosome locations of fitness loci.
#'
#'    The fifth element is a vector giving the location of each fitness locus in centiMorgans.

#' @examples
#'     library(admixr)
#'     # simulate admixture in a river system
#'     tryRiver <- admixRiver_fast(importNetwork = NULL,mainStemLeng=100,tribNum=10,tribLeng=10,popSize=200,nativeDispProb=0.05,maxDispProb=0.5,barrierLoc=0,lambda=0.05,
#'                            nonNatThresh=0.5,repro_d=1,surv_d=1,fitDom=TRUE,epiSize=1,epiDom=1,fitDomEpi=FALSE,numSelecLoci=10,numDelRec=20,
#'                            delRecEffNat_repro = 0.2,delRecEffInv_repro = 0.2,delRecEffNat_surv= 0.2,delRecEffInv_surv=0.2,ages=c(0,1,2),
#'                            ageMaturity=1,ageStruc=c(0.5,0.3,0.2),reproRatio=2,invRelSurv=0,invRelRepro=0,assortWeight=0,stockYears=1:10,
#'                            stockAge=1,stockNum=100,nChromLoci=100,chroms=4,mapLeng=50,runTime=10)
#'
# plot the results from year 10 of the simulation
#'     plotRiver(admixDat=tryRiver,mainStemLeng=100,tribLeng=10,yearPlot=10)
#' @export

admixRiver_fast_delRec <- function (importNetwork,mainStemLeng,tribNum,tribLeng,lambda,popSize,nativeDispProb,maxDispProb,barrierLoc,nonNatThresh,fitDom,
                             epiSize,epiDom,fitDomEpi,ages,ageMaturity,ageStruc,reproRatio,repro_d,surv_d,numSelecLoci,numDelRec,delRecEffNat_repro,
                             delRecEffInv_repro,delRecEffNat_surv,delRecEffInv_surv,epiRelSurv,epiRelRepro,invRelSurv,invRelRepro,F1Heterosis,
                             assortWeight,stockYears,stockAge,stockNum,nChromLoci,chroms,mapLeng,runTime){

  #################################################################
  # assign movement probability between each pair of tributaries
  #################################################################

  ###### without importing a custom river network
  if(is.null(importNetwork)){
    confs <- seq(mainStemLeng/tribNum,mainStemLeng,mainStemLeng/tribNum)  # locations of the confluences of tributaries and the mainstem
    tribSideLeng <- sqrt((tribLeng^2)/2)
    tribAbsLeng <- rep(tribLeng,length(confs))
    sites <- 1:tribNum                                                    # spawning site identifications
    distMat <- matrix(NA,nrow=length(sites),ncol=length(sites))   # matrix of pairwise distances between spawning sites
    bifMat  <- matrix(NA,nrow=length(sites),ncol=length(sites))    # matrix of pairwise number of bifurcations separating spawning sites
    for(i in 1:length(sites)){
      distMat[i,] <- abs(confs[i] - confs) + 2*tribLeng
      distMat[i,i] <- 0
      bifMat[i,] <- abs(i - 1:length(confs))
      bifMat[i,i] <- 0
    }
    movProbs <-  matrix(NA,nrow=length(sites),ncol=length(sites))  # matrix of probabilities of movement of
    # fish from one site to another (assuming it is a disperser)
    movProbs <- (1/(2*bifMat))*exp(-lambda*distMat)
    for (i in 1:nrow(movProbs)){
      movProbs[i,i] <- NA
    }
    for (i in 1:nrow(movProbs)){
      movProbs[i,i] <- 1-sum(movProbs[i,],na.rm=TRUE)
    }
  }

  ###### when importing a custom river network
  if(is.null(importNetwork) == FALSE){
    confs <- importNetwork[,1]
    tribSideLeng <- sqrt((importNetwork[,2]^2)/2)
    tribAbsLeng <- importNetwork[,2]
    sites <- 1:nrow(importNetwork)                                                  # spawning site identifications
    distMat <- matrix(NA,nrow=length(sites),ncol=length(sites))   # matrix of pairwise distances between spawning sites
    bifMat  <- matrix(NA,nrow=length(sites),ncol=length(sites))    # matrix of pairwise number of bifurcations separating spawning sites
    for(i in 1:length(sites)){
      distMat[i,] <- abs(confs[i] - confs) + (importNetwork[i,2] + importNetwork[,2])
      distMat[i,i] <- 0
      bifMat[i,] <- abs(i - 1:length(confs))
      bifMat[i,i] <- 0
    }
    movProbs <-  matrix(NA,nrow=length(sites),ncol=length(sites))  # matrix of probabilities of movement of
    # fish from one site to another (assuming it is a disperser)
    movProbs <- (1/(2*bifMat))*exp(-lambda*distMat)
    for (i in 1:nrow(movProbs)){
      movProbs[i,i] <- NA
    }
    for (i in 1:nrow(movProbs)){
      movProbs[i,i] <- 1-sum(movProbs[i,],na.rm=TRUE)
    }
  }


  ##########################################################
  # populate the network with genetically pure native fish
  ##########################################################
  ageVec <- NULL
  for (i in 2:length(ages)){
    ageVec <- c(ageVec,rep(ages[i],ageStruc[i]*popSize))
  }
  pop <- NULL
  age <- NULL
  for(i in 1:length(confs)){
    pop  <- c(pop,rep(i,length(ageVec)))
    age <- c(age,ageVec)
  }
  id <- 1:length(pop)
  yearVec <- rep(0,length(pop))
  percRBT <- rep(0,length(pop))      # hybrid index initialized at zero for all native fish
  sex <- rep(c(0,1),length(pop)/2)
  popMat <- NULL                      # matrix to store all of the individuals in the river system
  selecPercRBT <- rep(0,length(pop))  # hybrid index at the loci affecting fitness
  mom <- rep(NA,length(pop))
  dad <- rep(NA,length(pop))
  survVec <- rep(1,length(pop))    # vector indicating that all the initial individuals survived to the next year
  allPopMat <- cbind(id,pop,age,percRBT,sex,selecPercRBT,mom,dad,yearVec,survVec) # matrix to store all of the population data throughout the simulation
  allPopMat <- allPopMat[which(allPopMat[,3] > 0),]    # eliminate the zero age class
  popMat <- allPopMat # matrix to store the individuals that are in the population currently
  colonizProbs <- movProbs[1,]

  ###########################################
  # initialize the genome matrices
  ###########################################
  listNames <- paste("popGenDat",1:length(confs),sep="")
  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  for(i in 1:chroms){
    chr1List [[i]]<- cbind(popMat[,1],matrix(1,nrow=nrow(popMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
    chr2List [[i]]<- cbind(popMat[,1],matrix(1,nrow=nrow(popMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
  }

  #######################
  # identify fitness loci
  #######################


  selecLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  selecChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression
  delRecLociMat <- NULL    # matrices storing the positions of loci with deleterious recessive alleles
  delRecChrMat <- NULL
  delRecChrs <- sort(sample(1:chroms,numDelRec*2,replace=TRUE))
  selecChrs <- sort(sample(1:chroms,numSelecLoci,replace=TRUE))
  selecLoci <- NULL
  delRecLoci <- NULL


  for(i in 1:chroms){
    possibleLoci <- 1:nChromLoci
    if(i %in% selecChrs){
      theseSelecLoci <- sort(sample(possibleLoci,sum(selecChrs == i),replace=FALSE))
      selecLoci <- c(selecLoci,theseSelecLoci)
      possibleLoci <- possibleLoci[-theseSelecLoci]
    }
    if(i %in% delRecChrs){
      delRecLoci <- c(delRecLoci,sort(sample(possibleLoci,sum(delRecChrs == i),replace=FALSE)))
    }
 }

  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat <- rbind(selecChrMat,selecChrs)

  delRecLociMat <- rbind(delRecLociMat,delRecLoci)
  delRecChrMat <-  rbind(delRecChrMat,delRecChrs)

  ##############################################################################
  # select modifier loci to interact epistatically with the fitness loci
  ##############################################################################
  modLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  modChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression
  modChrs <- rep(NA,length(selecChrs))
  for(i in 1:length(modChrs)){
    if(chroms > 2) {modChrs [i] <- sample( (1:chroms)[which( (1:chroms) != selecChrs[i])],1)}
    if(chroms == 2){modChrs [i] <- (1:chroms)[which( (1:chroms) != selecChrs[i])]}
  }
  modLoci <- NULL
  uniChrs <- unique(modChrs)
  for(i in 1:length(uniChrs)){
    keepLoci <- 1:nChromLoci
    if(sum(selecChrs == uniChrs[i]) > 0){
      keepLoci <- keepLoci[which(keepLoci %in% c(selecLoci[which(selecChrs == uniChrs[i])]) == FALSE)]
    }
    if(sum(delRecChrs == uniChrs[i]) > 0){
      if(sum(keepLoci %in% delRecLoci[which(delRecChrs == uniChrs[i])]) > 0){
        keepLoci <- keepLoci[which(keepLoci %in% delRecLoci[which(delRecChrs == uniChrs[i])] == FALSE)]
      }
    }
    modLoci <- c(modLoci,sort(sample(keepLoci,sum(modChrs == uniChrs[i]),replace=FALSE)))
  }
  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat <- rbind(selecChrMat,selecChrs)

  ############################################
  # make map files for all and selected loci
  ############################################
  lociMap <- NULL
  for (j in 1:chroms){
    chr <- rep(j,nChromLoci)
    pos <- seq(0,mapLeng,mapLeng/(nChromLoci-1))
    thisMap <- cbind(chr,pos)
    lociMap <- rbind(lociMap,thisMap)
  }
  if(numSelecLoci > 0){
    selecLociMap <- NULL
    for(j in 1:length(selecLoci)){
      outVec <- c(lociMap[which(lociMap[,1] == selecChrs[j])[selecLoci[j]],])
      selecLociMap <- rbind(selecLociMap,outVec)
    }
  }
  snpLocs <- lociMap[which(lociMap[,1] == 1),2]



  #####################
  # run the simulation
  #####################
  maxID <- max(allPopMat[,1])
  for (i in 1:runTime){
    ##########################
    # dispersal of juveniles
    ##########################
    for (j in 1:length(confs)){
      thisPopDat <- NULL
      thisPopDat <- popMat[which(popMat[,2] == j & popMat[,10] == 1),]
      juvies <- which (thisPopDat[,3] == 0)
      thisMovProbs <- movProbs[j,]    # vector of probabilities of dispersal to different spawning grounds
      thisMovProbs[j] <- 0       # do not allow a disperser to select its natal spawning ground
      juvHybInds <- thisPopDat[juvies,4]  # hybrid indices of the juveniles
      dispProbs <- nativeDispProb + juvHybInds*(maxDispProb - nativeDispProb)# Probability that each individual will disperse...
      # This depends on the hybridity of the individual as in Della Croce et al. (2014)
      dispTests <- runif(length(dispProbs),min=0,max=1)
      if(sum(dispTests <= dispProbs) > 0){
        dispPops <- rep(NA,sum(dispTests <= dispProbs))
        for (k in 1:length(dispPops)){
          if(barrierLoc == 0 | juvHybInds[k] < nonNatThresh){          # select distination stream for dispersers
            dispPops[k] <- sample(1:length(confs),size=1,prob=thisMovProbs)
          }
          if(barrierLoc > 0 & juvHybInds[k] >= nonNatThresh){          # select destination stream that is below the non-native dispersal barrier for dispersing highly indivdual
            dispPops[k] <- sample(1:(length(confs)-barrierLoc),size=1,prob=thisMovProbs[1:(length(confs)-barrierLoc)])
          }
        }
        dispersers <- juvies[which(dispTests <= dispProbs)]
        popMat[which(popMat[,2] == j)[dispersers],2] <- dispPops
      }
    }

    #######################
    # introduce non-natives
    #######################
    if(i %in% stockYears){
      stockIDs <- (maxID+1):(stockNum + maxID) # ids of the stocked individuals
      maxID <- max(stockIDs)
      stockPop <- rep(1,length(stockIDs))
      stockAges <- rep(stockAge,length(stockIDs))    # age of stocked fish
      stockSex <- rep(c(0,1),length(stockAges)/2)    # sex of stocked fish
      stockRBT <- rep(1,length(stockIDs))            # all stocked fish have a hybrid index of 1
      stockSelecRBT <- rep(1,length(stockIDs))

      #####################################
      # disperse the non-natives
      #####################################
      stockPop <- sample(1:(length(confs)-barrierLoc),size=length(stockIDs),replace=TRUE,prob = colonizProbs[1:(length(confs)-barrierLoc)]) # which population will the stocked fish colonize
      stockMom <- rep(NA,length(stockIDs))
      stockDad <- rep(NA,length(stockIDs))
      year <- rep(i,length(stockIDs))
      stockMat <- cbind(stockIDs,stockPop,stockAges,stockRBT,stockSex,stockSelecRBT,stockMom,stockDad,year,rep(0,length(stockIDs)))
      colnames(stockMat) <- NULL
      popMat <- rbind(popMat,stockMat)
      for(j in 1:length(chr1List)){
        chr1List[[j]] <- rbind(chr1List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))  # add the genomic data from the stocked fish
        chr2List[[j]] <- rbind(chr2List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))
      }
    }

    ##########
    # mating
    ##########
    offspring <- NULL # matrix to store the new offspring demographic data (i.e., hybrid index, parents, etc.)
    offChr1 <- list() #list of length 'chroms' storing the maternal chromosome copies
    offChr2 <- list() #list of length 'chroms' storing the paternal chromosome copies
    for (j in 1:length(confs)){
      numOffs <- ageStruc[1]*popSize*reproRatio           # total number of offspring to produce for EACH population
      thisDat <- popMat[which(popMat[,2] == j),] # population data from the jth tributary
      matFems <- NULL      # mature females
      pickFemales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 0)
      matFems <- thisDat[pickFemales,1] # mature females
      matFemHybInd <- thisDat[pickFemales,4]       # female hybrid indices at the loci affecting fitness
      matFemHybIndSelec <- thisDat[pickFemales,6]
      candMales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 1) # males that are mature and could breed
      maleHybInd <- thisDat[candMales,4]   # hybrid indices of males (at all loci) that are mature and could breed

      #### pick males for the females to breed with.... Onle one male per female. Males can mate with multiple females
      pickMales <- rep(NA,length(matFems))
      for (v in 1:length(matFems)){
        pickMales [v] <- sample(candMales,size=1,prob= (1 - abs(matFemHybInd[v] - maleHybInd)*assortWeight),replace=FALSE)
      }
      matMales <- thisDat[pickMales,1]  # males that will be paired with females
      matMaleHybInd <- thisDat[pickMales,4]
      # make offspring
      matePairs <- cbind(matFems,matFemHybInd,matMales,matMaleHybInd)     # pairs of candidate parents
      femSelecGenos1 <- NULL    # female genotypes at loci affecting fitness
      femSelecGenos2 <- NULL
      for(z in 1:length(selecChrs)){
        femSelecGenos1 <- cbind(femSelecGenos1,chr1List[[selecChrs[z]]][match(matFems,chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        femSelecGenos2 <- cbind(femSelecGenos2,chr2List[[selecChrs[z]]][match(matFems,chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      }
      if(invRelRepro <= 0) femSelecGenos <- 2 - (femSelecGenos1 + femSelecGenos2)    # The number of the least fit alleles at each selected locus
      if(invRelRepro > 0)  femSelecGenos <- femSelecGenos1 + femSelecGenos2

      ######################################
      # get genotypes at the modifier loci
      ######################################
      femModGenos1 <- NULL    # female genotypes at loci affecting fitness
      femModGenos2 <- NULL    # female genotypes at loci affecting fitness
      for(z in 1:length(selecChrs)){
        femModGenos1 <- cbind(femModGenos1,chr1List[[modChrs[z]]][match(matFems,chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
        femModGenos2 <- cbind(femModGenos2,chr2List[[modChrs[z]]][match(matFems,chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
      }
      if(invRelRepro <= 0) femModGenos <- 2 - (femModGenos1 + femModGenos2)    # The number of the least fit alleles at each modifier locus
      if(invRelRepro > 0) femModGenos <- femModGenos1 + femModGenos2
      matFemPop1 <- NULL                                                                                        # the genotypes give the number of the most fit allele at both fitness and modifier loci

      #####################################################################################
      # assign the single locus effect size, adjusting for spatially varying selection
      # if necessary
      #####################################################################################
      if(invRelRepro_top == invRelRepro) {
        if(epiRelRepro != 0) locusEffsize <-  abs (((invRelRepro)/numSelecLoci)/2)/2      # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
        if(epiRelRepro == 0) locusEffsize <-  abs (((invRelRepro)/numSelecLoci)/2)
      }
      if(invRelRepro_top != invRelRepro) {
        adjInvRelRepro <- invRelRepro - ((confs[j] + tribAbsLeng[j])/(max(confs + tribAbsLeng))) * abs(invRelRepro - invRelRepro_top)
        if(epiRelRepro != 0) locusEffsize <-  abs (((adjInvRelRepro)/numSelecLoci)/2)/2      # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
        if(epiRelRepro == 0) locusEffsize <-  abs (((adjInvRelRepro)/numSelecLoci)/2)
      }

      #############################################################
      # get genotypes at loci with deleterious recessive alleles
      #############################################################
      # The first half of these loci are fixed for deleterious recessives in the native population, the second half loci for the non-native invasive population
      femDelGenos1 <- NULL    # female genotypes at loci affecting fitness
      femDelGenos2 <- NULL    # female genotypes at loci affecting fitness
      for(z in 1:length(delRecChrs)){
        femDelGenos1 <- cbind(femDelGenos1,chr1List[[delRecChrs[z]]][match(matFems,chr1List[[delRecChrs[z]]][,1]),delRecLoci[z]+1])
        femDelGenos2 <- cbind(femDelGenos2,chr2List[[delRecChrs[z]]][match(matFems,chr2List[[delRecChrs[z]]][,1]),delRecLoci[z]+1])
      }
      femDelGenos <- femDelGenos1 + femDelGenos2    # number of native alleles at loci with recessive deleterious alleles for each female
      numDelRecAlls <- femDelGenos                  # counts of deleterious recessive alleles at each locus for each individual
      numDelRecAlls[,(0.5*ncol(femDelGenos)):ncol(femDelGenos)] <- 2 - numDelRecAlls[,(0.5*ncol(femDelGenos)):ncol(femDelGenos)]
      homozygDelRecAlls <- numDelRecAlls == 2
      delRecNatLocEffVec <- c(rep(-delRecEffNat_repro/numDelRec,numDelRec), rep(-delRecEffInv_repro/numDelRec,numDelRec))  # locus specific effect size for deleterious recessives (i.e., reduction in fitness due to being homozygous for the bad allele)
      delValMat <- matrix(NA,nrow(femDelGenos),ncol(femDelGenos))
      for(z in 1:ncol(delValMat)){
        delValMat[,z] <- delRecNatLocEffVec[z]*homozygDelRecAlls[,z]
      }
      delGenVals <- rowSums(delValMat)       # genetic values of each individual at loci with deleterious recessive alleles

      ##### genetic values of different single-locus genotypes
      gen_0 <- 0
      if(fitDom == TRUE) gen_1 <- -locusEffsize + repro_d*locusEffsize
      if(fitDom == FALSE) gen_1 <- -locusEffsize - repro_d*locusEffsize
      gen_2 <- -2*locusEffsize

      epiEff <- abs(((epiRelRepro)/numSelecLoci))

      ##### assign the epistatic effects for the two-locus genotypes
      epi_0_0 <- 0
      if(fitDomEpi == FALSE) epi_0_1 <- -1*epiDom*epiEff
      if(fitDomEpi == TRUE)  epi_0_1 <- -1*(1-epiDom)*epiEff
      epi_0_2 <- -1*epiEff
      if(fitDomEpi == FALSE) epi_1_0 <- -1*epiDom*epiEff
      if(fitDomEpi == TRUE)  epi_1_0 <- -1*(1-epiDom)*epiEff
      epi_1_1 <- 0
      if(fitDomEpi == FALSE) epi_1_2 <- -1*epiDom*epiEff
      if(fitDomEpi == TRUE)  epi_1_2 <- -1*(1-epiDom)*epiEff
      epi_2_0 <- -1*epiEff
      if(fitDomEpi == FALSE) epi_2_1 <- -1*epiDom*epiEff
      if(fitDomEpi == TRUE)  epi_2_1 <- -1*(1-epiDom)*epiEff
      epi_2_2 <- 0
      genValMat <- matrix(0,nrow(femSelecGenos),ncol(femSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus
      for(z in 1:ncol(femSelecGenos)){
          ######## homozygous for the fittest allele at the fitness locus
          if(sum(femSelecGenos[,z] == 0 & femModGenos[,z] == 2) > 0)  genValMat [which(femSelecGenos[,z] == 0 & femModGenos[,z] == 2),z] <- gen_0 + gen_2 + epi_0_2
          if(sum(femSelecGenos[,z] == 0 & femModGenos[,z] == 1) > 0)  genValMat [which(femSelecGenos[,z] == 0 & femModGenos[,z] == 1),z] <- gen_0 + gen_1 + epi_0_1
          if(sum(femSelecGenos[,z] == 0 & femModGenos[,z] == 0) > 0)  genValMat [which(femSelecGenos[,z] == 0 & femModGenos[,z] == 0),z] <- gen_0 + gen_0 + epi_0_0

          ######## heterozygous at the fitness locus
          if(sum(femSelecGenos[,z] == 1 & femModGenos[,z] == 2) > 0)  genValMat [which(femSelecGenos[,z] == 1 & femModGenos[,z] == 2),z] <- gen_1 + gen_2 + epi_1_2
          if(sum(femSelecGenos[,z] == 1 & femModGenos[,z] == 1) > 0)  genValMat [which(femSelecGenos[,z] == 1 & femModGenos[,z] == 1),z] <- gen_1 + gen_1 + epi_1_1
          if(sum(femSelecGenos[,z] == 1 & femModGenos[,z] == 0) > 0)  genValMat [which(femSelecGenos[,z] == 1 & femModGenos[,z] == 0),z] <- gen_1 + gen_0 + epi_1_0

          ######## homozygous for the least fit allele at the fitness locus
          if(sum(femSelecGenos[,z] == 2 & femModGenos[,z] == 2) > 0) genValMat [which(femSelecGenos[,z] == 2 & femModGenos[,z] == 2),z] <- gen_2 + gen_2 + epi_2_2
          if(sum(femSelecGenos[,z] == 2 & femModGenos[,z] == 1) > 0) genValMat [which(femSelecGenos[,z] == 2 & femModGenos[,z] == 1),z] <- gen_2 + gen_1 + epi_2_1
          if(sum(femSelecGenos[,z] == 2 & femModGenos[,z] == 0) > 0) genValMat [which(femSelecGenos[,z] == 2 & femModGenos[,z] == 0),z] <- gen_2 + gen_0 + epi_2_0
      }

      ###############################################################
      # modify genetic values if non-native fitness varies spatially
      ###############################################################
      femWeights <- NULL
      femWeights <- rowSums(genValMat)
      femWeights <- femWeights + (1-max(femWeights))
      femWeights <- femWeights + delGenVals*femWeights
      # rescale femWeights if there are negative probabilities
      if(sum(femWeights < 0) > 0){
        femWeights [which(femWeights < 0)] <- 0
      }

      if(invRelRepro == 0) femWeights <- rep(1,length(femWeights))

      parentPairs <- matePairs[sample(1:nrow(matePairs),size=numOffs,replace=TRUE,prob=femWeights),] # randomly selected parents of each offspring weighted by the hybrid index of the female
      fryIDs <- (maxID+1):(maxID+numOffs)    # IDs for the offspring
      maxID <- max(fryIDs)
      fryPop <- rep(j,length(fryIDs))
      fryAge <- rep(0,length(fryIDs))
      frySex <- rep(c(0,1),length(fryIDs)/2)
      fryMoms <- parentPairs[,1]
      fryDads <- parentPairs[,3]

      #######################################################
      # calculate the genomic hybrid index of each offspring
      #######################################################
      # meiosis
      nonNatAllsMom <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      nonNatAllsDad <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      for(k in 1:chroms){
        momsCopy1 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],chr1List[[k]][,1]),])
        dadsCopy1 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],chr1List[[k]][,1]),])
        momsCopy2 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], chr2List[[k]][,1]),])
        dadsCopy2 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], chr2List[[k]][,1]),])

        #----------------------------
        # maternal meiosis
        #----------------------------
        momRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
        momRecLocsMat <- matrix(NA,nrow=length(fryIDs),ncol=max(momRecs)+1)
        for(z in 1:ncol(momRecLocsMat)){   # draw locations of crossovers for all individuals
          momRecLocsMat[which(momRecs >= z),z] <- runif(n=length(which(momRecs >= z)),min=0,max=mapLeng)
          if(sum(momRecs == (z-1)) > 0) momRecLocsMat[which(momRecs == (z-1)),z] <- mapLeng
        }
        if(sum(momRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(momRecs > 1)
          for(b in moreThanOneRec){
            momRecLocsMat[b,1:(momRecs[b]+1)] <- sort(momRecLocsMat[b,])
          }
        }
        momChrPicker <- sample(x=c(1,2),size=length(fryIDs),replace=TRUE) # which parental chromosome copy to sample first
        offMomGenos <- matrix(NA,nrow=length(fryIDs),ncol=nChromLoci)        #  initialize offspring genotype matrix
        for(b in 1:(max(momRecs)+1)){        # assign genotypes to offspring
          thisMomGenoMat <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offMomGenos))
          if(sum(momChrPicker == 1) > 0){
            thisMomGenoMat[which(momChrPicker == 1),] <- momsCopy1[which(momChrPicker == 1),3:ncol(momsCopy1)]
          }
          if(sum(momChrPicker == 2) > 0){
            thisMomGenoMat[which(momChrPicker == 2),] <- momsCopy2[which(momChrPicker == 2),3:ncol(momsCopy2)]
          }
          if(b == 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(momChrPicker))
          if(sum(momChrPicker == 1) > 0) newChrPicker[which(momChrPicker == 1)] <- 2
          momChrPicker <- newChrPicker
        }
        fryChromOnes <- cbind(fryIDs,offMomGenos)

        #----------------------------
        # paternal meiosis
        #----------------------------
        dadRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
        dadRecLocsMat <- matrix(NA,nrow=length(fryIDs),ncol=max(dadRecs)+1)
        for(z in 1:ncol(dadRecLocsMat)){   # draw locations of crossovers for all individuals
          dadRecLocsMat[which(dadRecs >= z),z] <- runif(n=length(which(dadRecs >= z)),min=0,max=mapLeng)
          if(sum(dadRecs == (z-1)) > 0) dadRecLocsMat[which(dadRecs == (z-1)),z] <- mapLeng
        }
        if(sum(dadRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(dadRecs > 1)
          for(b in moreThanOneRec){
            dadRecLocsMat[b,1:(dadRecs[b]+1)] <- sort(dadRecLocsMat[b,])
          }
        }
        dadChrPicker <- sample(x=c(1,2),size=length(fryIDs),replace=TRUE) # which parental chromosome copy to sample first
        offDadGenos <- matrix(NA,nrow=length(fryIDs),ncol=nChromLoci)        #  initialize offspring genotype matrix
        for(b in 1:(max(dadRecs)+1)){        # assign genotypes to offspring
          thisDadGenoMat <- matrix(NA,nrow=length(fryIDs),ncol=ncol(offDadGenos))
          if(sum(dadChrPicker == 1) > 0){
            thisDadGenoMat[which(dadChrPicker == 1),] <- dadsCopy1[which(dadChrPicker == 1),3:ncol(dadsCopy1)]
          }
          if(sum(dadChrPicker == 2) > 0){
            thisDadGenoMat[which(dadChrPicker == 2),] <- dadsCopy2[which(dadChrPicker == 2),3:ncol(dadsCopy2)]
          }
          if(b == 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(dadChrPicker))
          if(sum(dadChrPicker == 1) > 0) newChrPicker[which(dadChrPicker == 1)] <- 2
          dadChrPicker <- newChrPicker
        }
        fryChromTwos <- cbind(fryIDs,offDadGenos)
        if(j == 1){
          offChr1[[k]] <- fryChromOnes
          offChr2[[k]] <- fryChromTwos
        }
        if(j > 1){
          offChr1[[k]] <- rbind(offChr1[[k]],fryChromOnes)
          offChr2[[k]] <- rbind(offChr2[[k]],fryChromTwos)
        }
        nonNatAllsMom <- cbind(nonNatAllsMom,rowSums(fryChromOnes[,2:ncol(fryChromOnes)] == 0))
        nonNatAllsDad <- cbind(nonNatAllsDad,rowSums(fryChromTwos[,2:ncol(fryChromTwos)] == 0))
      }
      fryPercRBT <- rowSums(cbind(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry
      fryOut <- cbind(fryIDs,fryPop,fryAge,fryPercRBT,frySex,fryMoms,fryDads,rep(i,length(fryIDs)))
      colnames(fryOut) <- NULL
      offspring <- rbind(offspring,fryOut)
    }

    ########################################################
    # calculate offspring hybrid index at the selected loci
    ########################################################
    selecPercRBT <- rep(NA,length(fryPercRBT))     # hybrid index of the individual at the causal loci
    selecGenos <- NULL
    for(z in 1:length(selecChrs)){
      selecGenos <- cbind(selecGenos,offChr1[[selecChrs[z]]][,selecLoci[z]+1],offChr2[[selecChrs[z]]][,selecLoci[z]+1])
    }
    selecPercRBT <- 1 - rowSums(selecGenos)/ncol(selecGenos)
    offspring <- cbind(offspring[,1:5],selecPercRBT,offspring[,6:8],rep(0,nrow(offspring)))

    ##################################################################################
    # update the genetic and demographic data
    ##################################################################################
    for(k in 1:length(chr1List)){
      chr1List[[k]] <- rbind(chr1List[[k]],offChr1[[k]])
      chr2List[[k]] <- rbind(chr2List[[k]],offChr2[[k]])
    }
    popMat<- rbind(popMat,offspring)
    ##################################################
    # advance the population to the next year
    ##################################################
    survVec <- rep(0,nrow(popMat)) # vector indicating survival (1) or death (0)
    newPop <- NULL         # temporarily store the new population data
    keepIndices <- NULL    # vector of the ids of individuals surviving to the next year
    for (j in 1:length(confs)){
      thisDat <- NULL
      thisDat <- popMat[which(popMat[,2] == j),]
      for (k in 1:(length(ageStruc)-1)){       # select individuals in each age class to survive to the next year (all individuals in the last age class die)
        ageDat <- NULL
        ageDat <- thisDat[which(thisDat[,3] == ages[k]),] # individuals in age class k for the jth population

        #############################################################
        # get genotypes at loci with deleterious recessive alleles
        #############################################################
        # The first half of these loci are fixed for deleterious recessives in the native population, the second half loci for the non-native invasive population
        ageDelGenos1 <- NULL    # age class genotypes at loci affecting fitness
        ageDelGenos2 <- NULL    # age class genotypes at loci affecting fitness
        for(z in 1:length(delRecChrs)){
          ageDelGenos1 <- cbind(ageDelGenos1,chr1List[[delRecChrs[z]]][match(ageDat[,1],chr1List[[delRecChrs[z]]][,1]),delRecLoci[z]+1])
          ageDelGenos2 <- cbind(ageDelGenos2,chr2List[[delRecChrs[z]]][match(ageDat[,1],chr2List[[delRecChrs[z]]][,1]),delRecLoci[z]+1])
        }
        ageDelGenos <- ageDelGenos1 + ageDelGenos2    # number of native alleles at loci with recessive deleterious alleles for each individual
        numDelRecAlls <- ageDelGenos                  # counts of deleterious recessive alleles at each locus for each individual
        numDelRecAlls[,(0.5*ncol(ageDelGenos)):ncol(ageDelGenos)] <- 2 - numDelRecAlls[,(0.5*ncol(ageDelGenos)):ncol(ageDelGenos)]
        homozygDelRecAlls <- numDelRecAlls == 2
        delRecNatLocEffVec <- c(rep(-delRecEffNat_surv/numDelRec,numDelRec), rep(-delRecEffInv_surv/numDelRec,numDelRec))  # locus specific effect size for deleterious recessives (i.e., reduction in fitness due to being homozygous for the bad allele)

        delValMat <- matrix(NA,nrow(ageDelGenos),ncol(ageDelGenos))
        for(z in 1:ncol(delValMat)){
          delValMat[,z] <- delRecNatLocEffVec[z]*homozygDelRecAlls[,z]
        }
        delGenVals <- rowSums(delValMat)       # genetic values of each individual at loci with deleterious recessive alleles


        #############################################
        # get genotypes at fitness loci
        #############################################
        ageSelecGenos1 <- NULL    # genotypes of individuals in the kth age class at loci affecting fitness
        ageSelecGenos2 <- NULL
        for(z in 1:length(selecChrs)){
          ageSelecGenos1 <- cbind(ageSelecGenos1,chr1List[[selecChrs[z]]][match(ageDat[,1],chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
          ageSelecGenos2 <- cbind(ageSelecGenos2,chr2List[[selecChrs[z]]][match(ageDat[,1],chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        }
        if(invRelSurv <= 0) ageSelecGenos <- 2 - (ageSelecGenos1 + ageSelecGenos2)    # The number of the least fit alleles at each selected locus
        if(invRelSurv > 0) ageSelecGenos <- ageSelecGenos1 + ageSelecGenos2

        ######################################
        # get genotypes at the modifier loci
        ######################################
        ageModGenos1 <- NULL    # age class genotypes at modifier loci
        ageModGenos2 <- NULL
        for(z in 1:length(selecChrs)){
          ageModGenos1 <- cbind(ageModGenos1,chr1List[[modChrs[z]]][match(ageDat[,1],chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
          ageModGenos2 <- cbind(ageModGenos2,chr2List[[modChrs[z]]][match(ageDat[,1],chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
        }
        if(invRelSurv <= 0) ageModGenos <- 2 - (ageModGenos1 + ageModGenos2)    # The number of the least fit alleles at each selected locus
        if(invRelSurv > 0) ageModGenos <- ageModGenos1 + ageModGenos2
        # ageSelecGenos and ageModGenos now give the number of the most fit allele at fitness and modifier loci

        #####################################################################################
        # assign the single locus effect size, adjusting for spatially varying selection
        # if necessary
        #####################################################################################
        if(invRelRepro_top == invRelRepro) {
          if(epiRelSurv != 0) locusEffsize <-  abs (((invRelSurv)/numSelecLoci)/2)/2      # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
          if(epiRelSurv == 0) locusEffsize <-  abs (((invRelSurv)/numSelecLoci)/2)
        }
        if(invRelRepro_top != invRelRepro) {
          adjInvRelSurv <- invRelSurv - ((confs[j] + tribAbsLeng[j])/(max(confs + tribAbsLeng))) * abs(invRelSurv - invRelSurv_top)
          if(epiRelSurv != 0) locusEffsize <-  abs (((adjInvRelSurv)/numSelecLoci)/2)/2      # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
          if(epiRelSurv == 0) locusEffsize <-  abs (((adjInvRelSurv)/numSelecLoci)/2)
        }
        genValMat <- matrix(0,nrow(ageSelecGenos),ncol(ageSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus

        ##### genetic values of different single-locus genotypes
        gen_0 <- 0
        if(fitDom == TRUE) gen_1 <- -locusEffsize + surv_d*locusEffsize
        if(fitDom == FALSE) gen_1 <- -locusEffsize - surv_d*locusEffsize
        gen_2 <- -2*locusEffsize
        epiEff <- abs(((epiRelSurv)/numSelecLoci))

        ##### assign the epistatic effects for the two-locus genotypes
        ##### assume there is no fitness reduction when both parental haplotypes are intact (i.e., pure parental types, or F1s)
        epi_0_0 <- 0
        if(fitDomEpi == FALSE) epi_0_1 <- -1*epiDom*epiEff
        if(fitDomEpi == TRUE)  epi_0_1 <- -1*(1-epiDom)*epiEff
        epi_0_2 <- -1*epiEff
        if(fitDomEpi == FALSE) epi_1_0 <- -1*epiDom*epiEff
        if(fitDomEpi == TRUE)  epi_1_0 <- -1*(1-epiDom)*epiEff
        epi_1_1 <- 0
        if(fitDomEpi == FALSE) epi_1_2 <- -1*epiDom*epiEff
        if(fitDomEpi == TRUE)  epi_1_2 <- -1*(1-epiDom)*epiEff
        epi_2_0 <- -1*epiEff
        if(fitDomEpi == FALSE) epi_2_1 <- -1*epiDom*epiEff
        if(fitDomEpi == TRUE)  epi_2_1 <- -1*(1-epiDom)*epiEff
        epi_2_2 <- 0
        for(z in 1:ncol(ageSelecGenos)){
          ######## homozygous for the fittest allele at the fitness locus
          if(sum(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 2) > 0)  genValMat [which(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 2),z] <- gen_0 + gen_2 + epi_0_2
          if(sum(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 1) > 0)  genValMat [which(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 1),z] <- gen_0 + gen_1 + epi_0_1
          if(sum(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 0) > 0)  genValMat [which(ageSelecGenos[,z] == 0 & ageModGenos[,z] == 0),z] <- gen_0 + gen_0 + epi_0_0

          ######## heterozygous at the fitness locus
          if(sum(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 2) > 0)  genValMat [which(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 2),z] <- gen_1 + gen_2 + epi_1_2
          if(sum(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 1) > 0)  genValMat [which(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 1),z] <- gen_1 + gen_1 + epi_1_1
          if(sum(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 0) > 0)  genValMat [which(ageSelecGenos[,z] == 1 & ageModGenos[,z] == 0),z] <- gen_1 + gen_0 + epi_1_0

          ######## homozygous for the least fit allele at the fitness locus
          if(sum(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 2) > 0) genValMat [which(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 2),z] <- gen_2 + gen_2 + epi_2_2
          if(sum(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 1) > 0) genValMat [which(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 1),z] <- gen_2 + gen_1 + epi_2_1
          if(sum(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 0) > 0) genValMat [which(ageSelecGenos[,z] == 2 & ageModGenos[,z] == 0),z] <- gen_2 + gen_0 + epi_2_0
        }

        #################################################################################
        # Adjust genetic values for spatially varying selection on non-native genotypes
        #################################################################################
        if(invRelSurv == 0) survWeights <- rep(1,nrow(ageDat))
        if(invRelSurv != 0) survWeights <- rowSums(genValMat)
        survWeights <- survWeights + (1 - max(survWeights))
        survWeights <- survWeights + delGenVals*survWeights    # accunt for deleterious recessive alleles
        # rescale survWeights if there are negative probabilities
        if(sum(survWeights < 0) > 0){
          survWeights[which(survWeights < 0)] <- 0
        }
        keepIds <- sample(ageDat[,1],size=ageStruc[k+1]*(popSize),replace=FALSE,prob = survWeights)
        keepIndices <- append(keepIndices,which(popMat[,1] %in% keepIds))
      }
    }
    survVec[keepIndices] <- 1                          # mark the survivors
    popMat[,10] <- survVec
    popMat[,9] <- i
    allPopMat <- rbind(allPopMat,popMat)               # save all individuals, including non-survivors
    newPop <- popMat[which(survVec == 1),]             # population of survivors for next year
    newPop[,3] <- newPop[,3] + 1                       # increase age of survivors by one year
    popMat <- newPop                                   # replace this year's population with the next
    print(paste("done with year", i))
  }

  ######################
  # format the genotypes
  ######################
  atMat <- NULL
  # loci are in rows, individuals are in columns
  for(i in 1:length(chr2List)){
    thisChr1 <- t(chr1List[[i]][,2:ncol(chr1List[[i]])])
    thisChr2 <- t(chr2List[[i]][,2:ncol(chr2List[[i]])])
    thisGenoMat <- matrix(NA,ncol=ncol(thisChr1)*2,nrow=nrow(thisChr1))
    fstAlls <- seq(from=1,to=2*(ncol(thisChr1)),by=2)
    secAlls <- seq(from=2,to=2*(ncol(thisChr1)),by=2)
    for (j in 1:length(fstAlls)){
      thisGenoMat[which(thisChr1[,j] == 1),fstAlls[j]] <- "A"
      thisGenoMat[which(thisChr1[,j] == 0),fstAlls[j]] <- "T"
      thisGenoMat[which(thisChr2[,j] == 1),secAlls[j]] <- "A"
      thisGenoMat[which(thisChr2[,j] == 0),secAlls[j]] <- "T"
    }
  atMat <- rbind(atMat,thisGenoMat)
  }
  genoIds <- NULL
  genoIds <- cbind(genoIds,chr1List[[1]][,1])   # link genotypes to individual IDs
  if(numSelecLoci > 0){
    admixRes <- list(allPopMat,atMat,lociMap,selecLociMap,genoIds)
  }
  if(numSelecLoci == 0 | is.null(numSelecLoci)) {
    admixRes <- list(allPopMat,atMat,lociMap,genoIds)
  }
  return(admixRes)
}




