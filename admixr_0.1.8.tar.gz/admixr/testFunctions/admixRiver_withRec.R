#' A function to simulate hybridization in a river system.
#'
#' This function runs a forward-time spatially and genomically explicit simulation of hybridization in a
#'     river system with a mainstem and tributaries.
#' @param mainStemLeng numeric. The length of the mainstem in kilometers.
#' @param tribNum numeric. The number of evenly spaced tributaries in the river system.
#' @param tribLeng numeric. The length of each tributary in kilometers.
#' @param popSize numeric. The population size in each tributary.
#' @param nativeDispProb numeric. Probability of a pure native juvenile individual dispersing.
#' @param maxDispProb numeric. Probability of a pure non-native juvenile individual dispersing.
#' @param barrierLoc numeric. Number of headwater streams to place above a barrier to non-native immigration. Set to 0 for no barrier.
#' @param nonNatThresh numeric. The hybrid index above which an individual cannot go above the barrier.
#' @param repro_d numeric. The dominance of fitness loci for fedundity. 0 = no dominance. 1 = complete dominance.
#' @param surv_d numeric. The dominance of fitness loci for survival. 0 = no dominance. 1 = complete dominance.
#' @param nativeDom logical. TRUE if higher fitness alleles are dominant over lower fitness alleles, FALSE if less fit alleles alleles are dominant over more fit alleles
#'     at all fitness and modifier loci. If invRelRepro and invRelSurv are negative, then TRUE means that the native allele is dominant over the non-native allele.
#' @param epiSize numeric. The strength of epistasis. Ranges from 0 to 1. 1 means that the fitness effects of alleles at fitness loci depend 100% on the genotypes at modifier loci.
#'     Zero means there is no epistasis. The model assumes that native alleles at modifier loci interact positively with native alleles at fitness loci.
#' @param epiDom numeric. The dominance at modifier loci. 0 = no dominance. 1 = complete dominance. Must range from 0 to 1.
#' @param numSelecLoci numeric. The number of loci in the genome that affect fitness. The same loci affect survival and reproduction. The fitness effects on survival and reproduction
#'     are spread evenly over these loci. The fitness loci are selected at random from all sites across the genome.
#' @param ages numeric. The ages of individuals in the population. Starting with 0 for young-of-the-year.
#' @param ageMaturity numeric. The age at which an individual is capable of reproducing.
#' @param ageStruc numeric. A vector giving the proportion of the population in each of the age classes. Must sum to one.
#'@param invRelSurv numeric. Signed difference in survival of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-natives have higher survival than natives. Negative values mean that non-natives have lower survival than natives.
#' @param invRelRepro numeric. Signed difference in female fedundity of pure non-natives compared to pure natives, in the presence of natives.
#'     This is equivalent to soft selection. Positive values mean non-natives have higher reproduction than natives. Negative
#'     values mean that non-natives have lower reproduction than natives.
#' @param assortWeight numeric. The strength of positive assortative mating. Must range from 0 to 1. 1 means complete
#'     assortative mating (pure non-natives and pure natives will never mate), 0 means no assorative mating.
#' @param stockYears numeric. The years in the simulation that non-native individuals will be stocked at the bottom end
#'     of the mainstem.
#' @param stockAge numeric. The age of non-native indiviudals that will be stocked.
#' @param stockNum numeric. The number of non-native individuals that will be stocked each of stockYears.
#' @param nChromLoci numeric. The number of evenly spaced ancestry-informative loci on each chromosome.
#' @param chroms numeric. The number of chromosomes.
#' @param mapLeng numeric. The genetic map length of each chromosome (in centiMorgans).
#' @param runTime numeric. The number of years to run the simulation.
#' @details
#'    The output from this function is a list with five elements. The first element is a data frame with the following columns: Individual identification number,
#'    population number, age, the hybrid index (fraction of genome that is non-native), sex, the hybrid index at fitness
#'    loci, mother, father, and year. Only individuals that survived to age one are included. Every individual in the population is represented for each year. For example, an individual
#'    that was born in year 5 and died in year 7 will be represented in three rows (one for each of years 5-7).
#'
#'    The second element contains the genotypes of all individuals in 012 format. The first column is the individual identification number. The
#'    remaining columns are genotypes given as the number of non-native alleles at each locus in the genome. Loci are ordered left to right,
#'    starting with the first locus on chromosome 1, and so on.
#'
#'    The third element is a data frame containing the genotypes at "AT" format. T is the non-native allele and A is the native allele at each locus. The
#'    first column is the individual identification number. The remaining columns are individual genotypes, ordered from left to right, beginning
#'    with the first locus on chromosome one. Each locus is represented by two columns, such that the total number of columns is two times the number
#'    of loci plus one.
#'
#'    The fourth element is a vector giving the chromosome locations of fitness loci.
#'
#'    The fifth element is a vector giving the location of each fitness locus in centiMorgans.

#' @examples
#'     library(admixr)
#'     # simulate admixture in a river system
#'     tryRiver <- admixRiver(mainStemLeng=100,tribNum=10,tribLeng=10,popSize=200,nativeDispProb=0.05,maxDispProb=0.05,barrierLoc=0,
#'                       nonNatThresh=0.5,repro_d=1,surv_d=1,nativeDom=TRUE,epiSize=1,epiDom=1,numSelecLoci=10,ages=c(0,1,2),ageMaturity=1,ageStruc=c(0.5,0.25,0.25),invRelSurv=0,invRelRepro=0,
#'                       assortWeight=0,stockYears=1:5,stockAge=0,stockNum=20,nChromLoci=100,chroms=4,mapLeng=50,runTime=10)
# plot the results from year 10 of the simulation
#'     plotRiver(admixDat=tryRiver,mainStemLeng=100,tribLeng=10,yearPlot=10)
#' @export

admixRiver<- function (mainStemLeng,tribNum,tribLeng,lambda,popSize,nativeDispProb,maxDispProb,barrierLoc,
                       nonNatThresh,nativeDom,epiSize,epiDom,ages,ageMaturity,ageStruc,repro_d,surv_d,numSelecLoci,invRelSurv,invRelRepro,F1Heterosis,assortWeight,
                       stockYears,stockAge,stockNum,nChromLoci,chroms,mapLeng,runTime){

  confs <- seq(mainStemLeng/tribNum,mainStemLeng,mainStemLeng/tribNum)  # locations of the confluences of tributaries and the mainstem
  tribSideLeng <- sqrt((tribLeng^2)/2)
  sites <- 1:tribNum                                                    # spawning site identifications
  distMat <- matrix(NA,nrow=length(sites),ncol=length(sites))   # matrix of pairwise distances between spawning sites
  bifMat <- matrix(NA,nrow=length(sites),ncol=length(sites))    # matrix of pairwise number of bifurcations separating spawning sites
  for(i in 1:length(sites)){
    distMat[i,] <- abs(confs[i] - confs) + tribLeng
    distMat[i,i] <- 0
    bifMat[i,] <- abs(i - 1:length(confs))
    bifMat[i,i] <- 0
  }
  movProbs <-  matrix(NA,nrow=length(sites),ncol=length(sites))  # matrix of probabilities of movement of
  # fish from one site to another (assuming it is a disperser)
  movProbs <- (1/(2*bifMat))*exp(-lambda*distMat)
  for (i in 1:nrow(movProbs)){
    movProbs[i,i] <- NA
  }
  for (i in 1:nrow(movProbs)){
    movProbs[i,i] <- 1-sum(movProbs[i,],na.rm=TRUE)
  }

  ##########################################################
  # populate the network with genetically pure native fish
  ##########################################################
  ageVec <- NULL
  for (i in 1:length(ages)){
    ageVec <- c(ageVec,rep(ages[i],ageStruc[i]*popSize))
  }
  pop <- NULL
  age <- NULL
  for(i in 1:length(confs)){
    pop  <- c(pop,rep(i,length(ageVec)))
    age <- c(age,ageVec)
  }
  id <- 1:length(pop)
  yearVec <- rep(0,length(pop))
  percRBT <- rep(0,length(pop))      # hybrid index initialized at zero for all native fish
  sex <- rep(c(0,1),length(pop)/2)
  popMat <- NULL                      # matrix to store all of the individuals in the river system
  selecPercRBT <- rep(0,length(pop))  # hybrid index at the loci affecting fitness
  mom <- rep(NA,length(pop))
  dad <- rep(NA,length(pop))
  survVec <- rep(1,length(pop))    # vector indicating that all the initial individuals survived to the next year
  allPopMat <- cbind(id,pop,age,percRBT,sex,selecPercRBT,mom,dad,yearVec,survVec) # matrix to store all of the population data throughout the simulation
  allPopMat <- allPopMat[which(allPopMat[,3] > 0),]    # eliminate the zero age class
  popMat <- allPopMat # matrix to store the individuals that are in the population currently
  colonizProbs <- movProbs[1,]

  ###########################################
  # initialize the genome matrices
  ###########################################
  listNames <- paste("popGenDat",1:length(confs),sep="")
  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  for(i in 1:chroms){
    chr1List [[i]]<- cbind(popMat[,1],matrix(1,nrow=nrow(popMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
    chr2List [[i]]<- cbind(popMat[,1],matrix(1,nrow=nrow(popMat),ncol=nChromLoci))   ### 1's indicate that each individual in the original population is pure native
  }

  #######################
  # identify fitness loci
  #######################
  selecLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  selecChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression
  selecChrs <- sort(sample(1:chroms,numSelecLoci+numDelRec_nat+numDelRec_nonNat,replace=TRUE))
  selecLoci <- NULL
  uniChrs <- unique(selecChrs)
  for(i in 1:length(uniChrs)){
    selecLoci <- c(selecLoci,sort(sample(1:nChromLoci,sum(selecChrs == uniChrs[i]),replace=FALSE)))
  }
  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat  <- rbind(selecChrMat,selecChrs)

  ##############################################################################
  # select modifier loci to intereact epistatically with the fitness loci
  ##############################################################################
  modLociMat <- NULL     # matrix to store the positions of the loci responsible for outbreeding depression
  modChrMat <- NULL      # matrix to store the chromosomes of the loci responsible for outbreeding depression
  modChrs <- rep(NA,length(selecChrs))
  for(i in 1:length(modChrs)){
    if(chroms > 2) {modChrs [i] <- sample( (1:chroms)[which( (1:chroms) != selecChrs[i])],1)}
    if(chroms == 2){modChrs [i] <- (1:chroms)[which( (1:chroms) != selecChrs[i])]}
  }
  modLoci <- NULL
  uniChrs <- unique(modChrs)
  for(i in 1:length(uniChrs)){
    modLoci <- c(modLoci,sort(sample(1:nChromLoci,sum(modChrs == uniChrs[i]),replace=FALSE)))
  }
  selecLociMat <- rbind(selecLociMat,selecLoci)
  selecChrMat <- rbind(selecChrMat,selecChrs)

  #####################
  # run the simulation
  #####################
  maxID <- max(allPopMat[,1])
  for (i in 1:runTime){
    ##########################
    # dispersal of juveniles
    ##########################
    for (j in 1:length(confs)){
      thisPopDat <- NULL
      thisPopDat <- popMat[which(popMat[,2] == j & popMat[,10] == 1),]
      juvies <- which (thisPopDat[,3] == 0)
      thisMovProbs <- movProbs[j,]    # vector of probabilities of dispersal to different spawning grounds
      thisMovProbs[j] <- 0       # do not allow a disperser to select its natal spawning ground
      juvHybInds <- thisPopDat[juvies,4]  # hybrid indices of the juveniles
      dispProbs <- nativeDispProb + juvHybInds*(maxDispProb - nativeDispProb)# Probability that each individual will disperse...
      # This depends on the hybridity of the individual as in Della Croce et al. (2014)
      dispTests <- runif(length(dispProbs),min=0,max=1)
      if(sum(dispTests <= dispProbs) > 0){
        dispPops <- rep(NA,sum(dispTests <= dispProbs))
        for (k in 1:length(dispPops)){
          if(barrierLoc == 0 | juvHybInds[k] < nonNatThresh){          # select distination stream for dispersers
            dispPops[k] <- sample(1:length(confs),size=1,prob=thisMovProbs)
          }
          if(barrierLoc > 0 & juvHybInds[k] >= nonNatThresh){          # select destination stream that is below the non-native dispersal barrier for dispersing highly indivdual
            dispPops[k] <- sample(1:(length(confs)-barrierLoc),size=1,prob=thisMovProbs[1:(length(confs)-barrierLoc)])
          }
        }
        dispersers <- juvies[which(dispTests <= dispProbs)]
        popMat[which(popMat[,2] == j)[dispersers],2] <- dispPops
      }
    }

    #######################
    # introduce non-natives
    #######################
    if(i %in% stockYears){
      stockIDs <- (maxID+1):(stockNum + maxID) # ids of the stocked individuals
      maxID <- max(stockIDs)
      stockPop <- rep(1,length(stockIDs))
      stockAges <- rep(stockAge,length(stockIDs))    # age of stocked fish
      stockSex <- rep(c(0,1),length(stockAges)/2)    # sex of stocked fish
      stockRBT <- rep(1,length(stockIDs))            # all stocked fish have a hybrid index of 1
      stockSelecRBT <- rep(1,length(stockIDs))

      #####################################
      # disperse the non-natives
      #####################################
      stockPop <- sample(1:(length(confs)-barrierLoc),size=length(stockIDs),replace=TRUE,prob = colonizProbs[1:(length(confs)-barrierLoc)]) # which population will the stocked fish colonize
      stockMom <- rep(NA,length(stockIDs))
      stockDad <- rep(NA,length(stockIDs))
      year <- rep(i,length(stockIDs))
      stockMat <- cbind(stockIDs,stockPop,stockAges,stockRBT,stockSex,stockSelecRBT,stockMom,stockDad,year,rep(0,length(stockIDs)))
      colnames(stockMat) <- NULL
      popMat <- rbind(popMat,stockMat)
      for(j in 1:length(chr1List)){
        chr1List[[j]] <- rbind(chr1List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))  # add the genomic data from the stocked fish
        chr2List[[j]] <- rbind(chr2List[[j]],cbind(stockIDs,matrix(0,nrow=nrow(stockMat),ncol=nChromLoci)))
      }
    }

    ##########
    # mating
    ##########
    offspring <- NULL # matrix to store the new offspring demographic data (i.e., hybrid index, parents, etc.)
    offChr1 <- list() #list of length 'chroms' storing the maternal chromosome copies
    offChr2 <- list() #list of length 'chroms' storing the paternal chromosome copies
    for (j in 1:length(confs)){
      numOffs <- ageStruc[1]*popSize           # total number of offspring to produce for EACH population
      thisDat <- popMat[which(popMat[,2] == j),] # population data from the jth tributary
      matFems <- NULL      # mature females
      pickFemales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 0)
      matFems <- thisDat[pickFemales,1] # mature females
      matFemHybInd <- thisDat[pickFemales,6]       # female hybrid indices at the loci affecting fitness
      candMales <- which(thisDat[,3] >= ageMaturity & thisDat[,5] == 1) # males that are mature and could breed
      maleHybInd <- thisDat[candMales,4]   # hybrid indices of males (at all loci) that are mature and could breed
      maleLocs <- thisDat[candMales,7:8]
      matFemLocs <- thisDat[pickFemales,7:8]

      #### pick males for the females to breed with.... Onle one male per female. Males can mate with multiple females
      pickMales <- rep(NA,length(matFems))
      for (v in 1:length(matFems)){
        pickMales [v] <- sample(candMales,size=1,prob= (1 - abs(matFemHybInd[v] - maleHybInd)*assortWeight),replace=FALSE)
      }
      matMales <- thisDat[pickMales,1]  # males that will be paired with females
      matMaleHybInd <- thisDat[pickMales,4]
      # make offspring
      matePairs <- cbind(matFems,matFemHybInd,matMales,matMaleHybInd)     # pairs of candidate parents
      femSelecGenos1 <- NULL    # female genotypes at loci affecting fitness
      femSelecGenos2 <- NULL
      for(z in 1:length(selecChrs)){
        femSelecGenos1 <- cbind(femSelecGenos1,chr1List[[selecChrs[z]]][match(matFems,chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        femSelecGenos2 <- cbind(femSelecGenos2,chr2List[[selecChrs[z]]][match(matFems,chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
      }
      femSelecGenos <- 2 - (femSelecGenos1 + femSelecGenos2)    # this is the number of non-native alleles each female has at each selected locus

      ######################################
      # get genotypes at the modifier loci
      ######################################
      femModGenos1 <- NULL    # female genotypes at loci affecting fitness
      femModGenos2 <- NULL    # female genotypes at loci affecting fitness
      for(z in 1:length(selecChrs)){
        femModGenos1 <- cbind(femModGenos1,chr1List[[modChrs[z]]][match(matFems,chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
        femModGenos2 <- cbind(femModGenos2,chr2List[[modChrs[z]]][match(matFems,chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
      }
      femModGenos <- 2 - (femModGenos1 + femModGenos2)    # The number of non-native alleles each female has at the modifier loci
      matFemPop1 <- NULL                                                                                        # the genotypes give the number of the most fit allele at both fitness and modifier loci
      locusEffSize <- ((invRelRepro)/numSelecLoci)/2                             # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
      modEffSize <- epiSize/2                                                    # Additive effect at each modifier locus (half the difference between homozygous genotypes)
      modValMat <- matrix(0,nrow(femModGenos),ncol(femModGenos))           # Matrix to store the genetic values at modifier loci
      genValMat <- matrix(0,nrow(femSelecGenos),ncol(femSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus
      for(z in 1:numSelecLoci){
          if(sum(femSelecGenos[,z] == 1) > 0 & nativeDom == TRUE) {genValMat [which(femSelecGenos[,z] == 1),z] <- locusEffSize * (1 - repro_d)} #genetic value of heterozygotes at fitness loci, accounting for dominance
          if(sum(femSelecGenos[,z] == 1) > 0 & nativeDom == FALSE){genValMat [which(femSelecGenos[,z] == 1),z] <- locusEffSize * (1 + repro_d)}
          if(sum(femSelecGenos[,z] == 2) > 0){genValMat [which(femSelecGenos[,z] == 2),z] <- 2 * locusEffSize}
          if(epiSize > 0){
            if(sum(femModGenos[,z] == 1) > 0 & nativeDom == TRUE)  {modValMat [which(femModGenos[,z] == 1),z] <- modEffSize * (1 - epiDom)} #genetic value of heterozygotes at modifier loci, accounting for dominance
            if(sum(femModGenos[,z] == 1) > 0 & nativeDom == FALSE) {modValMat [which(femModGenos[,z] == 1),z] <- modEffSize * (1 + epiDom)}
            if(sum(femModGenos[,z] == 2) > 0) {modValMat [which(femModGenos[,z] == 2),z] <-  1}
          }
      }

      ###########################################
      # account for deleterious recessive alleles
      ###########################################
      if(numDelRec_nat > 0){     # account for the effects of deleterious recessive alleles fixed in pure native individuals
        natRecAlleleEff <- recEffSize_nat/numDelRec_nat
        for(z in 1:numDelRec_nat){
          if(sum(femSelecGenos[,z+numSelecLoci] > 0) > 0 ) genValMat[which(femSelecGenos[,z+numSelecLoci] > 0),z+numSelecLoci] <- natRecAlleleEff
        }
      }
      if(numDelRec_nonNat > 0){     # account for the effects of deleterious recessive alleles fixed in pure non-native individuals
        nonNatRecAlleleEff <- -1 * (recEffSize_nonNat/numDelRec_nonNat)
        for(z in 1:numDelRec_nonNat){
          if(sum(femSelecGenos[,z+numSelecLoci+numDelRec_nat] == 2) > 0 ) genValMat[which(femSelecGenos[,z+numSelecLoci+numDelRec_nat] == 2),z+numSelecLoci+numDelRec_nat] <- nonNatRecAlleleEff
        }
      }

      #modValMat <- 1 - modValMat
      minGenVal <- min(c(0,locusEffSize*2))
      maxGenVal <- max(c(0,locusEffSize*2))
      genValMat2 <- matrix(NA,nrow=nrow(genValMat),ncol=ncol(genValMat))
      for(e in 1:numSelecLoci){
        if(sum(femSelecGenos[,e] == 0) > 0){         # genetic values of individuals that are homozygous for the least fit allele
          zeros <- which(femSelecGenos[,e] == 0)
          genValMat2[zeros,e] <- genValMat[zeros,e]
        }
        if(sum(femSelecGenos[,e] %in% c(1,2)) > 0){
          onesTwos <- which(femSelecGenos[,e] %in% c(1,2))
          genValMat2[onesTwos,e] <- genValMat[onesTwos,e] - modValMat[onesTwos,e]*(genValMat[onesTwos,e] - minGenVal)
        }
      }
      if(numSelecLoci < ncol(genValMat)){
        genValMat2[,(numSelecLoci + 1):ncol(genValMat2)] <- genValMat[,(numSelecLoci + 1):ncol(genValMat2)]
      }

      femWeights <- NULL
      femWeights <-  1 + rowSums(genValMat2)
      parentPairs <- matePairs[sample(1:nrow(matePairs),size=numOffs,replace=TRUE,prob=femWeights),] # randomly selected parents of each offspring weighted by the genotypes in the female
      fryIDs <- (maxID+1):(maxID+numOffs)    # IDs for the offspring
      maxID <- max(fryIDs)
      fryPop <- rep(j,length(fryIDs))
      fryAge <- rep(0,length(fryIDs))
      frySex <- rep(c(0,1),length(fryIDs)/2)
      fryMoms <- parentPairs[,1]
      fryDads <- parentPairs[,3]

      #######################################################
      # calculate the genomic hybrid index of each offspring
      #######################################################
      # meiosis
      nonNatAllsMom <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      nonNatAllsDad <- NULL # matrix to store a count of the number of non-native chromosome segments for each individual
      for(k in 1:chroms){
        momsCopy1 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr1List[[k]][match(parentPairs[,1],chr1List[[k]][,1]),])
        dadsCopy1 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr1List[[k]][match(parentPairs[,3],chr1List[[k]][,1]),])
        momsCopy2 <- cbind(popMat[match(parentPairs[,1],popMat[,1]),1],chr2List[[k]][match(parentPairs[,1], chr1List[[k]][,1]),])
        dadsCopy2 <- cbind(popMat[match(parentPairs[,3],popMat[,1]),1],chr2List[[k]][match(parentPairs[,3], chr1List[[k]][,1]),])
        momRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the mom
        dadRecs <- rpois(n=length(fryIDs),lambda=mapLeng/100)    # number of recombination events in the dad
        fryChromOnes <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
        fryChromTwos <- cbind(fryIDs,matrix(NA,nrow=length(fryIDs),ncol=nChromLoci))
        for(l in 1:nrow(fryChromOnes)){
          # maternal chromosome
          momStartChrom <- sample(c(1,2),1)
          momChrom <- NULL
          momRecLocs <- c(sort(sample(1:(nChromLoci-1),momRecs[l],replace=FALSE)),nChromLoci)
          if(length(momRecLocs)>1){
            momBeginLocs <- c(1,momRecLocs[1:(length(momRecLocs)-1)] + 1)
            momBeginLocs [length(momBeginLocs)] <-c(momRecLocs[length(momRecLocs)-1]+1)
          }
          if(length(momRecLocs) == 1){
            momBeginLocs <- 1
          }
          if(momStartChrom == 1){
            for(m in 1:length(momRecLocs)){
              if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
              if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            }
          }
          if(momStartChrom == 2){
            for(m in 1:length(momRecLocs)){
              if(m %in% seq(1,200,2)){momChrom <- c(momChrom,momsCopy2[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
              if(m %in% seq(2,200,2)){momChrom <- c(momChrom,momsCopy1[l,(momBeginLocs[m]+2):(momRecLocs[m]+2)])}
            }
          }
          fryChromOnes [l,2:ncol(fryChromOnes)] <- momChrom

          ##### paternal chromosome
          dadStartChrom <- sample(c(1,2),1)
          dadChrom <- NULL
          dadRecLocs <- c(sort(sample(1:(nChromLoci-1),dadRecs[l],replace=FALSE)),nChromLoci)
          if(length(dadRecLocs)>1){
            dadBeginLocs <- c(1,dadRecLocs[1:(length(dadRecLocs)-1)] + 1)
            dadBeginLocs [length(dadBeginLocs)] <-c(dadRecLocs[length(dadRecLocs)-1]+1)
          }
          if(length(dadRecLocs) == 1){
            dadBeginLocs <- 1
          }
          if(dadStartChrom == 1){
            for(m in 1:length(dadRecLocs)){
              if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
              if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            }
          }
          if(dadStartChrom == 2){
            for(m in 1:length(dadRecLocs)){
              if(m %in% seq(1,200,2)){dadChrom <- c(dadChrom,dadsCopy2[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
              if(m %in% seq(2,200,2)){dadChrom <- c(dadChrom,dadsCopy1[l,(dadBeginLocs[m]+2):(dadRecLocs[m]+2)])}
            }
          }
          fryChromTwos[l,2:ncol(fryChromTwos)] <- dadChrom
        }
        if(j == 1){
          offChr1[[k]] <- fryChromOnes
          offChr2[[k]] <- fryChromTwos
        }
        if(j > 1){
          offChr1[[k]] <- rbind(offChr1[[k]],fryChromOnes)
          offChr2[[k]] <- rbind(offChr2[[k]],fryChromTwos)
        }
        nonNatAllsMom <- cbind(nonNatAllsMom,rowSums(fryChromOnes[,2:ncol(fryChromOnes)] == 0))
        nonNatAllsDad <- cbind(nonNatAllsDad,rowSums(fryChromTwos[,2:ncol(fryChromTwos)] == 0))
      }
      fryPercRBT <- rowSums(cbind(nonNatAllsMom,nonNatAllsDad))/(nChromLoci*(chroms)*2)   # genomic hybrid index of each fry
      fryOut <- cbind(fryIDs,fryPop,fryAge,fryPercRBT,frySex,fryMoms,fryDads,rep(i,length(fryIDs)))
      colnames(fryOut) <- NULL
      offspring <- rbind(offspring,fryOut)
    }

    ########################################################
    # calculate offspring hybrid index at the selected loci
    ########################################################
    selecPercRBT <- rep(NA,length(fryPercRBT))     # hybrid index of the individual at the causal loci
    selecGenos <- NULL
    for(z in 1:length(selecChrs)){
      selecGenos <- cbind(selecGenos,offChr1[[selecChrs[z]]][,selecLoci[z]+1],offChr2[[selecChrs[z]]][,selecLoci[z]+1])
    }
    selecPercRBT <- 1 - rowSums(selecGenos[,1:numSelecLoci])/numSelecLoci
    offspring <- cbind(offspring[,1:5],selecPercRBT,offspring[,6:8],rep(0,nrow(offspring)))

    ##################################################################################
    # update the genetic and demographic data
    ##################################################################################
    for(k in 1:length(chr1List)){
      chr1List[[k]] <- rbind(chr1List[[k]],offChr1[[k]])
      chr2List[[k]] <- rbind(chr2List[[k]],offChr2[[k]])
    }
    popMat<- rbind(popMat,offspring)
    ##################################################
    # advance the population to the next year
    ##################################################
    survVec <- rep(0,nrow(popMat)) # vector indicating survival (1) or death (0)
    newPop <- NULL         # temporarily store the new population data
    keepIndices <- NULL    # vector of the ids of individuals surviving to the next year
    for (j in 1:length(confs)){
      thisDat <- NULL
      thisDat <- popMat[which(popMat[,2] == j),]
      for (k in 1:(length(ageStruc)-1)){       # select individuals in each age class to survive to the next year (all individuals in the last age class die)
        ageDat <- NULL
        ageDat <- thisDat[which(thisDat[,3] == ages[k]),] # individuals in age class k for the jth population
        ageSelecGenos1 <- NULL    # genotypes of individuals in the kth age class at loci affecting fitness
        ageSelecGenos2 <- NULL
        for(z in 1:length(selecChrs)){
          ageSelecGenos1 <- cbind(ageSelecGenos1,chr1List[[selecChrs[z]]][match(ageDat[,1],chr1List[[selecChrs[z]]][,1]),selecLoci[z]+1])
          ageSelecGenos2 <- cbind(ageSelecGenos2,chr2List[[selecChrs[z]]][match(ageDat[,1],chr2List[[selecChrs[z]]][,1]),selecLoci[z]+1])
        }
        ageSelecGenos <- 2 - (ageSelecGenos1 + ageSelecGenos2)    # this is the number of non-native alleles each age[k] individdual has at each selected locus

        ######################################
        # get genotypes at the modifier loci
        ######################################
        ageModGenos1 <- NULL    # age class genotypes at modifier loci
        ageModGenos2 <- NULL
        for(z in 1:length(selecChrs)){
          ageModGenos1 <- cbind(ageModGenos1,chr1List[[modChrs[z]]][match(ageDat[,1],chr1List[[modChrs[z]]][,1]),modLoci[z]+1])
          ageModGenos2 <- cbind(ageModGenos2,chr2List[[modChrs[z]]][match(ageDat[,1],chr2List[[modChrs[z]]][,1]),modLoci[z]+1])
        }
        ageModGenos <- 2 - (ageModGenos1 + ageModGenos2)    # The number of population 1 alleles each female has at each modifier locus
        if(invRelSurv > 0){ageModGenos <- 2 - ageModGenos; ageSelecGenos <- 2 - ageSelecGenos}  # invert the genotypes at selected and modifier loci (to the number of native alleles) if natives are fitter than natives
        # ageSelecGenos and ageModGenos now give the number of the most fit allele at fitness and modifier loci
        locusEffsize_surv <- ((invRelSurv)/numSelecLoci)/2                              # Additive effect at each locus on reproduction (half the difference between homozygous genotypes, assumes equal effect sizes across loci)
        modEffSize <- epiSize/2                                                    # Additive effect at each modifier locus (half the difference between homozygous genotypes)
        modValMat <- matrix(0,nrow(ageModGenos),ncol(ageModGenos))           # Matrix to store the genetic values at modifier loci
        genValMat <- matrix(0,nrow(ageSelecGenos),ncol(ageSelecGenos))       # matrix to store the genetic trait values for each individual and selected locus
        for(z in 1:numSelecLoci){
          if(sum(ageSelecGenos[,z] == 1) > 0 & nativeDom == TRUE) {genValMat [which(ageSelecGenos[,z] == 1),z] <-  locusEffsize_surv * (1 - surv_d)     } #genetic value of heterozygotes at fitness loci, accounting for dominance
          if(sum(ageSelecGenos[,z] == 1) > 0 & nativeDom == FALSE){genValMat [which(ageSelecGenos[,z] == 1),z] <-  locusEffsize_surv * (1 + surv_d)}
          if(sum(ageSelecGenos[,z] == 2) > 0) {genValMat [which(ageSelecGenos[,z] == 2),z] <- 2 * locusEffsize_surv}
          if(epiSize > 0){
            if(sum(ageModGenos[,z] == 1) > 0 & nativeDom == TRUE)  {modValMat [which(ageModGenos[,z] == 1),z] <- modEffSize * (1 - epiDom)} #genetic value of heterozygotes at modifier loci, accounting for dominance
            if(sum(ageModGenos[,z] == 1) > 0 & nativeDom == FALSE) {modValMat [which(ageModGenos[,z] == 1),z] <- modEffSize * (1 + epiDom)}
            if(sum(ageModGenos[,z] == 2) > 0) {modValMat [which(ageModGenos[,z] == 2),z] <-  1}
          }
        }


        #############################################################
        # account for deleterious recessive alleles
        #############################################################

        if(numDelRec_nat > 0){     # account for the effects of deleterious recessive alleles fixed in pure native individuals
          natRecAlleleEff <- recEffSize_nat/numDelRec_nat
          for(z in 1:numDelRec_nat){
            if(sum(ageSelecGenos[,z+numSelecLoci] > 0) > 0 ) genValMat[which(ageSelecGenos[,z+numSelecLoci] > 0),z+numSelecLoci] <- natRecAlleleEff
          }
        }
        if(numDelRec_nonNat > 0){     # account for the effects of deleterious recessive alleles fixed in pure non-native individuals
          nonNatRecAlleleEff <- -1 * (recEffSize_nonNat/numDelRec_nonNat)
          for(z in 1:numDelRec_nonNat){
            if(sum(ageSelecGenos[,z+numSelecLoci+numDelRec_nat] == 2) > 0 ) genValMat[which(ageSelecGenos[,z+numSelecLoci+numDelRec_nat] == 2),z+numSelecLoci+numDelRec_nat] <- nonNatRecAlleleEff
          }
        }
        modValMat <- 1 - modValMat
        minGenVal <- min(c(0,locusEffsize_surv*2))
        maxGenVal <- max(c(0,locusEffsize_surv*2))
        genValMat2 <- matrix(NA,nrow=nrow(genValMat),ncol=ncol(genValMat))
        for(b in 1:ncol(genValMat2)){
          if(sum(ageSelecGenos[,b] == 0) > 0){         # genetic values of individuals that are homozygous for the least fit allele
            zeros <- which(ageSelecGenos[,b] == 0)
            genValMat2[zeros,b] <- genValMat[zeros,b]
          }
          if(sum(ageSelecGenos[,b] %in% c(1,2)) > 0){
            onesTwos <- which(ageSelecGenos[,b] %in% c(1,2))
            genValMat2[onesTwos,b] <- genValMat[onesTwos,b] - modValMat[onesTwos,b]*(genValMat[onesTwos,b] - minGenVal)
          }
        }
        if(numSelecLoci < ncol(genValMat)){
          genValMat2[,(numSelecLoci + 1):ncol(genValMat2)] <- genValMat[,(numSelecLoci + 1):ncol(genValMat2)]
        }
        survWeights <-  1 + rowSums(genValMat2)
        keepIds <- sample(ageDat[,1],size=ageStruc[k+1]*(popSize),replace=FALSE,prob = survWeights)
        keepIndices <- append(keepIndices,which(popMat[,1] %in% keepIds))
      }
    }
    survVec[keepIndices] <- 1                          # mark the survivors
    popMat[,10] <- survVec
    popMat[,9] <- i
    allPopMat <- rbind(allPopMat,popMat)               # save all individuals, including non-survivors
    newPop <- popMat[which(survVec == 1),]             # population of survivors for next year
    newPop[,3] <- newPop[,3] + 1                       # increase age of survivors by one year
    popMat <- newPop                                   # replace this year's population with the next
    print(paste("done with year", i))
  }

  ######################
  # format the genotypes
  ######################
  atMat <- NULL
  # loci are in rows, individuals are in columns
  for(i in 1:length(chr2List)){
    thisChr1 <- t(chr1List[[i]][,2:ncol(chr1List[[i]])])
    thisChr2 <- t(chr2List[[i]][,2:ncol(chr2List[[i]])])
    thisGenoMat <- matrix(NA,ncol=ncol(thisChr1)*2,nrow=nrow(thisChr1))
    fstAlls <- seq(from=1,to=2*(ncol(thisChr1)),by=2)
    secAlls <- seq(from=2,to=2*(ncol(thisChr1)),by=2)
    for (j in 1:length(fstAlls)){
      thisGenoMat[which(thisChr1[,j] == 1),fstAlls[j]] <- "A"
      thisGenoMat[which(thisChr1[,j] == 0),fstAlls[j]] <- "T"

      thisGenoMat[which(thisChr2[,j] == 1),secAlls[j]] <- "A"
      thisGenoMat[which(thisChr2[,j] == 0),secAlls[j]] <- "T"
    }
  atMat <- rbind(atMat,thisGenoMat)
  }
  genoIds <- NULL
  genoIds <- cbind(genoIds,chr1List[[1]][,1])   # link genotypes to individual IDs

  ############################################
  # make map files for all and selected loci
  ############################################
  lociMap <- NULL
  for (j in 1:chroms){
    chr <- rep(j,nChromLoci)
    pos <- seq(0,mapLeng,mapLeng/(nChromLoci-1))
    thisMap <- cbind(chr,pos)
    lociMap <- rbind(lociMap,thisMap)
  }
  if(numSelecLoci > 0){
    selecLociMap <- NULL
    for(j in 1:length(selecLoci)){
      outVec <- c(lociMap[which(lociMap[,1] == selecChrs[j])[selecLoci[j]],])
      selecLociMap <- rbind(selecLociMap,outVec)
    }
  }
  if(numSelecLoci > 0){
    admixRes <- list(allPopMat,atMat,lociMap,selecLociMap,genoIds)
  }
  if(numSelecLoci == 0 | is.null(numSelecLoci)) {
    admixRes <- list(allPopMat,atMat,lociMap,genoIds)
  }
  return(admixRes)
}




